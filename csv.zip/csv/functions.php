<?php ob_start();
class lib
{
	function __construct()
	{
		$this->db=new PDO("mysql:host=localhost;dbname=domains","domains","domains@12");
		$this->base_url="http://dandelionmovie.com/domains_database/";
		$this->current_url=(isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";;
	}
	function insert($data,$table)
	{
		foreach($data as $key=>$val)
		{
			@$cols .=$key."='".str_replace("'","",$val)."',";
		}
		$col=rtrim($cols,",");
		$sql="insert into $table set ".$col;
		$row=$this->db->prepare($sql);
		$row->execute();
		//echo "<pre>";print_r($row->errorInfo());
		
	}
	
	function update($data,$table,$id)
	{
		foreach($data as $key=>$val)
		{
			@$cols .=$key."='".$val."',";
		}
		$col=rtrim($cols,",");
		$sql="update $table set ".$col." where id='".$id."'";
		$row=$this->db->prepare($sql);
		$row->execute();
		
	}
	
	function updatewhere($data,$table,$arr)
	{
		foreach($data as $key=>$val)
		{
			@$cols .=$key."='".$val."',";
		}
		$col=rtrim($cols,",");
		$coll=array_keys($arr);
		//print_r($col);
		$sql="update $table set ".$col." where ".$coll[0]."=".$arr[$coll[0]];
		$row=$this->db->prepare($sql);
		$row->execute();
		//echo "<pre>";print_r($row->errorInfo());
		
	}
	
	function delete($table,$id)
	{
	
		$sql="delete  from $table  where id='".$id."'";
		$row=$this->db->prepare($sql);
		$row->execute();
		
	}
	
	function getData($table)
	{
		$sql="select * from $table order by id desc";
		$row=$this->db->prepare($sql);
		$rw=$row->execute();
		$rdata=$row->fetchAll(PDO::FETCH_ASSOC);
		return $rdata;
	}
	
	function query($sql)
	{
		$sql=$sql;
		$row=$this->db->prepare($sql);
		$rw=$row->execute();
		return $row;
	}
	
	
	function getDataByID($table,$id)
	{
		$sql="select * from $table where id='".$id."'";
		$row=$this->db->prepare($sql);
		$rw=$row->execute();
		$rdata=$row->fetch(PDO::FETCH_ASSOC);
		return $rdata;
	}


	function uploadFile($target_dir,$name)
	{
		$filename=time()."__".basename($_FILES[$name]['name']);
		$path=$target_dir.$filename;
		if(move_uploaded_file($_FILES[$name]['tmp_name'], $path))
		{
			return true;
		}
		else
		{
			return false;
		}

	}

	function multiUploadFile($target_dir,$name)
	{
		
		for($i=0;$i<count($_FILES[$name]['name']);$i++)
		{
		$filename=time()."__".basename($_FILES[$name]['name'][$i]);
		$path=$target_dir.$filename;
		move_uploaded_file($_FILES[$name]['tmp_name'][$i], $path);
		}
		

	}
	
	function editfunction($table,$id,$url)
	{
		if(isset($_POST['edt_'.$table]))
		{
			//print_r($_POST[$table]);
			$this->update($_POST[$table],$table,$id);
			header("location:".$url);
		}
		echo "<div class='p-row'>
		<br>
		<br>
		<div class='container'>
		<div class='row'>
		<div class='col-md-5 col-md-offset-3'>
		<table class='table table-bordered'><form method='post'>";
		$row=$this->getDataByID($table,$id);
		unset($row['id']);
		foreach($row as $key=>$val)
		{
			$r=$table."[".$key."]";
			echo "<tr><td style='text-transform:capitalize;'><label>".str_replace('_','',$key)."</label></td>";
			echo "<td><input type='text' name='".$r."' value='".$val."' /></td></tr>";
		}
		echo "<tr><td></td><td><input type='submit' class='btn btn-primary' name='edt_".$table."' value='Update' /></td></tr>";;
		echo "</form></table></div></div></div></div>";
		
		
	}
	
	function showfunction($table,$edit,$del)
	{
		echo "<table class='table table-bordered table-responsive'>";
		$q = $this->query("DESCRIBE $table");
		$col = $q->fetchAll(PDO::FETCH_COLUMN);
		
		foreach($col as $val)
		{
			echo "<th>".str_replace("_"," ",$val)."</th>";
		}
		echo "<th>Edit</th>";
		echo "<th>Delete</th>";
		echo "</tr>";
		$rows=$this->getData($table);
		//echo "<pre>";print_r($rows);
		foreach($rows as $row)
		{
			echo "<tr>";
			foreach($col as $cols)
			{
				//echo $cols."<br />";
				echo "<td>".$row[$cols]."</td>";
			}
				echo "<td><a href='$edit&id=".$row['id']."'><i class='fa fa-pencil'></i></a></td>";
				echo "<td><a href='$del&id=".$row['id']."'><i class='fa fa-trash-o'></i></a></td>";
			echo "</tr>";
		}
		
		echo "</table>";
		
	}
	
	function addfunction($table,$url)
	{
		if(isset($_POST['add_'.$table]))
		{
			//print_r($_POST[$table]);
			$this->insert($_POST[$table],$table);
			header("location:".$url);
		}
		echo "<div class='p-row'>
		<br>
		<br>
		<div class='container'>
		<div class='row'>
		<div class='col-md-5 col-md-offset-3'>
		<table class='table table-bordered'><form method='post'>";
		$q = $this->query("DESCRIBE $table");
		$row = $q->fetchAll(PDO::FETCH_COLUMN);
		//print_r($row);
		unset($row[0]);
		foreach($row as $key)
		{
			$r=$table."[".$key."]";
			echo "<tr><td style='text-transform:capitalize;'><label>".str_replace('_','',$key)."</label></td>";
			echo "<td><input type='text' name='".$r."' /></td></tr>";
		}
		echo "<tr><td></td><td><input type='submit' class='btn btn-primary' name='add_".$table."' value='Add' /></td></tr>";;
		echo "</form></table></div></div></div></div>";
		
		
	}
	
	function drawForm($cls,$data)
	{
		echo "<div class='".$cls."'><form method='post' enctype='multipart/form-data'>";
		foreach($data as $key=>$val)
		{
			echo "<div class='form-group'><lable for=".$key.">".ucwords($key)." : </label><input class='form-control' type='".$val."' name='".$key."' /></div>";
		}
		echo "<div><input type='submit' name='submit' class='form-control' /></div>";
		echo "</form></div>";
	}
	
	function array_to_csv_download($array, $filename = "export.csv", $delimiter=";") {
    // open raw memory as file so no temp files needed, you might run out of memory though
    $f = fopen('php://memory', 'w'); 
    // loop over the input array
	$arw=array("domain_name","host","uname","password","userid","start_date","end_date");
	fputcsv($f, $arw, $delimiter); 
    foreach ($array as $line) { 
        // generate csv lines from the inner arrays
        fputcsv($f, $line, $delimiter); 
    }
    // reset the file pointer to the start of the file
    fseek($f, 0);
    // tell the browser it's going to be a csv file
    header('Content-Type: application/csv');
    // tell the browser we want to save it instead of displaying it
    header('Content-Disposition: attachment; filename="'.$filename.'";');
    // make php send the generated csv lines to the browser
    fpassthru($f);
}

}
$lib=new lib;

 ?>