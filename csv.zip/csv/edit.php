<?php include("header.php");   ?>
  <style>
		.table tr:nth-child(4)
		{
			display:none;
		}
	</style>
<?php 

if(@$_GET['action']=="edit")
{
	 $lib->editfunction("domains",$_GET['id'],$lib->base_url);
}

if(@$_GET['action']=="add")
{
	 $lib->addfunction("domains",$lib->base_url);
}

if(@$_GET['action']=="edit_profile")
{
	//print_r($_SESSION);
	 $lib->editfunction("users",$_SESSION['userInfo']['id'],$lib->base_url);
}

if(@$_GET['action']=="delete")
{
	$lib->delete("domains",$_GET['id']);
	header("location:".$lib->base_url);
}

?>

<?php include("footer.php"); ?>