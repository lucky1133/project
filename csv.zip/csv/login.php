<?php ob_start(); session_start(); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>CSV IMPORTER</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	
  </head>
<?php
	include("functions.php");
	
	if(isset($_POST['register-submit'])){
		$row=$lib->query("select count(*) as num from users where username='".$_POST['user']['username']."' or email='".$_POST['user']['email']."' ");
		$rw=$row->fetch(PDO::FETCH_LAZY);
		$ck=$rw['num'];
		if($ck==0)
		{
		$lib->insert($_POST['user'],"users");
		}
		else
		{
			$msg="User Already Exist with same email or username!";
		}
	}
	
	if(isset($_POST['login-submit']))
	{
		$sql="select *,count(*) as num  from users where email='".$_POST['login']['username']."' and password='".$_POST['login']['password']."' ";
		$row=$lib->query($sql);
		$rw=$row->fetch(PDO::FETCH_ASSOC);
		//print_r($rw);
		 $ck=$rw['num'];
		if($ck!=0)
		{
			$_SESSION['userInfo']=$rw;
			$_SESSION['loggedIn']="yes";
			//print_r($_SESSION);
			header("Location:".$lib->base_url);
		}
		else
		{
			$msg="User or password is incorrect!";
		}
		
	}
	$curl=$lib->current_url;
	$arr=array($lib->base_url."login.php");
	if(in_array($curl,$arr) && @$_SESSION['loggedIn']=="yes")
	{
	  header("Location:".$lib->base_url."index.php");
	}

	if(!in_array($curl,$arr) && @$_SESSION['loggedIn']=="")
	{
	  header("Location:".$lib->base_url."login.php");
	}
?>
  
<div class="container">
        <div class="row">
			<div class="col-md-4 col-md-offset-4">
				
				<div class="panel panel-login panel-mar">
					<div class="text-center" style="margin-top:8px">
						<p style="color:red; font-weight:600"><?php echo @$msg; ?></p>
					</div>
					<div class="panel-heading">
						<div class="row">
						
							<div class="col-xs-6">
								<a href="#" class="active" id="login-form-link">Login</a>
							</div>
							<div class="col-xs-6">
								<a href="#" id="register-form-link">Register</a>
							</div>
						</div>
						<hr>
					</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-lg-12">
								<form id="login-form" action="" method="post" role="form" style="display: block;">
									<div class="form-group">
										<input type="text" name="login[username]" id="login[username]" tabindex="1" class="form-control" placeholder="Username" value="">
									</div>
									<div class="form-group">
										<input type="password" name="login[password]" id="login[password]" tabindex="2" class="form-control" placeholder="Password">
									</div>
									<!-- <div class="form-group text-center">
										<input type="checkbox" tabindex="3" class="" name="remember" id="remember">
										<label for="remember"> Remember Me</label>
									</div> -->
									<div class="form-group">
										<div class="row">
											<div class="col-sm-6 col-sm-offset-3">
												<input type="submit" name="login-submit" id="login-submit" tabindex="4" class="form-control btn btn-login" value="Log In">
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-lg-12">
												<!--div class="text-center">
													<a href="" tabindex="5" class="forgot-password">Forgot Password?</a>
												</div-->
											</div>
										</div>
									</div>
								</form>
								<form id="register-form" action="" method="post" role="form" style="display: none;">
									<div class="form-group">
										<input type="text" name="user[username]" id="username" tabindex="1" class="form-control" placeholder="Username" value="">
									</div>
									<div class="form-group">
										<input type="email" name="user[email]" id="email" tabindex="1" class="form-control" placeholder="Email Address" value="">
									</div>
									<div class="form-group">
										<input type="password" name="user[password]" id="password" tabindex="2" class="form-control" placeholder="Password">
									</div>
									<!--div class="form-group">
										<input type="password" name="confirm-password" id="confirm-password" tabindex="2" class="form-control" placeholder="Confirm Password">
									</div-->
									<div class="form-group">
										<div class="row">
											<div class="col-sm-6 col-sm-offset-3">
												<input type="submit" name="register-submit" id="register-submit" tabindex="4" class="form-control btn btn-register" value="Register Now">
											</div>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>
	
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	
	<script>
	$(function() {

		$('#login-form-link').click(function(e) {
			$("#login-form").delay(100).fadeIn(100);
			$("#register-form").fadeOut(100);
			$('#register-form-link').removeClass('active');
			$(this).addClass('active');
			e.preventDefault();
		});
		
		$('#register-form-link').click(function(e) {
			$("#register-form").delay(100).fadeIn(100);
			$("#login-form").fadeOut(100);
			$('#login-form-link').removeClass('active');
			$(this).addClass('active');
			e.preventDefault();
		});

	});

	</script>
  </body>
</html>