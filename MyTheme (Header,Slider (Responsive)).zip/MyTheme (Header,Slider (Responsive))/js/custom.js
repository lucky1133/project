//menu header//
jQuery(document).ready(function($){
    //if you change this breakpoint in the style.css file (or _layout.scss if you use SASS), don't forget to update this value as well
    var wd = 1170;

    //primary navigation slide-in effect
    if($(window).width() > wd) {
        var headerHeight = $('.Navbar-Header').height();
        $(window).on('scroll',
        {
            previousTop: 0
        },
        function () {
            var currentTop = $(window).scrollTop();
            //check if user is scrolling up
            if (currentTop < this.previousTop ) {
                //if scrolling up...
                if (currentTop > 0 && $('.Navbar-Header').hasClass('is-fixed')) {
                    $('.Navbar-Header').addClass('is-visible');
                } else {
                    $('.Navbar-Header').removeClass('is-visible is-fixed');
                }
            } else {
                //if scrolling down...
                $('.Navbar-Header').removeClass('is-visible');
                if( currentTop > headerHeight && !$('.Navbar-Header').hasClass('is-fixed')) $('.Navbar-Header').addClass('is-fixed');
            }
            this.previousTop = currentTop;
        });
    }
});

$(document).ready(function () {

if($('.Navbar-Header-sticky').attr('data-sticky') == "true"){
	$(window).on("scroll",function(){
		var Scrl = $(window).scrollTop();
		if (Scrl > 1) {
			$('.Navbar-Header-sticky').addClass('sticky animated fadeInDown');
		}else{
			$('.Navbar-Header-sticky').removeClass('sticky animated fadeInDown');
		}
	});
	$('document').ready(function(){
		var Scrl = $(window).scrollTop();
		if (Scrl > 1) {
			$('.Navbar-Header-sticky').addClass('sticky animated fadeInDown');
		}else{
			$('.Navbar-Header-sticky').removeClass('sticky animated fadeInDown');
		}
	});
}
});

/*-----------------------------------------------------------------------------------*/
/*	End Sticky Navigation
/*-----------------------------------------------------------------------------------*/

/* ---------------------------------------------------------------------- */
/*	Start Search
/* ---------------------------------------------------------------------- */

$('.Icons-Search').click(function(){
	if($(this).parent().find('#m_search').is(':visible')){
		$('#m_search').fadeOut(300);
		$(this).parent().removeClass('selected');
		$('body').removeClass('show-search');
		return false;
	}else{
		$('#m_search').fadeIn(100);
		$(this).parent().addClass('selected');
		$('body').addClass('show-search');
		return false;
	}
});










