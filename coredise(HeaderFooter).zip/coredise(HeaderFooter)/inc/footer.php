<footer class="footer ">
   <section class="footer1 main-pad" style="background-image: url(images/footerbg.png)">
      <div class="container">
         <div class="row">
            <div class="col-lg-3 col-sm-6 co-md-3 mt25">
               <img src="images/logo.png" class="mb-3" alt="" />
               <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a .</p>
               <h4 class="mt-3 mb-2">Follow Us</h4>
               <div class="topsoc">
                  <a href="#"> <img src="images/icon1.svg" width="25" alt=""> </a>
                  <a href="#"> <img src="images/icon2.svg" width="25" alt=""> </a>
                  <a href="#"> <img src="images/icon3.svg" width="25" alt=""> </a>
                  <a href="#"> <img src="images/icon4.svg" width="25" alt=""> </a>
               </div>
            </div>
            <div class="col-lg-3 col-sm-6 co-md-3 mt25">
               <h3>Quick Links</h3>
               <ul class="list-unstyled">
                  <li> <a href="">About Us</a> </li>
                  <li> <a href="">Terms & Conditions</a> </li>
                  <li> <a href="">Contact Us</a> </li>
                  <li> <a href="">My Account </a> </li>
                  <li> <a href="">FAQ </a> </li>
                  <li> <a href="">Blog </a> </li>
               </ul>
            </div>
            <div class="col-lg-3 col-sm-6 co-md-3 mt25">
               <h3>Support</h3>
               <ul class="list-unstyled">
                  <li> <a href="">About Us</a> </li>
                  <li> <a href="">Terms & Conditions</a> </li>
                  <li> <a href="">Contact Us</a> </li>
                  <li> <a href="">My Account </a> </li>
                  <li> <a href="">FAQ </a> </li>
                  <li> <a href="">Blog </a> </li>
               </ul>
            </div>
            <div class="col-lg-3 col-sm-6 co-md-3 mt25">
               <h3>Contact Us</h3>
               <ul class="list-unstyled conli">
                    <li>
                      <div class="address">
                        <img src="images/fphone.svg" width="18" />
                        <p> (01) 428 5890</p>
                      </div>
                    </li> 
                   <li>
                      <div class="address">
                        <img src="images/email.svg" width="16" />
                        <p> marketing@coredise.com.pe</p>
                      </div>
                    </li> 
                  <li>
                      <div class="address">
                        <img src="images/floc.svg" width="14" />
                        <p> Jr. Azángaro N ° 658, Int. 103 <br>  Cercado de Lima</p>
                      </div>
                    </li> 
                  <li>
                      <div class="address">
                        <img src="images/ftime.svg" width="19" />
                        <p> M - F 8:00 a.m. to 6:00 p.m. <br /> S 8:00 a.m. to 2:00 p.m.</p>
                      </div>
                    </li> 
               </ul>
            </div>
         </div>
      </div>
   </section>
   <section class="bgRed">
      <div class="container">
         <div class="row">
            <div class="col-md-12 text-center">
               <div class="footer-bottom-wrap d-flex justify-content-between">
                  <div class="copyright-text">
                     <p>Copyright © 2020 -Coredise</p>
                  </div>
                  <div class="linkul">
                     <ul class="list-unstyled list-inline">
                        <li class="list-inline-item"><a href="#">Privacy &amp; Policy </a></li>
                        <li class="list-inline-item"><a href="#"> Term  &amp;  Condition</a></li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
</footer>
<!-- End Of Footer -->
<!-- jQuery Javascript -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/mmenu-light.js"></script>
<script src="js/jquery.magnific-popup.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script src="js/custom.js"></script>
<script>
   var menu = new MmenuLight(
   	document.querySelector( '#menu' ),
   	'all'
   );
   
   var navigator = menu.navigation({
   	// selectedClass: 'Selected',
   	// slidingSubmenus: true,
   	// theme: 'dark',
   	// title: 'Menu'
   });
   
   var drawer = menu.offcanvas({
   	// position: 'left'
   });
   
   //	Open the menu.
   document.querySelector( 'a[href="#menu"]' )
   .addEventListener( 'click', evnt => {
   	evnt.preventDefault();
   	drawer.open();
   });
   
</script>
</body>
</html>