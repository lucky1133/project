<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Coredise</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="icon" href="images/favicon.png" type="image/png" sizes="16x16">
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <link href="css/animate.css" rel="stylesheet">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
      <link rel="stylesheet" href="css/magnific-popup.css" />   
      <link rel="stylesheet" href="css/mmenu-light.css">
      <link rel="stylesheet" href="css/menumobile.css">
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/responsive.css">
   </head>
   <body>
      <!-- Desktop Version menu -->
      <header class="dktop">
         <div class="top_header">
            <div class="container">
               <div class="tick">
                  <div class="ticker__viewport">
                      <ul class="ticker__list" data-ticker="list">
                          <li class="ticker__item" data-ticker="item">
                           <img src="images/phone.svg" width="17" class="mr-2" /><a href="#">(+511) 428 5890/7198471</a>
                          </li>
                     </ul>
                  </div>
               </div>

               <div class="top_details d-flex align-items-center">
                  <div class="mr-3">
                     <img src="images/location.svg" width="17" class="mr-2" /> <span>Jr. Azángaro N ° 658, Int. 103 - Cercado de Lima</span>
                  </div>
                  <div class="topsoc">
                       <a href="#"> <img src="images/icon1.svg" width="25" alt="" /> </a>
                       <a href="#"> <img src="images/icon2.svg" width="25" alt="" /> </a>
                       <a href="#"> <img src="images/icon3.svg" width="25" alt="" /> </a>
                       <a href="#"> <img src="images/icon4.svg" width="25" alt="" /> </a>
                  </div>
               </div>
            </div>
         </div>

         <div class="header-bottom header-sticky">
            <!------ Include the above in your HEAD tag ---------->
               <div class="container">
                  <div class="navbar navbar-dark navbar-trans navbar-static-top navbar-expand-lg">
                     <a class="navbar-toggler" data-toggle="collapse" data-target=".navbar-collapse">
                     &#x2630;
                     </a>
                     <a class="navbar-brand" href="index.php"><img src="images/logo.png" class="img-fluid" alt="Logo" /></a>
                     <div class="navbar-collapse collapse justify-content-center">
                        <ul class="navbar-nav ml-auto svg-img">
                           <li class="active nav-item">
                              <a href="index.php" class="nav-link">Home</a>
                           </li>
                           <li class="nav-item">
                              <a href="#" target="ext" class="nav-link">Company</a>
                           </li>
                           <li class="nav-item">
                              <a href="#" class="nav-link">Points of Sale</a>
                           </li>
                           <li class="nav-item">
                              <a href="#" class="nav-link">Store</a>
                           </li>
                           <li class="nav-item">
                              <a href="services.php" class="nav-link">Virtual Classroom</a>
                           </li>
                           <li class="nav-item ml-3 d-flex">
                              <a href="#" class="nav-link mr-2"> Login</a>
                              <a href="#" class="btn btn-info logbtn"> Register</a>
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
               <!-- /container -->
            <!-- /navbar wrapper -->
            
         </div>
      </header>
      <!-- End Of Desktop Version menu -->


      <!-- Mobile Version menu -->
      <header class="mobileHeader">
        
         <div class="header-bottom header-sticky">
            <!------ Include the above in your HEAD tag ---------->
               <div class="container">
                  <div class="navbar navbar-dark navbar-trans navbar-static-top navbar-expand-lg">
                     <a href="#menu">
                     &#x2630;
                     </a>
                     <a class="navbar-brand" href="index.php"><img src="images/logo.png" class="img-fluid" alt="Logo" /></a>

                     <span class="pr-3"> 
                       <a href="#" class="mr-2">
                         Login
                       </a>

                       <a href="#">
                          <a href="#"><i class="fa fa-user"></i></a>
                       </a>
                     </span>

                     <nav  class="justify-content-center" id="menu">
                        <ul class="navbar-nav ml-auto svg-img">
                           <li class="active nav-item">
                              <a href="index.php" class="nav-link">Home</a>
                           </li>
                           <li class="nav-item">
                              <a href="#" target="ext" class="nav-link">Company</a>
                           </li>
                           <li class="nav-item">
                              <a href="#" class="nav-link">Points of Sale</a>
                           </li>
                           <li class="nav-item">
                              <a href="#" class="nav-link">Store</a>
                           </li>
                           <li class="nav-item">
                              <a href="services.php" class="nav-link">Virtual Classroom</a>
                           </li>
                        </ul>
                     </nav >
                  </div>
               </div>
               <!-- /container -->
         </div>
      </header>
      <!-- End Of Mobile Version menu -->
      
