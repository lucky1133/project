<?php include('inc/header.php'); ?>   
<section class="banner">
    <div class="owl-slider">
	    <div id="carousel" class="owl-carousel">
			<div class="item">
				<img class="owl-lazy" data-src="images/slider.jpg" alt="">
			</div>
			<div class="item">
				<img class="owl-lazy" data-src="images/slider.jpg" alt="">
			</div>
			<div class="item">
				<img class="owl-lazy" data-src="images/slider.jpg" alt="">
			</div>
	    </div>
	</div>
</section>


<?php include('inc/footer.php'); ?>