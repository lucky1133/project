"use strict";


$('#n-carousel').carousel({
	interval: 8000,
	pause: false
});


/*** making scroll spy ***/

$('body').scrollspy({ target: '#n-main-nav' });


/*** makeing full height carousel !! ***/

var windowHeight = $(window).height();

var windowWidth = $(window).width();

// header height count and removing

var headerHeight = $('#main-header').height();

$('.full-height').css('height', windowHeight - headerHeight); // you can disable this full height

/*** making carousel image to background image ***/

$('#n-carousel .item .carousel-image').each(function(){
	var imgSrc = $(this).attr('src');

	$(this).parent().css('background-image', 'url(' + imgSrc + ')');

	$(this).remove();
});

/*** creating carousel indicators ***/

var slideNum = $('#n-carousel .item').length;

for(var i=0; i< slideNum; i++){
	var insertData = '<li data-target="#n-carousel" data-slide-to="' + i + '"';

	if(i== 0){
		insertData += 'class="active"';
	}

	 insertData += '></li>';

	$('#n-carousel ol').append(insertData);
}


/* control the height of photo block of about us */

var chooseHieght = $('.about-us').height();

if($(window).width() > 992){

	$('.about-us .image-block').css('height', chooseHieght);
}

/*
	making navbar fixed
 */

var navbar = $('#n-main-nav');

var navbarHeight = navbar.height() - 2; // two comes from border i guess

var navbarDistance = navbar.offset().top;


if($('body').hasClass('home-page')){
	var needHeight = $('.intro').offset().top - navbarHeight;
}else{
	var needHeight = $('#page-title-block').offset().top + $('#page-title-block').outerHeight() - navbarHeight;
}



$(window).bind('scroll', function () {

	var scrollVal = $(window).scrollTop();

	var navbarHeight = navbar.height() - 2;

	if($('body').hasClass('construction')){
		return;
	}

	if( scrollVal > navbarHeight + navbarDistance ){

		navbar.css('opacity', 0).addClass('navbar-fixed-top');

		$('body').css('padding-top', navbarHeight);

		if(scrollVal > needHeight){
			navbar.css('opacity', 1).css('transition', '.3s');
		}

	}else{
		navbar.css('transition', '0s').css('opacity', 1).removeClass('navbar-fixed-top');
		$('body').css('padding-top', 0);
	}

});



/*** WINDOW RESIZE EVENT ***/

$(window).resize(function(){

	/* adjust window of .full-height when window resize */
	
	windowHeight = $(window).height();
  	windowWidth = $(window).width();


	$('.full-height').css('height', windowHeight);

	/* Adjust the height of image on WHY CHOOSE US section */
	
	var chooseHieght = $('.about-us .content-block').height();

	if( windowWidth > 992){

		$('.about-us .image-block').css('height', chooseHieght + 56 + 58 ); // 56 + 58 comes from padding ! (im not sure !!)
	}

});






