<?php 
include("functions.php");
include("controller/Controller.php");
$action=$_GET['action'];
$method=$_GET['method'];
$file="controller/".$action.".php";
if(file_exists($file))
{
include($file);
$a=new $action;
if(method_exists($a,$method))
{
$a->$method();
}
else
{
	echo "Page Not Found!";
}
}
?>
