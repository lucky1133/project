	<!-- SLIDER SECTION STARTS -->

	<section class="slider" id="slider">
		<div id="n-carousel" class="carousel fade">
		

			<!-- Wrapper for slides -->
  			<div class="carousel-inner full-height" role="listbox">
  				<div class="item active">
  					<img class="img-responsive carousel-image" src="img/image-1.jpg" alt="carousel image">
			    	<!-- IMAGE SIZE SHOULD BE 1920x1080 -->
			    	<div class="carousel-caption">
						<div class="caption-wrapper">
				    		<h3>Welcome to Change AppleId</h3>
				    		<h1 class="caption-title"><a href="tel:1-855-887-0097"> 1-855-887-0097 </a></h1>
				    		
				    		<div class="caption-btns">
				    			<a href="tel:1-855-887-0097" class="btn btn-ghost"> CALL US NOW </a>
				    		</div>
				    	</div> 
			    	</div>
			    </div>				
  			</div> 
  		</div> 
	</section> <!-- .SLIDER SECTION ENDS -->
	
	<!-- INTRO SECTION STARTS -->

	<section class="section-block intro" id="about">
		<div class="container">
			<div class="row">

				<div class="section-title-block">
					<h3 class="section-title">About Us</h3>
					
				</div> <!-- .section-title-block ends -->

				<div class="col-md-12 intro-content">
				
						<p class="ab-para">
							Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
						</p>
						
					
						
				</div> <!-- .intro-content ends -->

			</div> 
		</div> 
	</section> <!-- INTRO SECTION ENDS -->
	
	<!-- Services	-->
	<section class="section-block intro" id="services">
		<div class="container">
			<div class="row">
				<div class="section-title-block">
					<h3 class="section-title">Services</h3>
				</div> 
			</div>

			<div class="row">
				<div class="col-md-6">
					<div class="serviceBox">
						<div class="service-icon">
							<i class="fa fa-globe"></i>
						</div>
						<div class="service-Content">
							<h3 class="title">Services 1</h3>
							<p class="description">
								Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
							</p>
						</div>
					</div>
				</div>
		 
				<div class="col-md-6">
					<div class="serviceBox">
						<div class="service-icon">
							<i class="fa fa-briefcase"></i>
						</div>
						<div class="service-Content">
							<h3 class="title">Services 1</h3>
							<p class="description">
								Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
							</p>
						</div>
					</div>
				</div>
				
					<div class="col-md-6">
					<div class="serviceBox">
						<div class="service-icon">
							<i class="fa fa-briefcase"></i>
						</div>
						<div class="service-Content">
							<h3 class="title">Services 1</h3>
							<p class="description">
								Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
							</p>
						</div>
					</div>
				</div>
				
					<div class="col-md-6">
					<div class="serviceBox">
						<div class="service-icon">
							<i class="fa fa-briefcase"></i>
						</div>
						<div class="service-Content">
							<h3 class="title">Services 1</h3>
							<p class="description">
								Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
							</p>
						</div>
					</div>
				</div>
			</div>
		</div> 
	</section> <!-- INTRO SECTION ENDS -->

	<!-- TESTIMONIAL CAROUSEL SECTION STARTS -->

	<section class="testimonial-carousel" id="testimonial-carousel">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="section-title-block">
						<h3 class="section-title">Why We Choose Us</h3>
					</div> 
				</div>
				
				<div class="col-md-12">
					<div class="why-para">
						<p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley. </p>
					
						<p> <strong> Lorem Ipsum is simply dummy text of the :- </strong> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries,  </p>
						
						<p> <strong> Lorem Ipsum is simply dummy text of the :- </strong> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries,  </p>
						
						<p> <strong> Lorem Ipsum is simply dummy text of the :- </strong> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries,  </p>
						
						<p> <strong> Lorem Ipsum is simply dummy text of the :- </strong> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries,  </p>
						
						<p> <strong> Lorem Ipsum is simply dummy text of the :- </strong> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries,  </p>
					</div>
				</div>
		    </div> 
		</div> 
	</section> <!-- TESTIMONIAL CAROUSEL SECTION ENDS -->

	<!-- CONTACT SECTION STARTS -->
	<section class="contact-us section-block" id="contact-us">
		<div class="container">
			<div class="section-title-block">
				<h3 class="section-title">Contact Us</h3>
				
			</div> 

			<div class="row">
				<div class="col-md-12 contact-form">
					<form id="n-contact" method="post" name="booking" action="form.php" onsubmit="return(validate())">
						<div class="row form-content">
							<div class="col-md-6 name-field">
								<div class="form-group">
									<label class="sr-only" for="name">Name:</label>
									<input type="text" id="name" class="form-control" name="name" placeholder="Name" >
								</div>
							</div>
							<div class="col-md-6 email-field">
								<div class="form-group">
									<label class="sr-only" for="email">Email:</label>
									<input type="email" id="email" class="form-control" name="email" placeholder="Email" >
								</div>
							</div> 
							
							<div class="col-md-12 message-field">
								<div class="form-group">
									<label class="sr-only" for="email">Phone Number:</label>
									<input type="text" id="phone" class="form-control" name="phone" placeholder="Your Number" >
								</div>
							</div> 


							<div class="col-md-12 message-field">
								<div class="form-group">
									<label class="sr-only" for="message">Message</label>
									<textarea class="form-control" id="message" name="message" placeholder="Write your message here" ></textarea>
								</div>

								<button type="submit" name="submit" class="btn btn-main pull-right">Submit</button>

							</div> 
						</div> 
					</form> 
				</div> <!-- .contact-form ends -->

			</div> 
		</div>
	</section> 

	<!-- CONTACT SECTION ENDS -->
	
	 <!-- Disclaimer -->
        <section id="disclaimer">
           <div class="container">
              <div class="row">
                <div class="col-md-12">
                <span> Disclaimer </span>
                    <p>Change AppleId is a total independent and completely autonomous technical service provider. We provide technical support for all the major vendors and third party products. </p>
                </div>
              </div>
           </div>
		</section>
        <!-- End Of Dislaimer -->
