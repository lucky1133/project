	<footer>
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="footer-social">
							<ul>
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-youtube"></i></a></li>
								<li><a href="#"><i class="fa fa-pinterest"></i></a></li>
							</ul>
						</div>
						
						<div class="footer-menu">
							<ul>
								<li> <a href="terms-and-condition.html"> Terms & Condition </a> </li>
								<li> <a href="privacy-policy.html"> Privacy Policy </a> </li>
								<li> <a href="disclaimer.html" > Disclaimer </a> </li>
							</ul>
						</div>
						
						<div class="copyright-text">
							<p>© 2017 Change AppleId All Rights Reserved.</p>
						</div>
						
					</div>
				</div>
			</div>
		</footer>
		<!-- Footer section Ends -->

	<!-- SCRIPTS -->
	<script type="text/javascript" src="js/jquery-1.11.3.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/owl.carousel.min.js"></script>
	<script type="text/javascript" src="js/main.js"></script>	
	
	<script>
		// Navigation Scroll Lucky
		$('.navbar li a').on('click', function() {
			$('html, body').animate({
				scrollTop: $(this.hash).offset().top - 10
			}, 1000);
			return false;
		});
	</script>
	
	<script type="text/javascript">
      
    function validate()
      {     
	         
        if (document.booking.name.value == "") 
        {
        alert("Please Enter Your Name");
        document.booking.name.focus();
        return false;
        }
    
        if (!/^[a-zA-Z, ]*$/g.test(document.booking.name.value)) 
        {
        alert("Please Enter Your Username In Alphabets Only");
        document.booking.name.focus();
        return false;
        }

         
        if( document.booking.email.value == "" )
        {
            alert( "Please Enter Your Email Address!" );
            document.booking.email.focus();
            return false;
        }
         
        var x = document.forms["booking"]["email"].value;
            var atpos = x.indexOf("@");
            var dotpos = x.lastIndexOf(".");
            if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length) {
                alert("The Email You Entered Is Not A Valid E-mail Address");
                document.booking.email.focus();
                return false;
            }             
		if( document.booking.phone.value == "" )
        {
            alert( "Please Enter Your Phone Number!" );
            document.booking.phone.focus() ;
            return false;
        }
		 
		if( document.booking.message.value == "" )
			{
				alert( "Please Enter Your Message!" );
				document.booking.message.focus();
				return false;
			}
		}
		 
	</script> 
	
</body>
</html>