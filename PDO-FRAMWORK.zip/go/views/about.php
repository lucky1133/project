<?php
$data=array(
"fname"=>"text",
"fname1"=>"text",
"fname2"=>"text",
"fname3"=>"text",
"fname4"=>"text",
"fname4"=>"text"
);
echo $this->drawForm("ccc",$data);
 ?>