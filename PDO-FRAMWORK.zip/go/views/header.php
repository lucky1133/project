<!doctype html>
<html lang="en">

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Change AppleId </title>

	<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700%7CSource+Sans+Pro:400,400italic,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/linea.css">
	<link rel="stylesheet" type="text/css" href="css/ionicons.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
	<link rel="stylesheet" type="text/css" href="css/owl.theme.default.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">

</head>
<body class="home-page" id="home-page"> 

	<!-- MAIN HEADER SECTION STARTS -->

	<header id="main-header">

		<nav class="navbar navbar-default" id="n-main-nav">
		  <div class="container">
		  
		    <div class="navbar-header">
		      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#n-navbar" aria-expanded="false">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		      </button>

		      <a class="navbar-brand" href="index.html"><i class="fa fa-apple"> </i> Change AppleId </a>

		    </div>
	  
		    <div class="collapse navbar-collapse" id="n-navbar">

			    <ul class="nav navbar-nav navbar-right">
					<li class="active"><a href="#home-page">Home <span class="sr-only">(current)</span></a></li>
					<li><a href="#about">About Us</a></li>
					<li><a href="#services">Services</a></li>
					<li><a href="#contact-us">Contact</a></li>
				</ul>
		    </div>
		  </div>
		</nav> 
	</header> <!-- MAIN HEADER ENDS -->