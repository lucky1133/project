	
	<!-- INTRO SECTION STARTS -->

	<section class="section-block intro p-row" id="intro">
		<div class="container">
			<div class="row">

				<div class="section-title-block">
					<h3 class="section-title">Disclaimer</h3>
				
				</div> <!-- .section-title-block ends -->

				<div class="col-md-12 intro-content">
					<p class="text-justify">
							Change AppleId is a total independent and completely autonomous technical service provider. We provide technical support for all the major vendors and third party products. The third party trademarks, logos, names of the brands and the products have been given for information purpose only and we in no means are advocating any affiliation or connection to any of the product or brand. Neither do we sponsor any product any brand or any service. Hence Change AppleId does not claim any sponsorship by any of the third party. If your product is under warranty, the repair service maybe available free from the brand owner.
						</p>						
				</div> <!-- .intro-content ends -->
			</div> 
		</div> 
	</section> <!-- INTRO SECTION ENDS -->
	
	
	 <!-- Disclaimer -->
        <section id="disclaimer">
           <div class="container">
              <div class="row">
                <div class="col-md-12">
                <span> Disclaimer </span>
                    <p>Change AppleId is a total independent and completely autonomous technical service provider. We provide technical support for all the major vendors and third party products. </p>
                </div>
              </div>
           </div>
		</section>
        <!-- End Of Dislaimer -->
