<?php 
class Home extends Controller
{
	function  index()
	{
		$this->insert("table",array("fname"=>"sukh"));
		$this->layout("home");
	}
	
	function  about()
	{
		$this->layout("about");
	}
	
	function  disclaimer()
	{
		$this->layout("disclaimer");
	}
}
?>