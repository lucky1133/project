<?php
	session_start();
	
	if(!$_SESSION['username'])
	{
		header ("LOCATION: http://localhost/student/login.php");
	}
	
	include('connection.php');
	
	if(isset($_POST['submit']))
	{
		$student_name = ucfirst($_POST['user_name']);
		$first_name = ucfirst($_POST['first_name']);
		$last_name = ucfirst($_POST['last_name']);
		$father_name = ucfirst($_POST['father_name']);
		$school_name = ucfirst($_POST['school_name']);
		$roll_no = $_POST['roll_no'];
		$class = $_POST['class'];
		
		$sql = "select * from user_reg where u_name='$student_name'";
		$query = mysqli_query($con,$sql);
		$count = mysqli_num_rows($query);
		
		if($count==0)
		{
			mysqli_query($con,"insert into user_reg (u_name,first_name,last_name,f_name,s_name,r_no,u_class) VALUES ('$student_name','$first_name','$last_name','$father_name','$school_name','$roll_no','$class')") or die (mysqli_error($con));
			
			$msg = "Submitted";
		}
		
		else
		{
			$msg =  "User Name Alrady Exixts";
		}
		
		/* mysqli_close($con); = Connection Closed String */
	}
?>

<!Doctype HTML>
<html>
<head>
	
	<title> Student Registration </title>
	
	<style>
		h2
		{
			font-size:18px;
			color:green;
		}
		
		.abc
		{
			color:red;
		}
		
	</style>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	
	<script>
		$(document).ready(function(){
			$('#submit').click(function(){
				
				if($('#user_name').val()=="")
				{
					$('#user_name').focus();
					//$('#user_name').after(" <span class='abc'> Please Enter Username </span> ");
					//$('#user_name').css({'border-color' : 'red'});
					alert('Please Enter Username');
					return false;
				}
				
				if($('#f_name').val()=="")
				{
					$('#f_name').focus();
					alert('Please Enter First Name');
					return false;
				}
				
				if($('#l_name').val()=="")
				{
					$('#l_name').focus();
					alert('Please Enter Last Name');
					return false;
				}
				
				if($('#fa_name').val()=="")
				{
					$('#fa_name').focus();
					alert('Please Enter Father Name');
					return false;
				}
				
				if($('#s_name').val()=="")
				{
					$('#s_name').focus();
					alert('Please Enter School Name');
					return false;
				}
				
				if($('#r_no').val()=="")
				{
					$('#r_no').focus();
					alert('Please Enter Roll No');
					return false;
				}
				
				if(!$.isNumeric($('input#r_no').val())) {
					
					alert("All the text boxes must have numeric values!");
					
					return false;
				}
					
				if($('#class').val()=="")
				{
					$('#class').focus();
					alert('Please Enter Class');
					return false;
				}
				
			});
		});
	</script>
	
</head>

<body>
<form method="post" action="user_reg.php">
	<table border="1" align="center" style="border-collapse:collapse;" cellpadding="5px">
		<tr>
			<th colspan="2"> <a href="logout.php"> Logout </a>  </th>
		</tr>
		<tr>
			<th> <h2> Student't Registration Form </h2> </th>
			<th> Welcom : <?php echo $_SESSION['login']; ?> </th>
		</tr>
		
		<tr>
			<td> User Name </td>
			<td> <input type="text" id="user_name" name="user_name" > </td>
		</tr>
		<tr>
			<td> First Name </td>
			<td> <input type="text" id="f_name" name="first_name" />  </td>
		</tr>
		<tr>
			<td> Last Name </td>
			<td> <input type="text" id="l_name" name="last_name" />  </td>
		</tr>
		
		<tr>
			<td> Father Name </td>
			<td> <input type="text" id="fa_name" name="father_name" />  </td>
		</tr>
		
		<tr>
			<td> School Name </td>
			<td> <input type="text" id="s_name" name="school_name" />  </td>
		</tr>
		
		<tr>
			<td> Roll No. </td>
			<td> <input type="text" id="r_no" name="roll_no" /> </td> 
		</tr>
		
		<tr>
			<td> Class </td>
			<td> 
				<select name="class" id="class"> 
					<option value=""> Select Class </option>
					<option value="10th"> 10th </option>
					<option value="9th"> 9th </option>
					
				</select> 
	
			</td>
		</tr>
		
		<tr>
			<td colspan="2" align="center"> 
			<button type="submit" id="submit" name="submit" value="Submit" > Submit </button>
			</td>
		</tr>
		
		<tr>
			<td colspan="2" align="center"> <p style="color:red;"> <?php if(isset($msg)){ echo $msg; } ?> <p> </td>
		</tr>
		
		
	<table>
</form>


</body>
</html> 