<?php ob_start();

	include('connection.php');
	session_start();
	
	if(!$_SESSION['username'])
	{
		header ("LOCATION: http://localhost/student/login.php");
	}
	
?>
<!Doctype HTML>
<html>
<head>
	<title> View Record </title>
	
	<style>
		h2
		{
			font-size:18px;
			color:green;
		}
		
	</style>
</head>

<body>
<form method="post" action="user_reg.php">
	<table border="1" align="center" style="border-collapse:collapse;" cellpadding="8px">
		<tr>
			<th colspan="10"> <h2> View Record </h2>  </th>
		</tr>
		
		<tr>
		
			<th> Sr No. </th>
			<th> Username </th>
			<th> First Name </th>
			<th> Last Name </th>
			
			<th> Father Name </th>
			<th> School Name </th>
			<th> Roll No. </th>
			<th> Class </th>
			<th> Delete </th>
			<th> Edit </th>
		</tr>
		
		<?php 
			$query = "select * from user_reg order by id asc";
			$sql = mysqli_query($con,$query);
			$check = mysqli_num_rows($sql);
			$c = "";
			if ($check > 0)
			{
				while($row = mysqli_fetch_assoc($sql))
				{
					$c++;
					$id = $row['id'];
					$f_name = $row['first_name'];
					$l_name = $row['last_name'];
					$user_name = $row['u_name'];
					$fa_name = $row['f_name'];
					$school_name = $row['s_name'];
					$roll_no = $row['r_no'];
					$class = $row['u_class'];
				
		?>
		
		<tr> 
			<td> <?php echo $c; ?> </td>
			<td> <?php echo $user_name; ?> </td>
			<td> <?php echo $f_name; ?> </td>
			<td> <?php echo $l_name; ?> </td>
			
			<td> <?php echo $fa_name; ?> </td>
			<td> <?php echo $school_name; ?> </td>
			<td> <?php echo $roll_no; ?> </td>
			<td> <?php echo $class; ?> </td>
			<td> <a href="?id=<?php echo $id; ?>" onclick="if(!confirm('are you sure!')){ return false; };" >Delete</a> </td>
			<td> <a href="edit.php?id=<?php echo $id; ?>">Edit</a> </td>
			
		</tr>
		
		<?php 
			}}
			
			else
			{
				echo "Here is no Value";
			}
		?>
	
	</table>
</form>
</body>
</html> 

<?php
	if(@$_GET['id']!="")
	{
		$id=$_GET['id'];
		$sql = "delete from user_reg where id='$id'";
		
		if (mysqli_query($con, $sql)) 
		{
			echo "Record deleted successfully";
			header("location:http://localhost/student/view_record.php");
		}
			
		else 
		{
			echo "Error deleting record: ".mysqli_error($con);
		}
	}
?>

