<?php 

	include('connection.php');

	
?>
<!Doctype HTML>
<html>
<head>
	<title> View Record </title>
	<link rel="stylesheet" href="theme.default.min.css" />
	<style>
		h2
		{
			font-size:18px;
			color:green;
		}
		
	</style>
	
	
	<script src="jquery-1.2.6.min.js"></script>
	<script src="jquery.tablesorter.min.js"></script>

	<script>
	$(function(){
		$('table').tablesorter({
			widgets        : ['zebra', 'columns'],
			usNumberFormat : false,
			sortReset      : true,
			sortRestart    : true
		});
	});
	</script>
</head>

<body>
<form method="post" action="user_reg.php">
 <center> <h1> Filter </h1>  </center>
	<table class="tablesorter">
		<thead>
		
		<tr>
		
			<th> Sr No. </th>
			<th> Username </th>
			<th> First Name </th>
			<th> Last Name </th>
			
			<th> Father Name </th>
			<th> School Name </th>
			<th> Roll No. </th>
			<th> Class </th>
		
		</tr>
		</thead>
		<tbody>
		<?php 
			$query = "select * from user_reg order by id asc";
			$sql = mysqli_query($con,$query);
			$check = mysqli_num_rows($sql);
			$c = "";
			if ($check > 0)
			{
				while($row = mysqli_fetch_assoc($sql))
				{
					$c++;
					$id = $row['id'];
					$f_name = $row['first_name'];
					$l_name = $row['last_name'];
					$user_name = $row['u_name'];
					$fa_name = $row['f_name'];
					$school_name = $row['s_name'];
					$roll_no = $row['r_no'];
					$class = $row['u_class'];
				
		?>
		
		<tr> 
			<td> <?php echo $c; ?> </td>
			<td> <?php echo $user_name; ?> </td>
			<td> <?php echo $f_name; ?> </td>
			<td> <?php echo $l_name; ?> </td>
			
			<td> <?php echo $fa_name; ?> </td>
			<td> <?php echo $school_name; ?> </td>
			<td> <?php echo $roll_no; ?> </td>
			<td> <?php echo $class; ?> </td>
			
			
		</tr>
		
		<?php 
			}}
			
			else
			{
				echo "Here is no Value";
			}
		?>
		</tbody>
	
	</table>
</form>


</body>
</html> 

