<?php 
include('connection.php');

	if(isset($_POST['submit']))
	{
		//echo "<pre>"; print_r($_POST);
		
		$title = $_POST['title'];
		$content = $_POST['content'];
		$url = $_POST['url'];
		
		//print_r($title);
		
		for($i=0;$i<count($title);$i++)
		{
			if($title[$i]!="" && $content[$i]!="" && $url[$i]!="")
			{
			$query ="insert into blog (title,content,url) VALUES ('$title[$i]','$content[$i]','$url[$i]')";
			mysqli_query($con,$query) or die(mysqli_error($con));
			}
		}
		
		
		
	}
	
?>
<style type="text/css">
    table{
        width: 30%;
		margin-top:25px;
        border-collapse: collapse;
	
    }
	table tr th,td
	{
		padding:10px;
	}

</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
	$(document).ready(function(){
		var c=0;
		$(".add-row").click(function(){
			c++;
			if(c<=10)
			{
			var html = "<tr> <td> <input type='text' name='title[]'  placeholder='Enter Title'> </td><td> <input type='text' name='content[]' placeholder='Enter Content'> </td><td> <input type='text' name='url[]' placeholder='Enter URL'> </td><td colspan='3' align='center' > <input type='button' onClick='$(this).closest(\"tr\").remove();' class='add-row' value='Remove'></td></tr>";
			
			$("#tab").append(html);
			}
			else
			{
				alert("Only 10 Enter Allowed");
				return false;
			}
		});
	});
</script>
<form method="post">
 <table border="1" align="center">
		
			 <tr>
				<th> Title </th>
				<th> Content </th>
				<th> URL </th>
				<th> Action </th>
            </tr>
       
            <tr>
                <td> <input type='text' name="title[]" placeholder="Enter Title">  </td>
				<td> <input type='text' name="content[]" placeholder="Enter Content">  </td>
				<td> <input type='text' name="url[]" placeholder="Enter URL">  </td>
				<td colspan="3" align="center" >
				 <input type='button'  class='add-row' value='Add Row'>
				</td>
            </tr>
			<tbody id="tab">
				
			</tbody>
			
			<tr>
              	<td colspan="4" align="center" >
				 <input type='submit'  class='add-row' name="submit" value='Save'>
				</td>
            </tr>
				
		
    </table></form>