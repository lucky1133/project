<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<?php
	include('connection.php');
	
	$id = $_GET['id'];
	
	if(isset($_POST['submit']))
	{
		
		$user_name = ucfirst(@$_POST['user_name']);
		$first_name = ucfirst(@$_POST['first_name']);
		$last_name = ucfirst(@$_POST['last_name']);
		$father_name = ucfirst(@$_POST['father_name']);
		$school_name = ucfirst(@$_POST['school_name']);
		$roll_no = @$_POST['roll_no'];
		$class = @$_POST['class'];
		
		$sql="update user_reg SET u_name='$user_name',first_name='$first_name',last_name='$last_name',f_name='$father_name',s_name='$school_name',r_no='$roll_no',u_class='$class' where id='$id' ";
		mysqli_query($con,$sql) or die (mysqli_error($con));
		
		//header("location:http://localhost/student/view_record.php");?>
		
		<script>
		$(document).ready(function(){
			//alert();
			$("#edit").hide();
			$(".loader").show();
			
			setTimeout(function(){
				window.location.href = 'http://localhost/student/view_record.php';
			}, 3000);
		});
		</script>
		
		<?php
			
	}
		$sql = "select * from user_reg where id='$id'";
		$query = mysqli_query($con,$sql);
		$row = mysqli_fetch_assoc($query);
?>

<!Doctype HTML>
<html>
<head>
	
	<title> Student Registration </title>
	
	<style>
		h2
		{
			font-size:18px;
			color:green;
		}
		
		.abc
		{
			color:red;
		}
		
		.loader {
		  border: 16px solid #f3f3f3;
		  border-radius: 50%;
		  border-top: 16px solid blue;
		  border-bottom: 16px solid blue;
		  width: 120px;
		  height: 120px;
		  -webkit-animation: spin 2s linear infinite;
		  animation: spin 2s linear infinite;
		}

		@-webkit-keyframes spin {
		  0% { -webkit-transform: rotate(0deg); }
		  100% { -webkit-transform: rotate(360deg); }
		}

		@keyframes spin {
		  0% { transform: rotate(0deg); }
		  100% { transform: rotate(360deg); }
		}
		
	</style>
	
	
</head>

<body>

<div class="loader" style="display:none;"></div>

<form method="post" id="edit">
	<table border="1" align="center" style="border-collapse:collapse;" cellpadding="5px">
		<tr>
			<th colspan="2"> <h2> Student't Registration Form </h2> </th>
		</tr>
		
		<tr>
			<td> User Name </td>
			<td> <input type="text" id="user_name" name="user_name" value="<?php echo @$row['u_name']; ?>" > </td>
		</tr>
		<tr>
			<td> First Name </td>
			<td> <input type="text" id="f_name" name="first_name" value="<?php echo @$row['first_name']; ?>"   />  </td>
		</tr>
		<tr>
			<td> Last Name </td>
			<td> <input type="text" id="l_name" name="last_name" value="<?php echo @$row['last_name']; ?>"  />  </td>
		</tr>
		
		<tr>
			<td> Father Name </td>
			<td> <input type="text" id="fa_name" name="father_name" value="<?php echo @$row['f_name']; ?>"  />  </td>
		</tr>
		
		<tr>
			<td> School Name </td>
			<td> <input type="text" id="s_name" name="school_name" value="<?php echo @$row['s_name']; ?>"  />  </td>
		</tr>
		
		<tr>
			<td> Roll No. </td>
			<td> <input type="text" id="r_no" name="roll_no" value="<?php echo @$row['r_no']; ?>"  /> </td> 
		</tr>
		
		<tr>
			<td> Class </td>
			<td> 
				<select name="class" id="class"> 
					<option value=""> Select Class </option>
					<option value="10th"> 10th </option>
					<option value="9th"> 9th </option>
					
				</select> 
	
			</td>
		</tr>
		
		<tr>
			<td colspan="2" align="center"> 
			<button type="submit" id="submitss" name="submit" value="Submit" > Submit </button>
			</td>
		</tr>
		
		<tr>
			<td colspan="2" align="center"> <p style="color:red;"> <?php if(isset($msg)){ echo $msg; } ?> <p> </td>
		</tr>
		
		
	<table>
</form>

</body>
</html> 

