<?php
	$host = "localhost";
	$username = "root";
	$password = "";
	$db_name = "students";
	$con = mysqli_connect($host,$username,$password);
	mysqli_select_db($con,$db_name);
?>