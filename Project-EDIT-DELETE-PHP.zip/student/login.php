<?php
	session_start();

	include("connection.php");
	
	if(isset($_POST['submit']))
	{
		$username = $_SESSION['username'] = $_POST['username'];
		$password = $_POST['password'];
		
		$query = "select * from admin where admin='$username' and pass='$password'";
		$sql = mysqli_query($con,$query);
		$count = mysqli_num_rows($sql);
		if($count > 0)
		{	
		
			header("location: http://localhost/student/user_reg.php");
		}
		
		else
		{
			echo "Password Incorrect";
		}
	}
?>

<DOCTYPE Html>
<html>
<head>


</head>

<body>


<center>
<h3> Admin Login </h3>
<form action="login.php" method="post">
	<input type="text" name="username"> <br> <br>
	<input type="password" name="password"> <br> <br>
	<input type="submit" name="submit" value="Submit"/>
</form>
</center;

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"> </script>
</body>
</html>