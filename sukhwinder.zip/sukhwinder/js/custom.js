(function($){
   "use strict"   
    var LUCKY = {};

    /*--------------------
      * Pre Load
    ----------------------*/
    LUCKY.WebLoad = function(){
      document.getElementById("loading").style.display = "none"; 
    }

    /*--------------------
        * Menu Close
    ----------------------*/
    LUCKY.MenuClose = function(){
      $(".toggler-menu").on('click', function(){
        $(this).toggleClass('open');
        $('.nav_menu').stop().toggleClass('menu-open');
        $('.nav_menu .navbar-nav').toggleClass('nav-open');
      });
    }

    /*--------------------
        * Menu Close
    ----------------------*/
    LUCKY.MenuClose01 = function(){
      $('.navbar-nav .nav-link').on('click', function() {
       var toggle = $('.navbar-toggler').is(':visible');
       if (toggle) {
         $('.navbar-collapse').collapse('hide');
       }
      });
    }


    /*--------------------
        * Smooth Scroll
    ----------------------*/
    LUCKY.HeaderScroll = function(){
        $('a[href*="#"]:not([href="#"])').on('click', function() {
            if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') || location.hostname == this.hostname) {
              var target = $(this.hash);
                  target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
                  if (target.length) {
                    $('html,body').animate({
                      scrollTop: target.offset().top - 0,
                      }, 1000);
                      return false;
                  }
            }
        });
    }

    /*--------------------
        * Header Fixed
    ----------------------*/
    LUCKY.HeaderFixed = function(){
        if ($(window).scrollTop() >= 60) {
           $('.navbar').addClass('fixed-header');
        }
        else {
           $('.navbar').removeClass('fixed-header');
        }
    }    

    /*--------------------
        * Progress Bar 
    ----------------------*/
    LUCKY.ProgressBar = function(){
        $(".progress .progress-bar").each(function () {
          var bottom_object = $(this).offset().top + $(this).outerHeight();
          var bottom_window = $(window).scrollTop() + $(window).height();
          var progressWidth = $(this).attr('aria-valuenow') + '%';
          if(bottom_window > bottom_object) {
            $(this).css({
              width : progressWidth
            });
          }
        });
    }

    

    /*--------------------
    * Isotope
    ----------------------*/
    LUCKY.MasoNry = function () {
      var portfolioWork = $('.portfolio-content');
        $(portfolioWork).isotope({
            resizable: false,
            itemSelector: '.portfolio-item',
            layoutMode: 'masonry',
            filter: '*'
          });
          //Filtering items on portfolio.html
          var portfolioFilter = $('.filter li');
          // filter items on button click
          $(portfolioFilter).on( 'click', function() {
            var filterValue = $(this).attr('data-filter');
            portfolioWork.isotope({ filter: filterValue });
          });
          //Add/remove class on filter list
          $(portfolioFilter).on( 'click', function() {
            $(this).addClass('active').siblings().removeClass('active');
          });
    }

    
    /*--------------------
    * owl Slider
    ----------------------*/
    LUCKY.ProjectSlider = function(){
      var project_slider = $('#project-slider-single');
        project_slider.owlCarousel({
            loop: true,
            margin: 0,
            nav:false,
            responsive: {
              0: {
                items: 1
              },
              768: {
                items: 1
              },
              991: {
                items: 2
              },
              1140: {
                items: 3
              }
            }
        });
    }

    

    

    LUCKY.LightboxGallery = function(){
      $('.portfolio-col').magnificPopup({
          delegate: '.lightbox-gallery',
          type: 'image',
          tLoading: '#%curr%',
          mainClass: 'mfp-fade',
          fixedContentPos: true,
          closeBtnInside: true,
          gallery: {
              enabled: true,
              navigateByImgClick: true,
              preload: [0, 1] // Will preload 0 - before current, and 1 after the current image
          }
      });
    }

    LUCKY.mTypeIt = function() {
        new TypeIt('#type-it', {
            speed: 200,
            loop:true,
            strings: [
              'DESIGNER',
              'DEVELOPER'
            ],
            breakLines: false
        }); 
    }

    
    // Window on Load
    $(window).on("load", function(){
      LUCKY.WebLoad();
    });

    $(document).on("ready", function(){
        LUCKY.MasoNry(),
        LUCKY.MenuClose(),
        LUCKY.MenuClose01(),
        LUCKY.ProgressBar(),
        LUCKY.HeaderScroll(),
        LUCKY.LightboxGallery(),
        LUCKY.mTypeIt();
    });

    $(window).on("scroll", function(){
        LUCKY.ProgressBar(),
        LUCKY.HeaderFixed();
    });

})(jQuery);
