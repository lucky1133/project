<?php include('inc/header.php'); ?>  
<style>
	header
	{
		display: none;
	}	
</style>

<div class="container login_formn">
    <div class="row align-items-center h-100vh">
      <div class="col-sm-9 col-md-7 col-lg-5 my-auto mx-auto">
        <div class="card card-signin my-5">
          <div class="card-body">
          	<h3 class="badge badge-info newbdg">Authorization required</h3>
            <h5 class="card-title text-center">Please enter your login details</h5>
            <form class="form-signin">
              <div class="form-label-group">
                <input type="email" id="inputEmail" class="form-control" placeholder="Email address" required autofocus>
                <label for="inputEmail">Username</label>
              </div>

              <div class="form-label-group">
                <input type="password" id="inputPassword" class="form-control" placeholder="Password" required>
                <label for="inputPassword">Password</label>
              </div>

              <div class="custom-control custom-checkbox mb-3">
                <input type="checkbox" class="custom-control-input" id="customCheck1">
                <label class="custom-control-label" for="customCheck1">Remember password</label>
              </div>
              <button class="btn btn-lg btn-primary btn-block text-uppercase" type="submit">LOGIN</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php include('inc/footer.php'); ?>