      <!-- Footer -->
 
      <!-- End Of Footer -->

      <!-- jQuery Javascript -->
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script src="js/custom.js"></script>
   </body>
</html>