<?php
ob_start();
session_start();
include("functions.php"); 
define("ROW_PER_PAGE",2);
$row=$lib->getData("user");
if(@$_GET['action']=="delete")
{
	$lib->delete("user",$_GET['id']);
	header("location:http://localhost/email-form/view_all.php");
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse nav">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <a class="navbar-brand" href="index.php">LOGO</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href=""> Welcome: <?php echo @$_SESSION['userdata']['email']; ?>  </a></li>
        <li><a href="http://localhost/email-form/index.php"><span class="glyphicon glyphicon-user"></span> Add New Row </a></li>
        <li><a href="http://localhost/email-form/view_all.php"><span class="glyphicon glyphicon-log-in"></span> View All </a></li>
      </ul>
    </div>
  </div>
</nav>



<div class="container">
  <div class="row">
	<table class="table table-bordered">
	<tr>
		<th>Sr.no</th>
		<th>Name</th>
		<th>Email</th>
		<th>Phone</th>
		<th>Edit</th>
		<th>Delete</th>
	</tr>
	<?php $c=""; 
	
		foreach($row as $row){ 
		
		$c++;
	?>
	<tr>
		<td><?php echo $c; ?></td>
		<td><?php echo $row['name']; ?></td>	
		<td><?php echo $row['email']; ?></td>	
		<td><?php echo $row['phone']; ?></td>
		<td><a href="edit.php?id=<?php echo $row['id']; ?>">Edit</a></td>
		<td><a href="http://localhost/email-form/view_all.php?action=delete&id=<?php echo $row['id']; ?>">Delete</a></td>
	</tr>
	<?php } ?>
  </table>
  </div>
  
  <div class="container text-center">
	<ul class="pagination ">
		<li class="disabled"><a href="#">«</a></li>
		<li class="active"><a href="#">1 <span class="sr-only">(current)</span></a></li>
		<li><a href="#">2</a></li>
		<li><a href="#">3</a></li>
		<li><a href="#">4</a></li>
			<li><a href="#">»</a></li>
    </ul>
   </div>

   
</div>

</body>
</html>


