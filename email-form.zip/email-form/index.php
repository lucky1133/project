<?php include("functions.php"); 
if(isset($_POST['submit']))
{
	$row=$lib->query("select * from user where email='".$_POST['user']['email']."'");
	
	$count=$row->rowCount();
	if($count==0)
	{
	$lib->insert($_POST['user'],"user");
	}
	else
	{
		echo "Already added email!";
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<body>
<a href="http://localhost/email-form/index.php">Add New Row</a>
<a href="http://localhost/email-form/view_all.php">View All</a>
<div class="container">
  <div class="row">
		<div class="login">
			<h1>Login</h1>
				<form action="" method="post">
					
						<input type="text" class="form-control" id="name" placeholder="Enter Your Name" name="user[name]">
						<input type="email" class="form-control" id="email" placeholder="Enter email" name="user[email]">
						<input type="text" class="form-control" id="number" placeholder="Enter Phone Number" name="user[phone]">
						<button type="submit" class="btn btn-primary btn-block btn-large" name="submit">Submit</button>
					
				</form>
		</div>
		
	</div>
</div>

</body>
</html>
