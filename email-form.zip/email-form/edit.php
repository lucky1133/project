<?php include("functions.php"); 
if(isset($_POST['submit']))
{
	$lib->update($_POST['user'],"user",$_GET['id']);
}
$row=$lib->getDataByID("user",$_GET['id']);
//print_r($row);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<a href="http://localhost/email-form/index.php">Add New Row</a>
<a href="http://localhost/email-form/view_all.php">View All</a>
<div class="container">
  <div class="row">
	<form action="" method="post">
	<div class="col-md-10 col-md-offset-1">
		<h1 class="text-center"> Form </h1>
	
		<div class="form-group">
		  <label class="control-label col-sm-2" for="email">Name:</label>
		  <div class="col-sm-10">
			<input type="text" class="form-control" id="name" placeholder="Enter Your Name" value="<?php echo $row['name']; ?>" name="user[name]">
		  </div>
		</div>
		
		<div class="form-group">
		  <label class="control-label col-sm-2" for="email">Email:</label>
		  <div class="col-sm-10">
			<input type="email" class="form-control" id="email" placeholder="Enter email" value="<?php echo $row['email']; ?>" name="user[email]">
		  </div>
		</div>
		
		<div class="form-group">
		  <label class="control-label col-sm-2" for="number">Phone Number:</label>
		  <div class="col-sm-10">          
			<input type="text" class="form-control" id="number" placeholder="Enter Phone Number" value="<?php echo $row['phone']; ?>" name="user[phone]">
		  </div>
		</div>
	   
		<div class="form-group">        
		  <div class="col-sm-offset-2 col-sm-10">
			<button type="submit" class="btn btn-default" name="submit">Submit</button>
		  </div>
		</div>
	
	 </div>
	</form>
	</div>
</div>

</body>
</html>
