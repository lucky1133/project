<?php 
	session_start();
	$con = mysqli_connect("localhost","root","","employee_crm");
	if($con)
	{
		//echo "Connected Successfull" or die ("Error".mysqli_error());
	}

?>