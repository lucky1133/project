<?php
	
	include("connection.php");

	if(isset($_SESSION['user']))
   {
      $user = $_SESSION['user'];
   }

   else
   {
      header("Location: login.php");
   }
	
	if(!empty($_POST))
	{
		extract($_POST);
		$query = "INSERT INTO `tasks` SET uid=".$user['uid'].", `task`='$task',`start_time`='$start_time',`end_time`='$end_time'";
		if(mysqli_query($con,$query))
		{
			header("Location: index.php");
		}
		
		else
		{
			echo "Error".mysqli_error($con);
		}
	}
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" >
	<link rel="stylesheet" type="text/css" href="css/material-design-iconic-font.min.css">
   
	<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
	<link href="https://unpkg.com/gijgo@1.9.11/css/gijgo.min.css" rel="stylesheet" type="text/css" />
	 <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/util.css">

    <title>Employee</title>
  </head>
  <body>
 
    <div class="limiter">
		<div class="container-login100" >
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">
				<form class="login100-form validate-form add-aa" method="post">
					<div class="d-flex m-b-23">
						<a href="index.php" class="btn btn-primary" style="margin-right: 25px;">Back</a>
						<span class="login100-form-title">
							Daily TASK
						</span>
					</div>

					<div class="wrap-input100 validate-input m-b-23" data-validate = "Username is reauired">
						<span class="label-input100">Task</span>
						<textarea class="input100" name="task" placeholder="Enter Your Task" required></textarea>
		
					</div>

					<div class="wrap-input100 validate-input m-b-23" data-validate="Password is required" style="border-bottom:none;">
						<span class="label-input100">Start Time</span>
						<input class="input100" id="timepicker" name="start_time" required pattern="([01]?[0-9]|2[0-3]):[0-5][0-9]" title="Time 24 format(23:30)"/>
					</div>
					
					<div class="wrap-input100 validate-input" data-validate="Password is required" style="border-bottom:none;">
						<span class="label-input100">End Time</span>
						<input class="input100" id="timepicker1" name="end_time" required pattern="([01]?[0-9]|2[0-3]):[0-5][0-9]" title="Time 24 format(23:30)" />
					</div>
					
					<div class="text-right p-t-8 p-b-31">
						
					</div>
					
					<div class="d-flex justify-content-center ">
						<button class="btn btn-success" style="margin-right:20px;">
							SAVE
						</button>
						<a href="index.php" class="btn btn-danger">
							CANCEL
						</a>
					</div>
		
				</form>
			</div>
		</div>
	</div>

    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
	<script src="https://unpkg.com/gijgo@1.9.11/js/gijgo.min.js" type="text/javascript"></script>
	
	<script>
        $('#timepicker').timepicker({
            uiLibrary: 'bootstrap4'
        });
		$('#timepicker1').timepicker({
            uiLibrary: 'bootstrap4'
        });
    </script>
  </body>
</html>