<?php
	include("connection.php");
	if(isset($_SESSION['user']))
    {
      $user = $_SESSION['user'];
    }

    else
    {
      header("Location: login.php");
    }


	if(!empty($_GET['delid']))
	{
		$tid = $_GET['delid'];
		$query = "DELETE from tasks where tid=$tid ";
		if(mysqli_query($con,$query))
		{
			header("Location: index.php");
		}
		
		else
		{
			echo "Error".mysqli_error($con);
		}
	}

?>