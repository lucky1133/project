<?php
	
	include("connection.php");

	if(isset($_SESSION['user']))
   {
      $user = $_SESSION['user'];
   }

   else
   {
      header("Location: login.php");
   }

   	if(isset($_GET['uid']) and trim($_GET['uid']) != ''){
		$uid = trim($_GET['uid']);
		$query = "SELECT * FROM users WHERE uid=$uid;";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		if(!$row){
			echo 'Not found'; exit;
		}
	}else {
		echo 'Not found'; exit;
	}


	
	if(!empty($_POST))
	{
		extract($_POST);
		$query = "UPDATE `users` SET uid=".$user['uid'].", `name`='$email',`email`='$email',`password`='$password' WHERE uid=".$uid." ";
		if(mysqli_query($con,$query))
		{
			header("Location: usres.php");
		}
		
		else
		{
			echo "Error".mysqli_error($con);
		}
	}
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" >
	<link rel="stylesheet" type="text/css" href="css/material-design-iconic-font.min.css">
   
	<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
	<link href="https://unpkg.com/gijgo@1.9.11/css/gijgo.min.css" rel="stylesheet" type="text/css" />
	 <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/util.css">

    <title>Employee</title>
  </head>
  <body>
 
    <div class="limiter">
		<div class="container-login100" style="background-image: url('images/bg-01.jpg');">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">
				<form class="login100-form validate-form" action="" method="post">
					<div class="d-flex m-b-23">
						<a href="index.php" class="btn btn-primary" style="margin-right: 25px;">Back</a>
						<span class="login100-form-title">
							Add User
						</span>
					</div>

					<div class="wrap-input100 validate-input m-b-23" data-validate = "Name is reauired">
						<span class="label-input100">Name</span>
						<input class="input100" type="text" name="name" placeholder="Type your Name" required value="<?php echo $row['name']; ?>" />
						<span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>
					
					<div class="wrap-input100 validate-input m-b-23" data-validate="Email is required">
						<span class="label-input100">Email</span>
						<input class="input100" type="email" name="email" placeholder="Type your Email" required value="<?php echo $row['email']; ?>" />
						<span class="focus-input100" data-symbol="&#xf190;"></span>
					</div>
					
					<div class="wrap-input100 validate-input" data-validate="Password is required">
						<span class="label-input100">Password</span>
						<input class="input100" type="password" name="pass" placeholder="Type your password" required>
						<span class="focus-input100" data-symbol="&#xf190;"></span>
					</div>
					
					<div class="text-right p-t-8 p-b-31">
						
					</div>
					
					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn">
								Save
							</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>

    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
	<script src="https://unpkg.com/gijgo@1.9.11/js/gijgo.min.js" type="text/javascript"></script>
	
	<script>
        $('#timepicker').timepicker({
            uiLibrary: 'bootstrap4'
        });
		$('#timepicker1').timepicker({
            uiLibrary: 'bootstrap4'
        });
    </script>
  </body>
</html>