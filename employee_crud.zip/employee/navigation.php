<?php
 if(isset($_SESSION['user']))
 {
    $user = $_SESSION['user'];
 }
?>

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <a class="navbar-brand" href="index.php">Employee</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
     
      <ul class="nav navbar-nav">
        <?php if($user['role'] == 'admin'){?>
        <li><a href="index.php"><span class="glyphicon glyphicon-user"></span> Tasks </a></li>
        
        <li><a href="users.php"><span class="glyphicon glyphicon-log-in"></span> Users </a></li>
        <?php }?>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a><span class="glyphicon glyphicon-user"></span> Welcome: <?php echo $user['name']; ?></a></li>
        <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Sign Out</a></li>
      </ul>
    </div>
  </div>
</nav>