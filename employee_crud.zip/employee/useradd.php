<?php
	
	include("connection.php");
	if(isset($_SESSION['user']))
    {
      $user = $_SESSION['user'];
    }

    else
    {
      header("Location: login.php");
    }
	if(!empty($_POST))
	{
		extract($_POST);
		$query = "INSERT INTO `users` SET `name`='$name',`email`='$email',`password`='$pass'";
		if(mysqli_query($con,$query))
		{
			header("Location: users.php");
		}
		
		else
		{
			echo "Error".mysqli_error($con);
		}
	}
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/util.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">

    <title>Employee</title>
  </head>
  <body>


  
    <div class="limiter">
		<div class="container-login100" style="background-image: url('images/bg-01.jpg');">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">
				<form class="login100-form validate-form" action="" method="post">
					<div class="d-flex m-b-23">
						<a href="index.php" class="btn btn-primary" style="margin-right: 25px;">Back</a>
						<span class="login100-form-title">
							Add User
						</span>
					</div>

					<div class="wrap-input100 validate-input m-b-23" data-validate = "Name is reauired">
						<span class="label-input100">Name</span>
						<input class="input100" type="text" name="name" placeholder="Type your Name" required>
						<span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>
					
					<div class="wrap-input100 validate-input m-b-23" data-validate="Email is required">
						<span class="label-input100">Email</span>
						<input class="input100" type="email" name="email" placeholder="Type your Email" required>
						<span class="focus-input100" data-symbol="&#xf190;"></span>
					</div>
					
					<div class="wrap-input100 validate-input" data-validate="Password is required">
						<span class="label-input100">Password</span>
						<input class="input100" type="password" name="pass" placeholder="Type your password" required>
						<span class="focus-input100" data-symbol="&#xf190;"></span>
					</div>
					
					<div class="text-right p-t-8 p-b-31">
						
					</div>
					
					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn">
								Save
							</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>

    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	
	
	
  </body>
</html>