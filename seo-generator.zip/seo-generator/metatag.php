<?php include("header.php"); ?>
<!DOCTYPE html>
<html>
<head>
<title>Meta Tag Generator</title>



</head>
<body>

 <!DOCTYPE html>
<html>
<head>
<title></title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">


</head>
<body>


        <div class="row">
            <div class="col-lg-12">
                
               
              

                   <div class="container profile-c pro-tfn">
						<div class="row">
						
							<div class="col-md-7 col-md-offset-2 ">
							 
							 <div class="loginmodal-container">
									<h1>Add Meta Tag Details</h1>
									<br>
									<form action="metataggenerator.php" method="post">
										
										<div class="form-group">
											<label for="sel1">Site Title </label>
											<input type="text" name="title" class="login loginmodal-submit">
										</div>

										<div class="form-group">
											<label for="sel1">Site Description </label>
											<input type="text" name="description" class="login loginmodal-submit">
										</div>
										
										<div class="form-group">
											<label for="sel1">Site Keywords </label>
											<input type="text" name="Keyword" class="login loginmodal-submit">
										</div>
										
										<input type="submit" name="login" style="background-color: #1eb0bc;" class="login loginmodal-submit sky-color" value="GENERATE META TAGS">
									</form>

								</div>
							</div>
						</div>
					</div>
                </div>
            </div>
        



<?php include("footer.php"); ?>