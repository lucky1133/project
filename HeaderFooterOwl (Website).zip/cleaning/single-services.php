<?php include("inc/header.php"); ?>

  <!-- Heading Image -->
  <section class="comh2 bg-img" style="background-image: url(images/about-us.png)">
    <h2 class="text-center">House Cleaning </h2>
  </section>
  <!-- End Heading Image -->

  <!-- About Us -->
  <section class="secpad goodcus cleano">
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-sm-8">
           <h2 class="text-left">House Cleaning</h2>
           <div class="singelser">
             <img src="images/singleser.jpg" class="img-responsive singleFix" alt="" />
             <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. 
             </p>
             <h2>Service Overview</h2>
             <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
              <ul class="list-unstyled">
                 <li><i class="fa fa-check"></i> One-off, weekly or fortnightly visits </li>
                 <li><i class="fa fa-check"></i> Vetted &amp; background-checked cleaners </li>
                 <li><i class="fa fa-check"></i> Keep the same cleaner for every visit </li>
                 <li><i class="fa fa-check"></i> Book, manage &amp; pay online </li>
              </ul>
              <h2>Service Overview</h2>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
           </div>
        </div>
        <div class="col-md-4 col-sm-4 rightser">

           <h2>Our Services</h2>

            <ul class="list-group">
              <li class="list-group-item active"> 
                  <a href="#"><i class="fa fa-angle-double-right"></i> House Cleaning </a>
              </li>
              <li class="list-group-item"> 
                  <a href="#"><i class="fa fa-angle-double-right"></i> Kitchen Cleaning  </a>
              </li>
              <li class="list-group-item"> 
                  <a href="#"><i class="fa fa-angle-double-right"></i> Glass Cleaning  </a>
              </li>
              <li class="list-group-item"> 
                  <a href="#"><i class="fa fa-angle-double-right"></i> Office Cleaning  </a>
              </li>
              <li class="list-group-item"> 
                  <a href="#"><i class="fa fa-angle-double-right"></i> Residental Cleaning  </a>
              </li>
              <li class="list-group-item"> 
                  <a href="#"><i class="fa fa-angle-double-right"></i> Floor Cleaning  </a>
              </li>
            </ul>

           <div class="addBox">
              <a href="#"><img src="images/discount.png" class="img-responsive" alt="" /></a>
           </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End Of About Us -->

  <!-- About Us -->
  <section class="cleano bgblue thingsa about1">
     <div class="container">
        <div class="row">
           <div class="col-lg-7 col-md-6 col-sm-6">
              <h2 class="text-left">Have Any Query?</h2>
              <div class="row queryform">
                <div class="col-md-6">
                   <div class="form-group">
                      <input type="text" class="form-control" placeholder="Name" />
                    </div>
                </div>
                <div class="col-md-6">
                   <div class="form-group">
                      <input type="text" class="form-control" placeholder="Email" />
                    </div>
                </div>

                <div class="col-md-12">
                  <div class="form-group">
                    <textarea class="form-control" rows="5" id="comment"></textarea>
                  </div>  
                </div>
              </div>
              <a href="#" class="btn btn-info custombtn">Send Message</a>
           </div>
            <div class="col-lg-5 col-md-6 col-sm-6">
              <img src="images/things1.png" class="img-responsive mttop img100" alt="">
           </div>
        </div>
     </div>
  </section>
  <!-- End Of About Us -->

<?php include("inc/footer.php"); ?>