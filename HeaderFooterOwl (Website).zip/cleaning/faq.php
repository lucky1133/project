<?php include("inc/header.php"); ?>
<!-- Heading Image -->
<section class="comh2 bg-img" style="background-image: url(images/about-us.png)">
   <h2 class="text-center">Faq </h2>
</section>
<!-- End Heading Image -->
<!-- About Us -->
<section class="secpad faqpage">
   <h2 class="text-center"> Frequent Ask Questions </h2>
   <div class="accordion-section clearfix mt-3" aria-label="Question Accordions">
      <div class="container">
         <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
            <div class="panel panel-default">
               <div class="panel-heading p-3 mb-3" role="tab" id="heading0">
                  <h3 class="panel-title">
                     <a class="collapsed" role="button" title="" data-toggle="collapse" data-parent="#accordion" href="#collapse0" aria-expanded="true" aria-controls="collapse0">
                     Do i have to sign a contract?
                     </a>
                  </h3>
               </div>
               <div id="collapse0" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading0">
                  <div class="panel-body px-3 mb-4">
                     <p>What is Lorem Ipsum Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum has been the industry's standard dummy text ever since the 1500s when an unknown printer took a galley of type and scrambled it to make a type specimen book it has.</p>
                  </div>
               </div>
            </div>
            <div class="panel panel-default">
               <div class="panel-heading p-3 mb-3" role="tab" id="heading1">
                  <h3 class="panel-title">
                     <a class="collapsed" role="button" title="" data-toggle="collapse" data-parent="#accordion" href="#collapse1" aria-expanded="true" aria-controls="collapse1">
                     Will i always have the same house cleaner?
                     </a>
                  </h3>
               </div>
               <div id="collapse1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading1">
                  <div class="panel-body px-3 mb-4">
                     <p>What is Lorem Ipsum Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum has been the industry's standard dummy text ever since the 1500s when an unknown printer took a galley of type and scrambled it to make a type specimen book it has.</p>
                  </div>
               </div>
            </div>
            <div class="panel panel-default">
               <div class="panel-heading p-3 mb-3" role="tab" id="heading2">
                  <h3 class="panel-title">
                     <a class="collapsed" role="button" title="" data-toggle="collapse" data-parent="#accordion" href="#collapse2" aria-expanded="true" aria-controls="collapse2">
                     Do you Guatantee your work?
                     </a>
                  </h3>
               </div>
               <div id="collapse2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading2">
                  <div class="panel-body px-3 mb-4">
                     <p>What is Lorem Ipsum Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum has been the industry's standard dummy text ever since the 1500s when an unknown printer took a galley of type and scrambled it to make a type specimen book it has.</p>
                  </div>
               </div>
            </div>
            <div class="panel panel-default">
               <div class="panel-heading p-3 mb-3" role="tab" id="heading3">
                  <h3 class="panel-title">
                     <a class="collapsed" role="button" title="" data-toggle="collapse" data-parent="#accordion" href="#collapse3" aria-expanded="true" aria-controls="collapse3">
                     How Do I Reset My Password?
                     </a>
                  </h3>
               </div>
               <div id="collapse3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading3">
                  <div class="panel-body px-3 mb-4">
                       <div class="panel-group" id="accordion1" role="tablist" aria-multiselectable="true">
                           <div class="panel panel-default">
                              <div class="panel-heading p-3 mb-3" role="tab" id="headinginner0">
                                 <h3 class="panel-title">
                                    <a class="collapsed" role="button" title="" data-toggle="collapse" data-parent="#accordion1" href="#collapsee0" aria-expanded="true" aria-controls="collapsee0">
                                    How Do I Reset My Password?
                                    </a>
                                 </h3>
                              </div>
                              <div id="collapsee0" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headinginner0">
                                 <div class="panel-body px-3 mb-4">
                                    <p>What is Lorem Ipsum Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum has been the industry's standard dummy text ever since the 1500s when an unknown printer took a galley of type and scrambled it to make a type specimen book it has.</p>
                                 </div>
                              </div>
                           </div>
                           <div class="panel panel-default">
                              <div class="panel-heading p-3 mb-3" role="tab" id="headinginner1">
                                 <h3 class="panel-title">
                                    <a class="collapsed" role="button" title="" data-toggle="collapse" data-parent="#accordion1" href="#collapsee1" aria-expanded="true" aria-controls="collapsee1">
                                    How Do I Change My Account Information?
                                    </a>
                                 </h3>
                              </div>
                              <div id="collapsee1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headinginner1">
                                 <div class="panel-body px-3 mb-4">
                                    <p>What is Lorem Ipsum Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum has been the industry's standard dummy text ever since the 1500s when an unknown printer took a galley of type and scrambled it to make a type specimen book it has.</p>
                                 </div>
                              </div>
                           </div>
                        </div>
                  </div>
               </div>
            </div>
            <div class="panel panel-default">
               <div class="panel-heading p-3 mb-3" role="tab" id="heading3">
                  <h3 class="panel-title">
                     <a class="collapsed" role="button" title="" data-toggle="collapse" data-parent="#accordion" href="#collapse4" aria-expanded="true" aria-controls="collapse4">
                     How i can payment?
                     </a>
                  </h3>
               </div>
               <div id="collapse4" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading3">
                  <div class="panel-body px-3 mb-4">
                     <p>What is Lorem Ipsum Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum has been the industry's standard dummy text ever since the 1500s when an unknown printer took a galley of type and scrambled it to make a type specimen book it has.</p>
                  </div>
               </div>
            </div>
            <div class="panel panel-default">
               <div class="panel-heading p-3 mb-3" role="tab" id="heading3">
                  <h3 class="panel-title">
                     <a class="collapsed" role="button" title="" data-toggle="collapse" data-parent="#accordion" href="#collapse5" aria-expanded="true" aria-controls="collapse5">
                     Can i cleaning professionals for a month?
                     </a>
                  </h3>
               </div>
               <div id="collapse5" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading3">
                  <div class="panel-body px-3 mb-4">
                     <p>What is Lorem Ipsum Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum has been the industry's standard dummy text ever since the 1500s when an unknown printer took a galley of type and scrambled it to make a type specimen book it has.</p>
                  </div>
               </div>
            </div>
            <div class="panel panel-default">
               <div class="panel-heading p-3 mb-3" role="tab" id="heading3">
                  <h3 class="panel-title">
                     <a class="collapsed" role="button" title="" data-toggle="collapse" data-parent="#accordion" href="#collapse6" aria-expanded="true" aria-controls="collapse6">
                     Does house cleaning include laundry?
                     </a>
                  </h3>
               </div>
               <div id="collapse6" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading3">
                  <div class="panel-body px-3 mb-4">
                     <p>What is Lorem Ipsum Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum has been the industry's standard dummy text ever since the 1500s when an unknown printer took a galley of type and scrambled it to make a type specimen book it has.</p>
                  </div>
               </div>
            </div>
            <div class="panel panel-default">
               <div class="panel-heading p-3 mb-3" role="tab" id="heading3">
                  <h3 class="panel-title">
                     <a class="collapsed" role="button" title="" data-toggle="collapse" data-parent="#accordion" href="#collapse7" aria-expanded="true" aria-controls="collapse7">
                     What's your pricing plan rules?
                     </a>
                  </h3>
               </div>
               <div id="collapse7" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading3">
                  <div class="panel-body px-3 mb-4">
                     <p>What is Lorem Ipsum Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum has been the industry's standard dummy text ever since the 1500s when an unknown printer took a galley of type and scrambled it to make a type specimen book it has.</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- End Of About Us -->
<?php include("inc/footer.php"); ?>