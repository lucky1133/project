<?php include("inc/header.php"); ?>

  <!-- Heading Image -->
  <section class="comh2 bg-img" style="background-image: url(images/about-us.png)">
    <h2 class="text-center">Blog </h2>
  </section>
  <!-- End Heading Image -->

  <!-- About Us -->
  <section class="secpad goodcus cleano blogpage">
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-sm-8">
          <div class="singelser">
             <img src="images/blogbg.jpg" class="img-responsive singleFix" alt="" />
             <div class="blogdet">
                <span> 12 April 2020 </span> 
                <img src="images/admin.svg" width="20" alt="" />
                <span> By Admin </span> 
                <img src="images/comment.svg" width="20" alt="" />
                <a href="#"><span> Comment 2 </span></a> 
             </div>
             <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
             <a href="blog-single.php" class="btn btn-info custombtn">Read More</a>
          </div>

          <hr class="hrclass" />

          <div class="singelser">
             <img src="images/blogbg1.jpg" class="img-responsive singleFix" alt="" />
             <div class="blogdet">
                <span> 12 April 2020 </span> 
                <img src="images/admin.svg" width="20" alt="" />
                <span> By Admin </span> 
                <img src="images/comment.svg" width="20" alt="" />
                <a href="#"><span> Comment 2 </span></a> 
             </div>
             <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
             <a href="blog-single.php" class="btn btn-info custombtn">Read More</a>
          </div>

          <hr class="hrclass" />

          <div class="singelser">
             <img src="images/blogbg2.jpg" class="img-responsive singleFix" alt="" />
             <div class="blogdet">
                <span> 12 April 2020 </span> 
                <img src="images/admin.svg" width="20" alt="" />
                <span> By Admin </span> 
                <img src="images/comment.svg" width="20" alt="" />
                <a href="#"><span> Comment 2 </span></a> 
             </div>
             <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
             <a href="blog-single.php" class="btn btn-info custombtn">Read More</a>
          </div>

          <hr class="hrclass" />

          <div class="singelser">
             <img src="images/blogbg3.png" class="img-responsive singleFix" alt="" />
             <div class="blogdet">
                <span> 12 April 2020 </span> 
                <img src="images/admin.svg" width="20" alt="" />
                <span> By Admin </span> 
                <img src="images/comment.svg" width="20" alt="" />
                <a href="#"><span> Comment 2 </span></a> 
             </div>
             <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
             <a href="blog-single.php" class="btn btn-info custombtn">Read More</a>
          </div>

          <nav class="pagiNation">
            <ul class="pagination">
              <li class="page-item active"><a class="page-link" href="#">1</a></li>
              <li class="page-item"><a class="page-link" href="#">2</a></li>
              <li class="page-item"><a class="page-link" href="#"><i class="fa fa-angle-double-right"></i></a></li>
            </ul>
          </nav>
        </div>
        <div class="col-md-4 col-sm-4 rightser">
            
            <div class="searchri pd25 bgblue">
               <h3>Search</h3>
               <!-- Actual search box -->
               <div class="form-group has-feedback has-search">
                  <span class="fa fa-search form-control-feedback"></span>
                  <input type="text" class="form-control" placeholder="Search">
               </div>
            </div>

            <div class="searchri pd25 bgblue">
              <h3>Category</h3>
              <ul class="list-group">
                <li class="list-group-item active"> 
                    <a href="#"><i class="fa fa-angle-double-right"></i> House Cleaning (4) </a>
                </li>
                <li class="list-group-item"> 
                    <a href="#"><i class="fa fa-angle-double-right"></i> Kitchen Cleaning (3)  </a>
                </li>
                <li class="list-group-item"> 
                    <a href="#"><i class="fa fa-angle-double-right"></i> Glass Cleaning (5)  </a>
                </li>
                <li class="list-group-item"> 
                    <a href="#"><i class="fa fa-angle-double-right"></i> Office Cleaning (8)  </a>
                </li>
                <li class="list-group-item"> 
                    <a href="#"><i class="fa fa-angle-double-right"></i> Residental Cleaning (3)  </a>
                </li>
                <li class="list-group-item"> 
                    <a href="#"><i class="fa fa-angle-double-right"></i> Floor Cleaning (2)  </a>
                </li>
              </ul>
            </div>

             <div class="searchri pd25 bgblue">
               <h3>Popular Tag</h3>
               <!-- Actual search box -->
               <div class="tagspop">
                  <a href="#"><span class="badge">Floor</span> </a>
                  <a href="#"><span class="badge">Office</span> </a>
                  <a href="#"><span class="badge">Carpet</span> </a>
                  <a href="#"><span class="badge">Window</span> </a>
               </div>
            </div>

        </div>
      </div>
    </div>
  </section>
  <!-- End Of About Us -->

<?php include("inc/footer.php"); ?>