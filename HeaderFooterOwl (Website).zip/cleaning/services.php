<?php include("inc/header.php"); ?>

  <!-- Heading Image -->
  <section class="comh2 bg-img" style="background-image: url(images/about-us.png)">
    <h2 class="text-center">Our Services</h2>
  </section>
  <!-- End Heading Image -->

  <!-- About Us -->
  <section class="secpad goodcus">
    <h2 class="text-center">Provide Worldwide Service For <br> Good Customers</h2>
    <h3 class="text-center">What We Do</h3>
    <div class="container">
      <div class="row">
        <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
           <div class="iinnerowl">
             <img src="images/ser1.svg"  alt="">
             <h3>House Cleaning</h3>
             <p>Imagine coming home to a completely clean, fresh smelling home after a long day of work. If you need our help</p>
             <a href="single-services.php" class="btn btn-info custombtn">Read More</a>
           </div>
        </div>
        <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
           <div class="iinnerowl">
             <img src="images/ser2.svg"  alt="">
             <h3>Kitchen Cleaning</h3>
             <p>Imagine coming home to a completely clean, fresh smelling home after a long day of work. If you need our help</p>
             <a href="single-services.php" class="btn btn-info custombtn">Read More</a>
           </div>
        </div>
        <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
           <div class="iinnerowl">
             <img src="images/ser3.svg"  alt="">
             <h3>Glass Cleaning</h3>
             <p>Imagine coming home to a completely clean, fresh smelling home after a long day of work. If you need our help</p>
             <a href="single-services.php" class="btn btn-info custombtn">Read More</a>
           </div>
        </div>
        <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
           <div class="iinnerowl">
             <img src="images/office.svg"  alt="">
             <h3>Office Cleaning</h3>
             <p>Imagine coming home to a completely clean, fresh smelling home after a long day of work. If you need our help</p>
             <a href="single-services.php" class="btn btn-info custombtn">Read More</a>
           </div>
        </div>
        <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
           <div class="iinnerowl">
             <img src="images/residental.svg"  alt="">
             <h3>Residental Cleaning</h3>
             <p>Imagine coming home to a completely clean, fresh smelling home after a long day of work. If you need our help</p>
             <a href="single-services.php" class="btn btn-info custombtn">Read More</a>
           </div>
        </div>
        <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
           <div class="iinnerowl">
             <img src="images/floor.svg"  alt="">
             <h3>Floor Cleaning</h3>
             <p>Imagine coming home to a completely clean, fresh smelling home after a long day of work. If you need our help</p>
             <a href="single-services.php" class="btn btn-info custombtn">Read More</a>
           </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End Of About Us -->

  <!-- About Us -->
  <section class="cleano bgblue thingsa about1">
     <div class="container">
        <div class="row rowflexth">
           <div class="col-lg-6 col-md-6">
              <h2 class="text-left">Together We'll <br /> Explore New Things</h2>
              <a href="#" class="btn btn-info custombtn">Book Now</a>
           </div>
            <div class="col-lg-6 col-md-6">
              <img src="images/things.png" class="img-responsive img100" alt="">
           </div>
        </div>
     </div>
  </section>
  <!-- End Of About Us -->

<?php include("inc/footer.php"); ?>