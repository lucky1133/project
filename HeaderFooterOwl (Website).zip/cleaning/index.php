<?php include("inc/header.php"); ?>

  <!-- Slider -->
  <div class="sliderDiv">
     <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
           <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
           <li data-target="#carousel-example-generic" data-slide-to="1"></li>
           <li data-target="#carousel-example-generic" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
           <div class="item active">
              <img src="images/slidermain.png" alt="First slide">
           </div>
           <div class="item">
              <img src="images/slidermain.png" alt="Second slide">
           </div>
           <div class="item">
              <img src="images/slidermain.png" alt="Third slide">
           </div>
        </div>
     </div>
     <div class="main-text hidden-xs">
        <div class="col-md-12 text-center">
           <h1>
              Best Cleaning Service <br /> Makes The Difference
           </h1>
           <p>
              Queak company is a minority owned business with a large group of speciallytrained, dedicated employees to provide professional service
           </p>
           <div class="newfrom">
              <form>
                <div class="input-group">
                  <img src="images/location.svg" width="15">
                  <input type="text" class="form-control" placeholder="Enter Your Post Code">
                  <div class="input-group-btn">
                    <button class="btn btn-default" type="submit">
                      Book Now
                    </button>
                  </div>
                </div>
              </form>
           </div>
        </div>
     </div>
  </div>
  <!-- End Of Slider -->

  <!-- Slider Customer -->
  <section class="secpad goodcus newpadbt">
     <h2 class="text-center">Provide Worldwide Service For <br /> Good Customers</h2>
     <h3 class="text-center">What We Do</h3>
     <div class="container">
        <div class="row">
           <div class="col-md-12">
       
              <div class="carousel-wrap">
                <div class="owl-carousel">
                  <div class="item">
                     <div class="iinnerowl">
                       <img src="images/ser1.svg"  alt="">
                       <h3>House Cleaning</h3>
                       <p>Imagine coming home to a completely clean, fresh smelling home after a long day of work. If you need our help</p>
                       <a href="single-services.php" class="btn btn-info custombtn">Read More</a>
                     </div>
                  </div>
                  <div class="item">
                     <div class="iinnerowl">
                       <img src="images/ser2.svg"  alt="">
                       <h3>Kitchen Cleaning</h3>
                       <p>Imagine coming home to a completely clean, fresh smelling home after a long day of work. If you need our help</p>
                       <a href="single-services.php" class="btn btn-info custombtn">Read More</a>
                     </div>
                  </div>
                  <div class="item">
                     <div class="iinnerowl">
                       <img src="images/ser3.svg"  alt="">
                       <h3>Glass Cleaning</h3>
                       <p>Imagine coming home to a completely clean, fresh smelling home after a long day of work. If you need our help</p>
                       <a href="single-services.php" class="btn btn-info custombtn">Read More</a>
                     </div>
                  </div>
                    <div class="item">
                     <div class="iinnerowl">
                       <img src="images/ser1.svg"  alt="">
                       <h3>Glass Cleaning</h3>
                       <p>Imagine coming home to a completely clean, fresh smelling home after a long day of work. If you need our help</p>
                       <a href="single-services.php" class="btn btn-info custombtn">Read More</a>
                     </div>
                  </div>
                    <div class="item">
                     <div class="iinnerowl">
                       <img src="images/ser2.svg"  alt="">
                       <h3>Glass Cleaning</h3>
                       <p>Imagine coming home to a completely clean, fresh smelling home after a long day of work. If you need our help</p>
                       <a href="single-services.php" class="btn btn-info custombtn">Read More</a>
                     </div>
                  </div>
                </div>
              </div>
           </div>
        </div>
     </div>
  </section>
  <!-- End Slider Customer -->

  <!-- Slider Customer -->
  <section class="secpad cleano bgblue">
     <div class="container">
        <div class="row">
           <div class="col-lg-8">
              <h2 class="text-left">Cleaning With a Conscience</h2>
              <h3 class="text-left">Professional Cleaning Services for Home and Office</h3>

              <p>Cleaning can be a chore and we know you have many choices when you consider hiring a maid service. Because of that, we are constantly thriving to improve our already high standards to have you see us as the absolute best in the industry. It’s not enough to have trust in the cleaning crew that you let into your home… you also have to trust that they will perform a first-class cleaning job for you. Putting our employees through a rigorous training program ensures each member of our cleaning team understands their role and how it relates to the overall performance of the team.</p>

              <ul class="list-unstyled">
                 <li><i class="fa fa-check"></i> One-off, weekly or fortnightly visits </li>
                 <li><i class="fa fa-check"></i> Vetted & background-checked cleaners </li>
                 <li><i class="fa fa-check"></i> Keep the same cleaner for every visit </li>
                 <li><i class="fa fa-check"></i> Book, manage & pay online </li>
              </ul>
           </div>

           <div class="col-lg-4">
              <img src="images/cleanlady.png" class="img-responsive img100" alt="">
           </div>
        </div>
     </div>
  </section>
  <!-- End Slider Customer -->

  <!-- Working Process -->
  <section class="secpad cleano">
     <h2 class="text-center">Our Working Process</h2>
     <h3 class="text-center">Lorem Ipsum is simply dummy text of the printing and typesettin</h3>
     <div class="container">
        <div class="row mt-60">
           <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <div class="iinnerowl">
                 <div class="bgicon">
                    <img src="images/bookonline.svg" alt="">
                 </div>
                 <h3>Book Online</h3>
                 <p>Book & pay online. We’ll match you with a trusted, experienced </p>
               </div>
           </div>
           <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <div class="iinnerowl">
                 <div class="bgicon bgicon1">
                    <img src="images/message.svg" alt="">
                 </div>
                 <h3>Get Confirmation</h3>
                 <p>Book & pay online. We’ll match you with a trusted, experienced </p>
               </div>
           </div>
           <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <div class="iinnerowl">
                 <div class="bgicon bgicon2">
                    <img src="images/enjoy.svg" alt="">
                 </div>
                 <h3>Let’s Enjoy</h3>
                 <p>Book & pay online. We’ll match you with a trusted, experienced </p>
               </div>
           </div>
        </div>
     </div>
  </section>
  <!-- End Working Process -->

  <!-- Why Choose Us -->
  <section class="secpad cleano">
     <div class="container">
        <div class="row">
           <div class="col-lg-6">
              <img src="images/whychooseus.png" class="img-responsive" alt="">
           </div>
           <div class="col-lg-6">
              <h2 class="text-left">Why Choose Us</h2>
              <h3 class="text-left">Our Expertise Making Your Business Shine</h3>

              <div class="whyBox">
                 <div class="whyBoxFlex">
                    <img src="images/choose1.svg" width="70" alt="">
                    <div class="headBox">
                       <h4>Expert Cleaner</h4>
                       <p>House cleaning professionals who have helped clean millions of homes</p>
                    </div>
                 </div>   
                 <div class="whyBoxFlex">
                    <img src="images/choose2.svg" width="70" alt="">
                    <div class="headBox">
                       <h4>Comfortable Price</h4>
                       <p>Price is what you pay. Value is what you get. We believe that value is what you’re looking for.</p>
                    </div>
                 </div>
                 <div class="whyBoxFlex">
                    <img src="images/choose3.svg" width="70" alt="">
                    <div class="headBox">
                       <h4>Affordable Service</h4>
                       <p>Total number of reviews and star-ratings are based on data collected during the time.</p>
                    </div>
                 </div>
              </div>
           </div>
        </div>
     </div>
  </section>
  <!-- End Why Choose Us -->

  <!-- Working Process -->
  <section class="secpad testimonial bg-img" style="background-image: url(images/testibg.png)">
    <h2 class="text-center">What Our Clients Speak About Us?</h2>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="carousel slide" data-ride="carousel" id="quote-carousel">
                    <!-- Carousel Slides / Quotes -->
                         <!-- Bottom Carousel Indicators -->
                    <ol class="carousel-indicators">
                        <li data-target="#quote-carousel" data-slide-to="0" class="active">
                          <img class="img-responsive " src="images/test2.png" alt="">
                        </li>
                        <li data-target="#quote-carousel" data-slide-to="1">
                          <img class="img-responsive" src="images/test1.png" alt="">
                        </li>
                        <li data-target="#quote-carousel" data-slide-to="2">
                          <img class="img-responsive" src="images/test2.png" alt="">
                        </li>
                    </ol>

                    <div class="carousel-inner text-center">
                        <!-- Quote 1 -->
                        <div class="item active">
                            <div class="row">
                                <div class="col-sm-8 col-sm-offset-2">
                                    <div class="test_box">
                                      <h3>John Smith</h3>
                                      <p>Creative Designer</p>
                                      <ul class="list-unstyled list-inline">
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star-o"></i></li>
                                      </ul>
                                    </div>

                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. !</p>
                                </div>
                            </div>
                        </div>
                        <!-- Quote 2 -->
                        <div class="item ">
                            <div class="row">
                                <div class="col-sm-8 col-sm-offset-2">
                                    <div class="test_box">
                                      <h3>John Smith</h3>
                                      <p>Creative Designer</p>
                                      <ul class="list-unstyled list-inline">
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star-o"></i></li>
                                      </ul>
                                    </div>

                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. !</p>
                                </div>
                            </div>
                        </div>
                        <!-- Quote 3 -->
                        <div class="item">
                            <div class="row">
                                <div class="col-sm-8 col-sm-offset-2">
                                    <div class="test_box">
                                      <h3>John Smith</h3>
                                      <p>Creative Designer</p>
                                      <ul class="list-unstyled list-inline">
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star-o"></i></li>
                                      </ul>
                                    </div>

                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. !</p>
                                </div>
                            </div>
                        </div>
                    </div>


                    <!-- Bottom Carousel Indicators -->
                    <ol class="carousel-indicators bottomin">
                        <li data-target="#quote-carousel" data-slide-to="0" class="active"></li>
                        <li data-target="#quote-carousel" data-slide-to="1"></li>
                        <li data-target="#quote-carousel" data-slide-to="2"></li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
  </section>
  <!-- End Working Process -->

  <!-- Working Process -->
  <section class="secpad price">
     <h2 class="text-center">No Extra Hidden Charges! <br> Choose Your Plan</h2>
     <div class="container">
        <div class="row mt-60">
           <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <div class="iinnerowl">
                 <h3 class="blueh3">Basic</h3>
                 <img src="images/basic.svg"  alt="">
                 <h3 class="priceh3">$35</h3>
                 <ul class="list-unstyled">
                    <li> 3 Bedrooms cleaning </li>
                    <li> Vacuuming </li>
                    <li> 2 Bathroom cleaning </li>
                    <li> 1 Livingroom Cleaning </li>
                 </ul>
                 <a href="#" class="btn btn-info custombtn">Book Now</a>
               </div>
           </div>
           <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <div class="iinnerowl">
                 <h3 class="blueh3">Standard</h3>
                 <img src="images/standard.svg"  alt="">
                 <h3 class="priceh3">$35</h3>
                 <ul class="list-unstyled">
                    <li> 5 Bedrooms cleaning </li>
                    <li> Vacuuming </li>
                    <li> 5 Bathroom cleaning </li>
                    <li> 3 Livingroom Cleaning </li>
                 </ul>
                 <a href="#" class="btn btn-info custombtn">Book Now</a>
               </div>
           </div>
           <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <div class="iinnerowl">
                 <h3 class="blueh3">Premium</h3>
                 <img src="images/premium.svg"  alt="">
                 <h3 class="priceh3">$35</h3>
                 <ul class="list-unstyled">
                    <li> 7 Bedrooms cleaning </li>
                    <li> Vacuuming </li>
                    <li> 7 Bathroom cleaning </li>
                    <li> 5 Livingroom Cleaning </li>
                 </ul>
                 <a href="#" class="btn btn-info custombtn">Book Now</a>
               </div>
           </div>
        </div>
     </div>
  </section>
  <!-- End Working Process -->

  <!-- Gallery -->
  <section class="secpad price pad-none pt-0">
     <h2 class="text-center">Our Projects</h2>
     <div class="gallerysec mt-60">
        <div class="controls">
            <button class="filter" data-filter="all">All</button>
            <button class="filter" data-filter=".house">House</button>
            <button class="filter" data-filter=".office">Office</button>
            <button class="filter" data-filter=".floor">Floor</button>
            <button class="filter" data-filter=".glass">Glass</button>
            <button class="filter" data-filter=".kitchen">Kitchen</button>
          </div>

          <div class="pager-list">
            <!-- Pagination buttons will be generated here -->
          </div>

          <div id="Container" class="cont">
            <div class="mix house" data-myorder="1">
               <img src="images/cleanpic1.png" class="img-responsive">
            </div>
            <div class="mix glass" data-myorder="2">
              <img src="images/cleanpic.png" class="img-responsive">
            </div>
            <div class="mix floor" data-myorder="3">
              <img src="images/cleanpic1.png" class="img-responsive">
            </div>
            <div class="mix office" data-myorder="4">
              <img src="images/cleanpic.png" class="img-responsive">
            </div>
            <div class="mix house" data-myorder="5">
              <img src="images/cleanpic1.png" class="img-responsive">
            </div>
            <div class="mix house" data-myorder="6">
              <img src="images/cleanpic.png" class="img-responsive">
            </div>
            <div class="mix glass" data-myorder="7">
              <img src="images/cleanpic1.png" class="img-responsive">
            </div>
            <div class="mix kitchen" data-myorder="8">
              <img src="images/cleanpic.png" class="img-responsive">
            </div>
            
            <div class="gap"></div>
            <div class="gap"></div>
          </div>
     </div>
  </section>
  <!-- End Gallery -->

    <!-- Blog -->
  <section class="secpad blogbox pt-0">
     <h2 class="text-center">Our Latest Blogs</h2>
     <div class="container">
        <div class="row mt-60">
           <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <div class="iinnerowl">
                 <img src="images/blog.png" class="img-responsive"  alt="">
                 <div class="blogcon">
                   <h4>16 April, 2020</h4>
                   <h3><a href="#"> The Secret of Cleaning Your House </a></h3>
                   <p>Borem ipsums dolor sit amet consect adipiscing elit integer lacorem ipsum ars amet consectetur adipiscing.</p>
                   <a href="#" class="readmore">Read More >></a>
                 </div>
               </div>
           </div>
           <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <div class="iinnerowl">
                 <img src="images/blog2.png" class="img-responsive"  alt="">
                 <div class="blogcon">
                   <h4>16 April, 2020</h4>
                   <h3><a href="#"> The Secret of Cleaning Your House </a></h3>
                   <p>Borem ipsums dolor sit amet consect adipiscing elit integer lacorem ipsum ars amet consectetur adipiscing.</p>
                   <a href="#" class="readmore">Read More >></a>
                 </div>
               </div>
           </div>
           <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <div class="iinnerowl">
                 <img src="images/blog1.png" class="img-responsive"  alt="">
                 <div class="blogcon">
                   <h4>16 April, 2020</h4>
                   <h3><a href="#"> The Secret of Cleaning Your House </a></h3>
                   <p>Borem ipsums dolor sit amet consect adipiscing elit integer lacorem ipsum ars amet consectetur adipiscing.</p>
                   <a href="#" class="readmore">Read More >></a>
                 </div>
               </div>
           </div>
        </div>
     </div>
  </section>
  <!-- End Blog -->

<?php include("inc/footer.php"); ?>