<?php include("inc/header.php"); ?>

  <!-- Heading Image -->
  <section class="comh2 bg-img" style="background-image: url(images/about-us.png)">
    <h2 class="text-center">About Us</h2>
  </section>
  <!-- End Heading Image -->

  <!-- About Us -->
  <section class="secpad cleano">
     <div class="container">
        <div class="row">
           <div class="col-lg-6 col-md-6">
              <h2 class="text-left">About Us</h2>
              <h3 class="text-left">New Generation of Cleaning And Restoration Concepts.</h3>

              <p>Whether you want to schedule a one off clean in your home, a weekly visit or even need an emergency call out, or have a commercial cleaning need then our Edinburgh team are equipped to meet your needs. With a range of customers including letting agents as well as homeowners, our cleaners are renowned for being flexible and reliable. Our mission is not only to meet your expectations but to exceed them, we also provide many more like condos and apartment cleaning. Our unique 22-Step Healthy Touch Deep Cleaning System will ensure you’ll receive a healthy, thorough housecleaning with every visit. We’ll tackle mold and mildew. We’ll eliminate dust. We’ll eliminate on pet dander and hair. We use cleaning products that are friendly to the environment—that includes Nature’s home and your own. .</p>

              <ul class="list-unstyled">
                 <li><i class="fa fa-check"></i> One-off, weekly or fortnightly visits </li>
                 <li><i class="fa fa-check"></i> Vetted &amp; background-checked cleaners </li>
                 <li><i class="fa fa-check"></i> Keep the same cleaner for every visit </li>
                 <li><i class="fa fa-check"></i> Book, manage &amp; pay online </li>
              </ul>
           </div>

           <div class="col-lg-6 col-md-6">
              <img src="images/about.png" class="img-responsive imghover img100" alt="">
           </div>
        </div>
     </div>
  </section>
  <!-- End Of About Us -->

  <!-- About Us -->
  <section class="cleano bgblue about1">
     <div class="container">
        <div class="row">
           <div class="col-lg-6 col-md-6">
              <img src="images/about1.png" class="img-responsive img100" alt="">
           </div>

           <div class="col-lg-6 col-md-6">
              <h2 class="text-left">Our Values</h2>
              <h3 class="text-left">Our Mission</h3>

              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>

              <h3 class="text-left">Our Visions</h3>

              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>

              <h3 class="text-left">Our Goal</h3>

              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
           </div>
        </div>
     </div>
  </section>
  <!-- End Of About Us -->

<?php include("inc/footer.php"); ?>