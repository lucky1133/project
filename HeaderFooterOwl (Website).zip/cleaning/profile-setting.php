<?php include("inc/header.php"); ?>
<style>
  .Navbar-Header
  {
      box-shadow: 1px -2px 6px #424242;
  }
</style>

<!-- About Us -->
<section class="secpad profileSetting">
   <div class="container">
      <div class="row row1">
         <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
            <div class="sideways">
              <!-- Nav tabs -->
              <ul class="nav nav-tabs tabs-left">
                 <li class="active"><a href="#profile-v" data-toggle="tab">Profile</a></li>
                 <li><a href="#password-v" data-toggle="tab">Password</a></li>
                 <li><a href="#notification-v" data-toggle="tab">Notification</a></li>
                 <li><a href="#bookedservice-v" data-toggle="tab">Booked Service</a></li>
                 <li><a href="#bookinghistory-v" data-toggle="tab">Booking History</a></li>
                 <li><a href="#payment-v" data-toggle="tab">Payment</a></li>
                 <li><a href="#transactions-v" data-toggle="tab">Transactions</a></li>
                 <li><a href="#review-v" data-toggle="tab">Review & Rating</a></li>
                 <li><a href="#deactivate-v" data-toggle="tab">Deactivate</a></li>
              </ul>
            </div>
         </div>
         <div class="col-lg-8 col-md-6 col-sm-6 col-xs-12">
          <!-- Tab panes -->
          <div class="sideways">
            <div class="tab-content">
              <div class="tab-pane active" id="profile-v">
                 <div class="proHead">
                    <h2>Profile</h2>
                    <a href="#"><img src="images/editicon.svg" width="25" alt=""></a>
                 </div>
                 <div class="profileDes">
                    <div class="ifexdiv"><img src="images/proimg.jpg" class="img-responsive" alt="" /> </div>
                    <div class="proDetails">
                       <div class="proField">
                          <i class="fa fa-user"></i>
                          <span>John Doe</span>
                       </div>
                       <div class="proField">
                          <i class="fa fa-envelope-o"></i>
                          <span>johndoe@gmail.com</span>
                       </div>
                       <div class="proField">
                          <i class="fa fa-phone"></i>
                          <span>+41 1234567890</span>
                       </div>
                       <div class="proField">
                          <i class="fa fa-home"></i>
                          <span>70 Washington Square South, <br> New York, NY 10012, <br>United States</span>
                       </div>
                    </div>
                 </div>
              </div>
              <div class="tab-pane" id="password-v">
                 <div class="proHead">
                    <h2>Profile</h2>
                    <a href="#"><img src="images/editicon.svg" width="25" alt=""></a>
                 </div>
                 <div class="profileDes">
                    <div class="ifexdiv"><img src="images/proimg.jpg" class="img-responsive" alt="" /> </div>
                    <div class="proDetails">
                      <div class="row">
                        <div class="col-md-10">
                            <form id="contact-form" class="contact_form">

                              <div class="form-group">
                                  <input name="user_name" type="text" class="form-control" placeholder="Name">
                              </div>
                              <div class="form-group">
                                  <input name="user_email" type="text" class="form-control" placeholder="Email">
                              </div>
                              <div class="form-group">
                                  <input name="user_subject" type="text" class="form-control" placeholder="Phone No.">
                              </div>
                              <div class="form-group">
                                  <input name="user_subject" type="text" class="form-control" placeholder="Address">
                              </div>

                              <div class="form-group">
                                  <input name="user_subject" type="text" class="form-control" placeholder="Zip Code">
                              </div>

                              <button class="btn btn-info custombtn blueBtn" type="submit">Update</button>
                            </form>
                        </div>
                      </div>
                    </div>
                 </div>
              </div>
              <div class="tab-pane" id="notification-v">
                <div class="proHead">
                  <h2>Notification</h2>
                </div>

                <div class="supervisor">
                   <div class="media">
                       <img src="images/test1.png" alt="user" class="chatImg">
                       <div class="media-body ml-4">
                          <div class="d-flex justify-content-between mb-1">
                             <h6 class="mb-1">Your Perposal for Digital Marketing has been accepted</h6>
                             
                          </div>
                          <p class="text-muted mb-3 text-small">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum hasbeen the industry's standard dummy text ever since the 1500s,.</p>     

                          <small class="small"> 11 May, 2020</small>  
                       </div>
                   </div>

                    <div class="media">
                       <img src="images/test1.png" alt="user" class="chatImg">
                       <div class="media-body ml-4">
                          <div class="d-flex justify-content-between mb-1">
                             <h6 class="mb-1">Your Perposal for Digital Marketing has been accepted</h6>
                             
                          </div>
                          <p class="text-muted mb-3 text-small">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum hasbeen the industry's standard dummy text ever since the 1500s,.</p>     

                          <small class="small"> 11 May, 2020</small>  
                       </div>
                   </div>

                    <div class="media">
                       <img src="images/test1.png" alt="user" class="chatImg">
                       <div class="media-body ml-4">
                          <div class="d-flex justify-content-between mb-1">
                             <h6 class="mb-1">Your Perposal for Digital Marketing has been accepted</h6>
                             
                          </div>
                          <p class="text-muted mb-3 text-small">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum hasbeen the industry's standard dummy text ever since the 1500s,.</p>     

                          <small class="small"> 11 May, 2020</small>  
                       </div>
                   </div>

                    <div class="media">
                       <img src="images/test1.png" alt="user" class="chatImg">
                       <div class="media-body ml-4">
                          <div class="d-flex justify-content-between mb-1">
                             <h6 class="mb-1">Your Perposal for Digital Marketing has been accepted</h6>
                             
                          </div>
                          <p class="text-muted mb-3 text-small">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum hasbeen the industry's standard dummy text ever since the 1500s,.</p>     

                          <small class="small"> 11 May, 2020</small>  
                       </div>
                   </div>

                    <div class="media">
                       <img src="images/test1.png" alt="user" class="chatImg">
                       <div class="media-body ml-4">
                          <div class="d-flex justify-content-between mb-1">
                             <h6 class="mb-1">Your Perposal for Digital Marketing has been accepted</h6>
                             
                          </div>
                          <p class="text-muted mb-3 text-small">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum hasbeen the industry's standard dummy text ever since the 1500s,.</p>     

                          <small class="small"> 11 May, 2020</small>  
                       </div>
                   </div>

                    <div class="media">
                       <img src="images/test1.png" alt="user" class="chatImg">
                       <div class="media-body ml-4">
                          <div class="d-flex justify-content-between mb-1">
                             <h6 class="mb-1">Your Perposal for Digital Marketing has been accepted</h6>
                             
                          </div>
                          <p class="text-muted mb-3 text-small">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum hasbeen the industry's standard dummy text ever since the 1500s,.</p>     

                          <small class="small"> 11 May, 2020</small>  
                       </div>
                   </div>
                </div>
                <div class="text-center mt-20">
                  <button class="btn btn-info custombtn blueBtn" type="submit">Update</button>
                </div>
              </div>
              <div class="tab-pane" id="bookedservice-v">No</div>
              <div class="tab-pane" id="bookinghistory-v">No</div>
              <div class="tab-pane" id="payment-v">No</div>
              <div class="tab-pane" id="transactions-v">No</div>
              <div class="tab-pane" id="review-v">No</div>
              <div class="tab-pane" id="deactivate-v">No</div>
            </div>
          </div>
         </div>
      </div>
   </div>
</section>
<!-- End Of About Us -->
<?php include("inc/footer.php"); ?>