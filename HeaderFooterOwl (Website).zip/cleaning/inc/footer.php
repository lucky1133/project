      <footer class="secpad bgBlue padfoot">
        <div class="container">
          <div class="row">
            <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12">
               <div class="foot_about">
                  <img src="images/logo/logo.png" width="250">
                  <p>There are many variations of passagesof Lorem Ipsum available, There aremany variations of passages.</p>

                  <div class="Link-ul">
                      <h3>Follow Us On:-</h3>
                      <ul class="icons-ul">
                         <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                         <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                         <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                         <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                      </ul>
                   </div>
               </div>
            </div>
            <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
               <div class="foot_about1">
                  <h3>Services</h3>
                  <ul class="list-unstyled">
                    <li> <a href="#"> <i class="fa fa-angle-right" aria-hidden="true"></i> Toilet Cleaning </a> </li> 
                    <li> <a href="#"> <i class="fa fa-angle-right" aria-hidden="true"></i> Bedroom Cleaning </a> </li> 
                    <li> <a href="#"> <i class="fa fa-angle-right" aria-hidden="true"></i> Window Cleaning </a> </li> 
                    <li> <a href="#"> <i class="fa fa-angle-right" aria-hidden="true"></i> Garden Cleaning </a> </li> 
                    <li> <a href="#"> <i class="fa fa-angle-right" aria-hidden="true"></i> Kitchen Cleaning </a> </li> 
                  </ul>
               </div>
            </div>
            <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
               <div class="foot_about1">
                  <h3>Quick Links</h3>
                  <ul class="list-unstyled">
                    <li> <a href="#"> <i class="fa fa-angle-right" aria-hidden="true"></i> Offers </a> </li> 
                    <li> <a href="#"> <i class="fa fa-angle-right" aria-hidden="true"></i> Features </a> </li> 
                    <li> <a href="#"> <i class="fa fa-angle-right" aria-hidden="true"></i> Pricing Table </a> </li> 
                    <li> <a href="#"> <i class="fa fa-angle-right" aria-hidden="true"></i> Partners </a> </li> 
                    <li> <a href="faq.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Faq Page </a> </li> 
                    <li> <a href="blog.php"> <i class="fa fa-angle-right" aria-hidden="true"></i> Blog </a> </li> 
                  </ul>
               </div>
            </div>
            <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
               <div class="foot_about1">
                  <h3>Corporate Office</h3>
                  <ul class="list-unstyled">
                    <li>
                      <div class="address">
                        <i class="fa fa-map-marker"></i>
                        <p> 59 Street, B4 Appartment, Australia</p>
                      </div>
                    </li> 
                    <li>
                      <div class="address">
                        <i class="fa fa-phone"></i>
                        <p> +985-8844-000</p>
                      </div>
                    </li> 
                    <li>
                      <div class="address">
                        <i class="fa fa-envelope-o"></i>
                        <p> info@cleanservice.com</p>
                      </div>
                    </li> 
                  </ul>
               </div>
            </div>
          </div>
        </div>

        <div class="container">
          <div class="row">
            <div class="col-dm-12 text-center">
              <div class="footdivider"></div>
              <div class="copyright">
                <p> © 2020 houseofmaidscleaningservices.co.uk All Rights Reserved.</p>
              </div>
            </div>
          </div>
        </div>
      </footer>

      <!-- Placed at the end of the document so the pages load faster -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
      <script type="text/javascript" src="js/menu-script.js"></script>
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.1.3/owl.carousel.min.js"></script>
      <script type="text/javascript" src="https://cdn.jsdelivr.net/jquery.mixitup/latest/jquery.mixitup.min.js"></script>
      <!-- End Of Slider -->
      <script type="text/javascript" src="js/custom.js"></script>

      <script>
         $('.owl-carousel').owlCarousel({
           loop: true,
           margin: 10,
           nav: true,
           navText: [
             "<img src='images/arrowt.png'> ",
             "<img src='images/arrowl.png'> "
           ],
           autoplay: true,
           autoplayHoverPause: true,
           responsive: {
             0: {
               items: 1
             },
             600: {
               items: 2
             },
             1000: {
               items: 3
             }
           }
         })

         $(function(){
            $('#Container').mixItUp();
          });
      </script>
   </body>
</html>