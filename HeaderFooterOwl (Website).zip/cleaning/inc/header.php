<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE10">
      <meta name="description" content="">
      <!--    <link rel="shortcut icon" href="images/favicon.ico"> -->
      <title>House Of Maid</title>
      <!-- Bootstrap core CSS -->
      <link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.1.3/assets/owl.carousel.min.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet">
      
      <link href="css/responsive.css" rel="stylesheet">
   </head>
   <body>
      <section class="mainheader">
         <div class="topheader">
            <div class="container">
               <div class="row">
                  <div class="Contact-h col-md-6">
                     <div class="PhoneNamber">
                        <p><img src="images/phone.svg" width="19px;" alt="Phone"> : (888) 379-9437</p>
                     </div>
                     <div class="Email-Site">
                        <p><img src="images/time.svg" width="19px;" alt="Time"> : Mon - Fri: 09.00am - 10.00pm</p>
                     </div>
                  </div>
                  <div class="col-md-6 pr-none">
                     <div class="Link-ul">
                        <ul class="icons-ul">
                           <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                           <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                           <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                           <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- Start Navbar -->
         <div class="Navbar-Header navbar basic" data-sticky="true">
            <div class="container">
               <div class="row flex-n">
                  <div class="Logo-Header col-md-3">
                     <a class="navbar-logo" href="index.php">
                     <img src="images/logo/logo.png" class="img-responsive">
                     </a>
                  </div>
                  <div class="collapse pull-right navbar-collapse">
                     <div id="cssmenu" class="Menu-Header top-menu">
                        <ul>
                           <!--  <li class="has-sub current"><a href="index.html">Home</a>
                              <ul>
                              	<li class="active"><a href="index.html">Homepage 1</a></li>
                              	<li><a href="index_v2.html">Homepage 2</a></li>
                              	<li><a href="index_v3.html">Homepage 3</a></li>
                              	<li><a href="index_v4.html">Homepage 4</a></li>
                              	<li><a href="image_parallax.html">Image Parallax</a></li>
                              	<li><a href="image_parallax_v2.html">Image Parallax 2</a></li>
                              	<li><a href="image_fixed.html">Image Fixed</a></li>
                              	<li><a href="image_fixed_v2.html">Image Fixed 2</a></li>
                              	<li><a href="pattern_background.html">Pattern Background</a></li>
                              	<li><a href="video_background.html">Video Background</a></li>
                              </ul>					  
                              </li>
                                <li class="has-sub yamm-fullwidth"><a href="#">Features</a>
                              <ul>
                                <li>
                                <div class="col-md-3">
                              	<h5>Header Styles</h5>
                              	<ul>
                              	  <li><a href="elements/header_01.html">Header 01</a></li>
                              	  <li><a href="elements/header_02.html">Header 02</a></li>
                              	  <li><a href="elements/header_03.html">Header 03</a></li>
                              	  <li><a href="elements/header_04.html">Header 04</a></li>
                              	  <li><a href="elements/header_05.html">Header 05</a></li>
                              	  <li><a href="elements/header_06.html">Header 06</a></li>
                              	</ul>
                                </div>
                                <div class="col-md-3">
                              	<h5>Footer Styles</h5>
                              	<ul>
                              	  <li><a href="elements/footer_01.html">Footer 01</a></li>
                              	  <li><a href="elements/footer_02.html">Footer 02</a></li>
                              	  <li><a href="elements/footer_03.html">Footer 03</a></li>
                              	  <li><a href="elements/footer_04.html">Footer 04</a></li>
                              	  <li><a href="elements/footer_05.html">Footer 05</a></li>
                              	</ul>
                                </div>
                                <div class="col-md-3">
                              	  <h5>Page Title img Styles</h5>
                              		<ul>
                              		  <li><a href="elements/page-title_01.html">Pattern BG</a></li>
                              		  <li><a href="elements/page-title_02.html">Polygon BG</a></li>
                              		  <li><a href="elements/page-title_05.html">Blue Color Overlay</a></li>
                              		  <li><a href="elements/page-title_06.html">Dark Color Overlay</a></li>
                              		  <li><a href="elements/page-title_09.html">Big Title Style</a></li>
                              		</ul>
                                </div>
                                <div class="col-md-3">
                              	  <h5>Page Title color Styles</h5>
                              		<ul>
                              		  <li><a href="elements/page-title_03.html">Light Color BG</a></li>
                              		  <li><a href="elements/page-title_04.html">Dark Color BG</a></li>
                              		  <li><a href="elements/page-title_07.html">Centered Dark Background</a></li>
                              		  <li><a href="elements/page-title_08.html">Centered Light Background</a></li>
                              		</ul>
                                </div>
                                </li>
                              </ul>
                                </li>
                                <li class="has-sub"><a href="#">Portfolio</a>
                               <ul>
                              <li><a href="#">Portfolio Classic</a>
                              	<ul class="sub-menu">
                              		<li><a href="portfolio_classic_2col.html">Portfolio Classic 2Col</a></li>
                              		<li><a href="portfolio_classic_3col.html">Portfolio Classic 3Col</a></li>
                              		<li><a href="portfolio_classic_4col.html">Portfolio Classic 4Col</a></li>
                              	</ul>
                              </li>
                              <li><a href="#">Portfolio Masonry</a>
                              	<ul class="sub-menu">
                              		<li><a href="portfolio_masonry_2col.html">Portfolio Masonry 2Col</a></li>
                              		<li><a href="portfolio_masonry_3col.html">Portfolio Masonry 3Col</a></li>
                              		<li><a href="portfolio_masonry_4col.html">Portfolio Masonry 4Col</a></li>
                              	</ul>
                              </li>
                              <li><a href="#">Portfolio Thumbnails</a>
                              	<ul class="sub-menu">
                              		<li><a href="portfolio_style_1.html">Portfolio Style 1</a></li>
                              		<li><a href="portfolio_style_2.html">Portfolio Style 2</a></li>
                              		<li><a href="portfolio_style_3.html">Portfolio Style 3</a></li>
                              	</ul>
                              </li>
                              <li><a href="#">Portfolio Gallery</a>
                              	<ul class="sub-menu">
                              		<li><a href="portfolio_gallery_2col.html">Portfolio Gallery 2Col</a></li>
                              		<li><a href="portfolio_gallery_3col.html">Portfolio Gallery 3Col</a></li>
                              		<li><a href="portfolio_gallery_4col.html">Portfolio Gallery 4Col</a></li>
                              	</ul>
                              </li>
                              <li><a href="#">Portfolio Fullwidth</a>
                              	<ul class="sub-menu">
                              		<li><a href="portfolio_fullwidth_2col.html">Portfolio Fullwidth 2Col</a></li>
                              		<li><a href="portfolio_fullwidth_3col.html">Portfolio Fullwidth 3Col</a></li>
                              		<li><a href="portfolio_fullwidth_4col.html">Portfolio Fullwidth 4Col</a></li>
                              	</ul>
                              </li>
                              <li><a href="portfolio_single.html">Portfolio Single</a></li>
                               </ul>
                                </li> -->
                           <li><a href="index.php">Home</a></li>
                           <li><a href="about-us.php">About Us</a></li>
                           <li><a href="services.php">Our Services</a></li>
                           <li><a href="testimonials.php">Testimonials</a></li>
                           <li><a href="contact-us.php">Contact Us</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="right-wrapper">
                     <div>
                        <a href="#"> 
                        <img src="images/login.svg" width="18px" />
                        <span>Login</span>
                        </a>
                     </div>
                     <div>
                        <a href="#"> 
                        <img src="images/fav.svg" width="16px" />
                        <span>Favuorite</span>
                        </a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- End Navbar -->
      </section>
