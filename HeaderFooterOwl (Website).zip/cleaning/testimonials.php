<?php include("inc/header.php"); ?>
<!-- Heading Image -->
<section class="comh2 bg-img" style="background-image: url(images/about-us.png)">
   <h2 class="text-center">Testimonials </h2>
</section>
<!-- End Heading Image -->
<!-- About Us -->
<section class="secpad custreview">
   <h2 class="text-center"> People say the nicest things </h2>
   <div class="container">
      <div class="row mt-60">
         <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
           <div class="iinnerowl">
              <img src="images/test2.png" class="img-responsive" alt="">
              <div class="blogcon">
                <h3> Ellena</h3>
                <h4>CEO WeWork</h4>
            
                <div class="teamLine"></div>
                <p>These guys are awseomeLorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis.</p>

                <ul class="list-unstyled list-inline">
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star-o"></i></li>
                 </ul>
              </div>
            </div>
         </div>

         <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
           <div class="iinnerowl">
              <img src="images/test1.png" class="img-responsive" alt="">
              <div class="blogcon">
                <h3> Ellena</h3>
                <h4>CEO WeWork</h4>
            
                <div class="teamLine"></div>
                <p>These guys are awseomeLorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis.</p>

                <ul class="list-unstyled list-inline">
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star-o"></i></li>
                 </ul>
              </div>
            </div>
         </div>

         <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
           <div class="iinnerowl">
              <img src="images/test2.png" class="img-responsive" alt="">
              <div class="blogcon">
                <h3> Ellena</h3>
                <h4>CEO WeWork</h4>
            
                <div class="teamLine"></div>
                <p>These guys are awseomeLorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis.</p>

                <ul class="list-unstyled list-inline">
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star-o"></i></li>
                 </ul>
              </div>
            </div>
         </div>

         <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
           <div class="iinnerowl">
              <img src="images/test2.png" class="img-responsive" alt="">
              <div class="blogcon">
                <h3> Ellena</h3>
                <h4>CEO WeWork</h4>
            
                <div class="teamLine"></div>
                <p>These guys are awseomeLorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis.</p>

                <ul class="list-unstyled list-inline">
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star-o"></i></li>
                 </ul>
              </div>
            </div>
         </div>

         <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
           <div class="iinnerowl">
              <img src="images/test1.png" class="img-responsive" alt="">
              <div class="blogcon">
                <h3> Ellena</h3>
                <h4>CEO WeWork</h4>
            
                <div class="teamLine"></div>
                <p>These guys are awseomeLorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis.</p>

                <ul class="list-unstyled list-inline">
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star-o"></i></li>
                 </ul>
              </div>
            </div>
         </div>

         <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
           <div class="iinnerowl">
              <img src="images/test2.png" class="img-responsive" alt="">
              <div class="blogcon">
                <h3> Ellena</h3>
                <h4>CEO WeWork</h4>
            
                <div class="teamLine"></div>
                <p>These guys are awseomeLorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis.</p>

                <ul class="list-unstyled list-inline">
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star-o"></i></li>
                 </ul>
              </div>
            </div>
         </div>

         <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
           <div class="iinnerowl">
              <img src="images/test2.png" class="img-responsive" alt="">
              <div class="blogcon">
                <h3> Ellena</h3>
                <h4>CEO WeWork</h4>
            
                <div class="teamLine"></div>
                <p>These guys are awseomeLorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis.</p>

                <ul class="list-unstyled list-inline">
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star-o"></i></li>
                 </ul>
              </div>
            </div>
         </div>

         <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
           <div class="iinnerowl">
              <img src="images/test1.png" class="img-responsive" alt="">
              <div class="blogcon">
                <h3> Ellena</h3>
                <h4>CEO WeWork</h4>
            
                <div class="teamLine"></div>
                <p>These guys are awseomeLorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis.</p>

                <ul class="list-unstyled list-inline">
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star-o"></i></li>
                 </ul>
              </div>
            </div>
         </div>

         <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
           <div class="iinnerowl">
              <img src="images/test2.png" class="img-responsive" alt="">
              <div class="blogcon">
                <h3> Ellena</h3>
                <h4>CEO WeWork</h4>
            
                <div class="teamLine"></div>
                <p>These guys are awseomeLorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis.</p>

                <ul class="list-unstyled list-inline">
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star-o"></i></li>
                 </ul>
              </div>
            </div>
         </div>

         <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
           <div class="iinnerowl">
              <img src="images/test2.png" class="img-responsive" alt="">
              <div class="blogcon">
                <h3> Ellena</h3>
                <h4>CEO WeWork</h4>
            
                <div class="teamLine"></div>
                <p>These guys are awseomeLorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis.</p>

                <ul class="list-unstyled list-inline">
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star-o"></i></li>
                 </ul>
              </div>
            </div>
         </div>

         <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
           <div class="iinnerowl">
              <img src="images/test1.png" class="img-responsive" alt="">
              <div class="blogcon">
                <h3> Ellena</h3>
                <h4>CEO WeWork</h4>
            
                <div class="teamLine"></div>
                <p>These guys are awseomeLorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis.</p>

                <ul class="list-unstyled list-inline">
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star-o"></i></li>
                 </ul>
              </div>
            </div>
         </div>

         <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
           <div class="iinnerowl">
              <img src="images/test2.png" class="img-responsive" alt="">
              <div class="blogcon">
                <h3> Ellena</h3>
                <h4>CEO WeWork</h4>
            
                <div class="teamLine"></div>
                <p>These guys are awseomeLorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis.</p>

                <ul class="list-unstyled list-inline">
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star"></i></li>
                   <li><i class="fa fa-star-o"></i></li>
                 </ul>
              </div>
            </div>
         </div>
      </div>
      <div class="text-center" style="margin-top: 15px">
         <a href="#" class="btn btn-info custombtn">Load More</a>
      </div>
   </div>
</section>
<!-- End Of About Us -->
<?php include("inc/footer.php"); ?>