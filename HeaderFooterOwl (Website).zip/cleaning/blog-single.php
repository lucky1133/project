<?php include("inc/header.php"); ?>

  <!-- Heading Image -->
  <section class="comh2 bg-img" style="background-image: url(images/about-us.png)">
    <h2 class="text-center">Blog Single </h2>
  </section>
  <!-- End Heading Image -->

  <!-- About Us -->
  <section class="secpad goodcus cleano blogpage blogsingle">
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-sm-8">
          <div class="singelser">
             <img src="images/blogbg.jpg" class="img-responsive singleFix" alt="" />
             <div class="blogdet">
                <span> 12 April 2020 </span> 
                <img src="images/admin.svg" width="20" alt="" />
                <span> By Admin </span> 
                <img src="images/comment.svg" width="20" alt="" />
                <a href="#"><span> Comment 2 </span></a> 
             </div>
             <h3>The Secret of Cleaning Your Kitchen</h3>
             <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>

             <ul class="list-unstyled">
                 <li><i class="fa fa-check"></i> Disinfecting food preparation areas. </li>
                 <li><i class="fa fa-check"></i> Cleaning beverage dispenser heads and bottle openers. </li>
                 <li><i class="fa fa-check"></i> Wash the crockery and utensils and leave them to dry. </li>
                 <li><i class="fa fa-check"></i> Clean rags, aprons, towels, and uniforms. </li>
                 <li><i class="fa fa-check"></i> Disinfect the waste disposal area and the waste bins. </li>
              </ul>

              <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>

              <div class="blogShare">
                  <span> Share </span> 
                  <div class="Link-ul">
                  <ul class="icons-ul">
                     <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                     <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                     <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                     <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                  </ul>
               </div>
             </div>

             <hr class="hrclass" />

             <div class="queryform">
                <h2 class="text-left">Leave A Comment</h2>
                <div class="row">
                  <div class="col-md-6">
                     <div class="form-group">
                        <input type="text" class="form-control" placeholder="Name">
                      </div>
                  </div>
                  <div class="col-md-6">
                     <div class="form-group">
                        <input type="text" class="form-control" placeholder="Email">
                      </div>
                  </div>

                  <div class="col-md-12">
                    <div class="form-group">
                      <textarea class="form-control" rows="5" id="comment"></textarea>
                    </div>  
                  </div>
                </div>
                <a href="#" class="btn btn-info custombtn">Post Comment</a>
             </div>
          </div>

        </div>
        <div class="col-md-4 col-sm-4 rightser">
            
            <div class="searchri pd25 bgblue">
               <h3>Search</h3>
               <!-- Actual search box -->
               <div class="form-group has-feedback has-search">
                  <span class="fa fa-search form-control-feedback"></span>
                  <input type="text" class="form-control" placeholder="Search">
               </div>
            </div>

            <div class="searchri pd25 bgblue">
              <h3>Category</h3>
              <ul class="list-group">
                <li class="list-group-item active"> 
                    <a href="#"><i class="fa fa-angle-double-right"></i> House Cleaning (4) </a>
                </li>
                <li class="list-group-item"> 
                    <a href="#"><i class="fa fa-angle-double-right"></i> Kitchen Cleaning (3)  </a>
                </li>
                <li class="list-group-item"> 
                    <a href="#"><i class="fa fa-angle-double-right"></i> Glass Cleaning (5)  </a>
                </li>
                <li class="list-group-item"> 
                    <a href="#"><i class="fa fa-angle-double-right"></i> Office Cleaning (8)  </a>
                </li>
                <li class="list-group-item"> 
                    <a href="#"><i class="fa fa-angle-double-right"></i> Residental Cleaning (3)  </a>
                </li>
                <li class="list-group-item"> 
                    <a href="#"><i class="fa fa-angle-double-right"></i> Floor Cleaning (2)  </a>
                </li>
              </ul>
            </div>

             <div class="searchri pd25 bgblue">
               <h3>Popular Tag</h3>
               <!-- Actual search box -->
               <div class="tagspop">
                  <a href="#"><span class="badge">Floor</span> </a>
                  <a href="#"><span class="badge">Office</span> </a>
                  <a href="#"><span class="badge">Carpet</span> </a>
                  <a href="#"><span class="badge">Window</span> </a>
               </div>
            </div>

        </div>
      </div>
    </div>
  </section>
  <!-- End Of About Us -->

<?php include("inc/footer.php"); ?>