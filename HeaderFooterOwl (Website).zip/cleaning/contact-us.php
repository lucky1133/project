<?php include("inc/header.php"); ?>
<!-- Heading Image -->
<section class="comh2 bg-img" style="background-image: url(images/about-us.png)">
   <h2 class="text-center"> Contact Us </h2>
</section>
<!-- End Heading Image -->
<!-- About Us -->
<section class="secpad contactus">
   <div class="container">
      <div class="row mt-60">
         <div class="col-md-5">
            <h2> Contact </h2>
            <h3> Get in touch with us </h3>
         </div>
         <div class="col-md-7">
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. </p>
         </div>
      </div>

      <div class="row">
        <div class="col-md-6 timesw">
          <h3>Opening Hours</h3>
          <p> Daily: 8.00 AM–10.00 PM </p>
          <p class="mb50"> Sunday & Holidays: Closed </p>

          <h3>Contact Info</h3>
          <div class="contaddres timesw mb50">
              <div>
                  <i class="fa fa-map-marker"></i>
                  <p>Metrotech Center, Brooklyn, NY 11201, USA</p>
              </div>
               <div>
                  <i class="fa fa-envelope-o"></i>
                  <p>info@houseofmaid.com</p>
              </div>
               <div>
                  <i class="fa fa-phone"></i>
                  <p>+41 1234567890</p>
              </div>
          </div>

           <h3>Social Contact</h3>

           <div class="blogShare">
              <div class="Link-ul">
                  <ul class="icons-ul">
                     <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                     <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                     <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                     <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                  </ul>
              </div>
            </div>
        </div>
        <div class="col-md-6">
          <form id="contact-form" class="contact_form">
                <h3 class="mb-4 font-weight-bold">Let’s Conversation <br> with House of Maid</h3>
                
                <div class="form-group">
                    <input name="user_name" type="text" class="form-control" placeholder="Name">
                </div>
                <div class="form-group">
                    <input name="user_email" type="text" class="form-control" placeholder="Email">
                </div>
                <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                          <input name="user_subject" type="text" class="form-control" placeholder="Phone">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                          <input name="user_subject" type="text" class="form-control" placeholder="Subject">
                      </div>
                    </div>
                </div>
                
                <div class="form-group mb-3">
                    <textarea name="user_message" class="form-control" rows="6" placeholder="Message"></textarea>
                </div>
                <button class="btn btn-info custombtn" type="submit">Send Now</button>
            </form>
        </div>
      </div>

      <div class="row mt-60">
        <div class="col-md-12">
          <img src="images/map.jpg" class="img-responsive">
        </div>
      </div>
   </div>
</section>
<!-- End Of About Us -->
<?php include("inc/footer.php"); ?>