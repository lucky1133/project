<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * e.g., it puts together the home page when no home.php file exists.
 *
 * Learn more: {@link https://codex.wordpress.org/Template_Hierarchy}
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); ?>

		<!-- Header Section Ends-->
	
	<!-- Slider Start -->
   <div id="jssor_1" class="main-slider">
        <!-- Loading Screen -->
       
        <div data-u="slides" class="cursor-on">
            
			<?php

global $post;
$args = array( 'posts_per_page' => -1, 'post_type'  => 'slider' );

$myposts = get_posts( $args );
foreach ( $myposts as $post ) : setup_postdata( $post ); 

?>
	<div>
               <img data-u="image" src="<?php echo get_the_post_thumbnail_url($post->ID); ?>" alt="" />
               <div class="sliderr"><?php the_title(); ?></div>
				
               <div class="slider-content"> <?php the_content(); ?></div>
			   
			 <div class="slider-btn">
				<a href="#" class="myButton">Call Us Now</a>
			 </div>
                
            </div>
<?php endforeach; 
wp_reset_postdata();?>
			
			
		
		
        </div>
        <!-- Bullet Navigator -->
        <div data-u="navigator" class="jssorb05" style="bottom:16px;right:16px;" data-autocenter="1">
            <!-- bullet navigator item prototype -->
            <div data-u="prototype" style="width:16px;height:16px;"></div>
        </div>
        <!-- Arrow Navigator -->
        <span data-u="arrowleft" class="jssora22l" style="top:0px;left:8px;width:40px;height:58px;" data-autocenter="2"></span>
        <span data-u="arrowright" class="jssora22r" style="top:0px;right:8px;width:40px;height:58px;" data-autocenter="2"></span>
    </div>
    <!-- Slider End -->
	
	
	<!-- Our Support Section starts -->
	<section class="our-support" id="feature">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="section-title">
						<h2>About Us</h2>
						<p>Lorem ipsum dolor sit amet</p>
					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-6 col-sm-6">
					<div class="support-image">
						<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/featureslid1.jpg" alt="" />
					</div>
				</div>
				
				<div class="col-md-6 col-sm-6">
					<div class="abt-con">
						<p class="text-justify"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Our Support Section Ends -->
		
	<!-- Features Section starts -->
	<section class="feature" id="support">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="section-title">
						<h2>Services</h2>
						<p>Lorem Ispum Tagline Goes here</p>
					</div>
				</div>
			</div>
			
			<div class="row">
		<?php

global $post;
$args = array( 'posts_per_page' => -1, 'post_type'  => 'services' );

$myposts = get_posts( $args );
foreach ( $myposts as $post ) : setup_postdata( $post ); 

?>			
				<!-- Feature single starts -->
				<div class="col-md-3 col-sm-6">
					<div class="feature-single " data-wow-delay="0.4s">
						<div class="icon-feature-single">
							<?php  echo html_entity_decode(get_field("icon"), ENT_QUOTES); ?>	
						</div>						
						<h3><?php the_title(); ?></h3>
						<p><?php the_content(); ?></p>
					</div>
				</div>
				<?php endforeach; 
				wp_reset_postdata();?>
				<!-- Feature single ends -->
			</div>
			
		</div>
	</section>
	<!-- Features Section Ends -->
	
	<!-- Our Support Section starts -->
	<section class="our-support" id="support">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="section-title">
						<h2>Frequently asked questions</h2>
						<p>Lorem ipsum dolor sit amet</p>
					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-6 col-sm-6">
					<div class="support-image">
						<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/support.jpg" alt="" />
					</div>
				</div>
				
				<div class="col-md-6 col-sm-6">
					<div class="faq-support">
						<!-- FAQ Accordion starts -->
						<div class="panel-group" id="accordion">
						
							<?php

					global $post;
					$args = array( 'posts_per_page' => -1, 'post_type'  => 'faq' );

					$myposts = get_posts( $args );
					$i=1;
					foreach ( $myposts as $post ) : setup_postdata( $post ); 

					if($i==1)
					{
						$class="in";
					}
					else
					{
						$class="";
					}

					?>
						
							<div class="panel">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#collapse<?php echo $i; ?>" data-toggle="collapse" data-parent="#accordion"><?php echo $i; ?>. <?php the_title(); ?></a></h4>
								</div>
								
								<div id="collapse<?php echo $i; ?>" class="panel-collapse collapse ">
									<div class="panel-body">
										<p><?php the_content(); ?></p>
									</div>
								</div>
							</div>
							
							<?php $i++; endforeach; 
				wp_reset_postdata();?>
							
						</div>
						<!-- FAQ Accordion ends -->
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Our Support Section Ends -->
	
	<!-- Testimonials -->
        <div class="testimonials-container section-container section-container-image-bg">
	        <div class="container">
	            <div class="row">
					<div class="col-lg-12">
						<div class="section-title sec-test">
							<h2>Testimonials</h2>
							<p>Lorem ipsum dolor sit amet</p>
						</div>
					</div>
			    </div>
	            <div class="row">
	                <div class="col-sm-10 col-sm-offset-1 testimonial-list">
	                	<div role="tabpanel">
	                		<!-- Tab panes -->
	                		<div class="tab-content">
							<?php

global $post;
$args = array( 'posts_per_page' => -1, 'post_type'  => 'testimonial' );

$myposts = get_posts( $args );
$i=0;
foreach ( $myposts as $post ) : setup_postdata( $post ); 

if($i==0)
{
	$class="active";
}
else
{
	$class="";
}
?>
	                			<div role="tabpanel" class="tab-pane fade in <?php echo $class; ?>" id="tab<?php echo $i; ?>">
	                				<div class="testimonial-image">
	                					<img src="<?php echo get_the_post_thumbnail_url($post->ID); ?>" alt="" data-at2x="<?php echo get_the_post_thumbnail_url($post->ID); ?>">
	                				</div>
	                				<div class="testimonial-text">
		                                <p>
		                                	<?php the_content(); ?><br>
		                                	
		                                </p>
	                                </div>
	                			</div>
								<?php 
								$i++;
								endforeach; 
				wp_reset_postdata();?>
	                			
	                		</div>
	                		<!-- Nav tabs -->
	                		<ul class="nav nav-tabs" role="tablist">
	                			<li role="presentation" class="active">
	                				<a href="#tab1" aria-controls="tab1" role="tab" data-toggle="tab"></a>
	                			</li>
	                			<li role="presentation">
	                				<a href="#tab2" aria-controls="tab2" role="tab" data-toggle="tab"></a>
	                			</li>
	                			<li role="presentation">
	                				<a href="#tab3" aria-controls="tab3" role="tab" data-toggle="tab"></a>
	                			</li>
	                			<li role="presentation">
	                				<a href="#tab4" aria-controls="tab4" role="tab" data-toggle="tab"></a>
	                			</li>
	                		</ul>
	                	</div>
	                </div>
	            </div>
	        </div>
        </div>
	
	<!-- Contact us Section starts -->
	<section class="contact-us" id="contact">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="section-title">
						<h2>Get in <span>Touch</span></h2>
						<p>Lorem Ipsum is simply dummy text of the printing</p>
					</div>
				</div>
			</div>
			
			<!-- Contact form starts -->
			<div class="contact-form">
				<form id="contactForm" action="#" method="post" data-toggle="validator" class="scroll-reveal">
					<div class="row">
						<div class="form-group col-md-6">
							<input type="text" name="name" id="name" class="form-control" placeholder="Your Name" required="">
							<div class="help-block with-errors"></div>
						</div>
						
						<div class="form-group col-md-6">
							<input type="email" name="email" id="email" class="form-control" placeholder="Your Email Address" required="">
							<div class="help-block with-errors"></div>
						</div>
						
						<div class="form-group col-md-12">
							<textarea rows="8" name="message" id="message" class="form-control" placeholder="Your Message" required=""></textarea>
							<div class="help-block with-errors"></div>
						</div>
						
						<div class="col-md-12 text-center">
							<div id="msgSubmit" class="h3 text-center hidden"></div>
							<button type="submit" name="submit" class="btn-custom btn-fill btn-contact" title="Submit Your Message!"><i class="fa fa-send"></i> Send</button>
						</div>
					</div>
				</form>
			</div>
			<!-- Contact form ends -->
			
		</div>
	</section>
	<!-- Contact us Section Ends -->
	
	 <!-- Disclaimer -->
    <section id="disclaimer">
      <div class="container">
         <div class="row">
            <div class="col-md-12">
               <span> Disclaimer </span>
                 <p> At Asus help support, we have been developing and rendering tailor-made solutions and support services for all of Asus products, including laptops, computers, printers, tablets or other devices. </p>
            </div>
         </div>
       </div>
    </section>

<?php get_footer(); ?>
