<?php
ini_set('default_charset', 'utf-8');
session_start();
$file=$_SESSION['file'];
header('Content-Type: text/html; charset=utf-8');
header('Content-Disposition: attachment; filename="sitemap.xml"');
echo htmlspecialchars_decode($file);
?>