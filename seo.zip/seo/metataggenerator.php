<?php
if(isset($_POST))
{
	$title=$_POST['title'];
	$des=$_POST['description'];
	$keywords=$_POST['Keyword'];
}

?>

<?php include("header.php"); ?>
<!DOCTYPE html>
<html>
<head>
<title>Meta Tag Generator</title>



</head>
<body>

 <!DOCTYPE html>
<html>
<head>
<title></title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">


</head>
<body>


        <div class="row">
            <div class="col-lg-12">
                
               
              

                   <div class="container profile-c pro-tfn">
						<div class="row">
						
							<div class="col-md-7 col-md-offset-2 ">
							 
							 <div class="loginmodal-container" style="max-width: 600px;">
							 <div class="form-group" style="border: 1px solid black; padding:10px;">
											<?php echo htmlspecialchars('<meta name="title" content="'.$title.'">');?>  <br>
											<?php echo htmlspecialchars('<meta name="description" content="'.$des.'">');?> <br>
											<?php echo htmlspecialchars('<meta  name="keywords" content="'.$keywords.'">');?>  <br>
										</div>
									
										
										<a href="metatag.php" name="login" style="background-color: #1eb0bc; color: white; padding: 10px;" class="login loginmodal-submit sky-color" > TRY NEW DOCUMENT</a>
									

								</div>
							</div>
						</div>
					</div>
                </div>
            </div>
        



<?php include("footer.php"); ?>