<?php include("header.php"); ?>
<!DOCTYPE html>
<html>
<head>
<title></title>



</head>
<body>

 
<div class="container top-mar">
		<div class="row">
			
			
			
			<div class="col-md-6 pro-center">
				<a href="metatag.php">
					<div class="admin card">
						<div class="card-3">
								<img src="image/meta_tag_generator.png" class="img-responsive center-block" />
						</div>
					</div>
					<p> Meta Tag Generator </p>
				</a>
			</div>
			
			<div class="col-md-2 pro-center">
				<a href="url.php">
					<div class="admin card">
						<div class="card-3">
								<img src="image/sitemap.png" class="img-responsive center-block" />
						</div>
					</div>
					<p> XML Site Map Generator </p>
				</a>
			</div>
		
		</div>
	</div>


<?php include("footer.php"); ?>