<?php include("functions.php");
$row=$lib->query("SELECT  `domain_name`, `host`, `uname`, `password`, `userid`, `start_date`, `end_date` FROM `domains` WHERE 1");
$rw=$row->fetchAll(PDO::FETCH_ASSOC);
//echo "<pre>";print_r($rw);
$lib->array_to_csv_download($rw, $filename = "export.csv", $delimiter=",");
?>