<?php ob_start(); session_start(); 
include("functions.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>CSV IMPORTER</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	
  </head>
  <body>
  <?php if(@$_SESSION['loggedIn']=="yes")
  {
	 // print_r($_SESSION);
	  $msg="Welcome ".ucwords($_SESSION['userInfo']['username'])."!";
  }
  if(@$_GET['action']=="logout")
  {
	  unset($_SESSION['userInfo']);
	  unset($_SESSION['loggedIn']);
	  header("Location:".$lib->base_url."login.php");
  }
   $curl=$lib->current_url;
  
  $arr=array($lib->base_url."login.php");
  if(in_array($curl,$arr) && @$_SESSION['loggedIn']=="yes")
  {
	  header("Location:".$lib->base_url."index.php");
  }
  
  if(!in_array($curl,$arr) && @$_SESSION['loggedIn']=="")
  {
	  header("Location:".$lib->base_url."login.php");
  }
  
  if($_SESSION['userInfo']['role']!="admin")
  {
  ?>
  <style>
		.table tr th:nth-child(9), .table tr td:nth-child(9), .table tr th:nth-child(10), .table tr td:nth-child(10)
		{
			display:none;
		}
	</style>
  <?php } ?>
	
  
	<nav class="navbar navbar-inverse">
	  <div class="container">
		<div class="navbar-header">
		  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span> 
		  </button>
		  <a class="navbar-brand" href="index.php">CSV IMPORTER</a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
		  <ul class="nav navbar-nav navbar-right">
			<li><a href="javascript:void(0);"><p><?php echo @$msg; ?></p></a></li>
			<li><a href="index.php">Home</a></li>
			 <li><a href="<?php echo $lib->base_url; ?>?action=logout">Logout</a></li>
			<li><a href="<?php echo $lib->base_url; ?>edit.php?action=edit_profile">Edit Profile</a></li> 
			<!--<li><a href="#">Page 3</a></li> -->
		  </ul>
		</div>
	  </div>
	</nav>