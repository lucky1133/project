-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 11, 2017 at 08:08 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `rating` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `asin` varchar(255) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `review` varchar(255) NOT NULL,
  `test` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `rating`, `title`, `author`, `type`, `asin`, `tags`, `review`, `test`) VALUES
(1, '0', 'The jhgjh Third Secret', 'Steve Berry', 'Book', '0340899263', '', 'need to find time to read this book', 'test'),
(2, '0', 'The Third Secret', 'Steve Berry', 'Book', '0340899262', '', 'need to find time to read this book', 'test'),
(3, '3', 'The Last Templar', 'Raymond Khoury', 'Book', '0752880705', '', '', ''),
(4, '5', 'The Traveller', 'John Twelve Hawks', 'Book', '059305430X', '', '', ''),
(5, '4', 'Crisis Four', 'Andy Mcnab', 'Book', '0345428080', '', '', ''),
(6, '5', 'Prey', 'Michael Crichton', 'Book', '0007154534', '', '', ''),
(7, '3', 'The Broker (Paperback)', 'John Grisham', 'Book', '0440241588', 'book johngrisham', 'good book, but is slow in the middle', ''),
(8, '3', 'Without Blood (Paperback)', 'Alessandro Baricco', 'Book', '1841955744', '', '', ''),
(9, '5', 'State of Fear (Paperback)', 'Michael Crichton', 'Book', '0061015733', '', '', ''),
(10, '4', 'The Rule of Four (Paperback)', 'Ian Caldwell', 'Book', '0099451956', 'book bestseller', '', ''),
(11, '4', 'Deception Point (Paperback)', 'Dan Brown', 'Book', '0671027387', 'book danbrown bestseller', '', ''),
(12, '5', 'Digital Fortress : A Thriller (Mass Market Paperback)', 'Dan Brown', 'Book', '0312995423', 'book danbrown bestseller', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `domains`
--

CREATE TABLE `domains` (
  `id` int(11) NOT NULL,
  `domain_name` varchar(255) NOT NULL,
  `host` varchar(255) NOT NULL,
  `uname` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `userid` varchar(255) NOT NULL,
  `start_date` varchar(255) NOT NULL,
  `end_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `domains`
--

INSERT INTO `domains` (`id`, `domain_name`, `host`, `uname`, `password`, `userid`, `start_date`, `end_date`) VALUES
(15, 'google.com', 'google', 'tarsem', 'admin@12', '1001', '10/10/2017', '10/10/2018'),
(16, 'google1.com', 'google', 'tarsem', 'admin@12', '1001', '10/10/2017', '10/10/2018');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `role`) VALUES
(1, 'admin', 'admin@12', 'admin@gmail.com', 'admin'),
(2, 'sukhi', '123456', 'sukhi@gmail.com', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `domains`
--
ALTER TABLE `domains`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `domains`
--
ALTER TABLE `domains`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
