<?php include("header.php"); ?>
  
<?php
require_once('parsecsv.lib.php');
if(@$_FILES['csv']['name']!="")
{
	//echo "sdfsdf";
	$csv = new parseCSV();
	$file=$_FILES['csv']['tmp_name'];
	$filename=$_FILES['csv']['name'];
	$ffile=explode(".",$filename);
	if($ffile[1]=="csv")
	{
	$csv->parse($file);
	foreach($csv->data as $key => $row):
		$rw=$lib->query("select count(*) as num from domains where domain_name='".$row['domain_name']."'");
		$rww=$rw->fetch(PDO::FETCH_LAZY);
		$count=$rww['num'];
		if($count==0)
		{
			$lib->insert($row,"domains");
		}
		else
		{
			$lib->updatewhere($row,"domains",array("domain_name"=>$row['domain_name']));
		}
	endforeach;
	}
	else{
		$msg2 ="Pleas upload csv file only!";
	}
}
?>

<style>
.image-preview-input {
    position: relative;
	overflow: hidden;
	margin: 0px;    
    color: #333;
    background-color: #fff;
    border-color: #ccc;    
}
.image-preview-input input[type=file] {
	position: absolute;
	top: 0;
	right: 0;
	margin: 0;
	padding: 0;
	font-size: 20px;
	cursor: pointer;
	opacity: 0;
	filter: alpha(opacity=0);
}
.image-preview-input-title {
    margin-left:2px;
}

.popover
{
	display:none !important;
}
</style>

<div class="container p-row">
	<div class="row">
		<div class="col-md-12">
			<form method="post" enctype="multipart/form-data">
				<div class="col-md-3" style="padding-left:0px;">
					<div class="form-group">
						<?php echo @$msg2; ?>
							<!-- 123 -->
								  <div class="input-group image-preview">
									<input type="text" name="csv" class="form-control image-preview-filename" disabled="disabled"> <!-- don't give a name === doesn't send on POST/GET -->
									<span class="input-group-btn">
										<!-- image-preview-clear button -->
										<button type="button" class="btn btn-primary image-preview-clear" style="display:none;">
											<span class="glyphicon glyphicon-remove"></span> Clear
										</button>
										<!-- image-preview-input -->
										<div class="btn btn-primary image-preview-input">
											<span class="glyphicon glyphicon-folder-open"></span>
											<span class="image-preview-input-title">Browse</span>
											<input type="file" name="csv" accept=".csv" /> <!-- rename it -->
										</div>
									</span>
								</div><!-- /input-group image-preview [TO HERE]-->
							<!-- asad -->
					</div>
				</div>
				<div class="col-md-5">
					<input type="submit" class="btn btn-primary" name="submit" />
					<a href="edit.php?action=add" class="btn btn-success">Add New</a>
					<a href="csv.php" class="btn btn-success">Export as CSV</a>
				</div>
				</form>
				<div class="col-md-4 text-right" style="padding-right:0px;">
					<form method="get">
						<div class="input-group " style="width: 75%; float: left; margin-right: 18px;">
						  <input type="text" name="keyword" class="form-control" value="<?php echo $_GET['keyword'];?>" placeholder="Search for...">
						  <span class="input-group-btn" style="margin-right:5px;">
							<button class="btn btn-primary"  type="submit">Search</button>
						  </span>
						 
						</div>
						<div class="input-group">
						 <span class="input-group-btn">
							<button class="btn btn-primary" id="form1" type="button" onclick="window.location.href='<?php echo $lib->base_url; ?>'">Reset</button>
						  </span>
						 </div>
					</form>
				</div>
			
			
		</div>
	
	</div>
	
	<div class="row">
		<div class="col-md-12">
			<?php $lib->showfunction("domains","edit.php?action=edit","edit.php?action=delete"); ?>
		</div>
			
		
	</div>
</div>


<?php include("footer.php"); ?>