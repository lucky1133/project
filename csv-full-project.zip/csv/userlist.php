<?php ob_start(); session_start(); 
include("header.php");
if($_GET['action']=="edit")
{
	$lib->editfunction("users",$_GET['id'],$lib->base_url."userlist.php");
}
else
{
	$lib->showfunction("users","?action=edit","?action=delete");
}

include("footer.php");
 ?>