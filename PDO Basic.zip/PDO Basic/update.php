<?php

$host = "localhost";
$username = "root";
$password = "";
$dbname = "pdo";

try
{
	$con = new PDO ("mysql:host=$host;dbname=$dbname",$username, $password);
	$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch (PDOException $e)
{
	echo "Error".$e->getMessage();
}

	if(isset($_POST['submit']))
	{
		$edit_id = $_GET['edit_id'];
		$email = $_POST['email'];
		$pass = $_POST['pass'];
		$subject = $_POST['subject'];
		
		$insert = $con->prepare("UPDATE users SET email=:email,pass=:pass,subject=:subject where id=$edit_id");
		$insert->bindParam(":email",$email, PDO::PARAM_STR);
		$insert->bindParam(":pass",$pass, PDO::PARAM_STR);
		$insert->bindParam(":subject",$subject, PDO::PARAM_STR);
		if($insert->execute())
		{
			echo "Success";
			header("Location: select.php");
		}
		else
		{
			echo "Not";
		}
		
		
	
		
	}
?>

<form method="post">
	<input type="text" name="email" id="email" />
	<input type="password" name="pass" id="pass" />
	<input type="text" name="subject" id="subject" />
	<input type="submit" name="submit" id="submit" />
</form>