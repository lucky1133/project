<?php

$host = "localhost";
$username = "root";
$password = "";
$dbname = "pdo";

try
{
	$con = new PDO ("mysql:host=$host;dbname=$dbname",$username, $password);
	$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch (PDOException $e)
{
	echo "Error".$e->getMessage();
}

	$del_id = $_GET['del_id'];
	
	$delete = $con->prepare("delete from users where id=$del_id");
	$delete->execute();
	header("Location: select.php");
	
?>

