<?php

$host = "localhost";
$username = "root";
$password = "";
$dbname = "pdo";

try
{
	$con = new PDO ("mysql:host=$host;dbname=$dbname",$username, $password);
	$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch (PDOException $e)
{
	echo "Error".$e->getMessage();
}

	if(isset($_POST['submit']))
	{
		$email = $_POST['email'];
		$pass = $_POST['pass'];
		$subject = $_POST['subject'];
		
		$insert = $con->prepare("INSERT INTO users (email,pass,subject) VALUES (:email,:pass,:subject)");
		$insert->bindParam(":email",$email);
		$insert->bindParam(":pass",$pass);
		$insert->bindParam(":subject",$subject);
		if($insert->execute())
		{
			echo "Success";
		}
		else
		{
			echo "Not";
		}
		
	}
?>

<form method="post">
	<input type="text" name="email" id="email" />
	<input type="password" name="pass" id="pass" />
	<input type="text" name="subject" id="subject" />
	<input type="submit" name="submit" id="submit" />
</form>