<table border="1">
<tr>
	<td> ID </td>
	<td> Email </td>
	<td> Password </td>
	<td> Subject </td>
	<td> Edit </td>
	<td> Delete </td>
</tr>

<?php

$host = "localhost";
$username = "root";
$password = "";
$dbname = "pdo";

try
{
	$con = new PDO ("mysql:host=$host;dbname=$dbname", $username, $password);
	$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}

catch (PDOException $e)
{
	echo "Error".$e->getMessgae();
}
	
	$select = $con->prepare("select * from users");
	$select->setFetchMode(PDO::FETCH_ASSOC);
	$select->execute();
	while($data=$select->fetch())
	{
		
	?>
<tr>
		<td> <?php echo $data['id']; ?> </td>
		<td> <?php echo $data['email']; ?> </td>
		<td> <?php echo $data['pass']; ?> </td>
		<td> <?php echo $data['subject']; ?> </td>
		<td> <a href="update.php?edit_id=<?php echo $data['id']; ?>"> Edit </a> </td>
		<td> <a href="delete.php?del_id=<?php echo $data['id']; ?>"> Delete </a> </td>
</tr>
	
<?php } ?>
</table>
