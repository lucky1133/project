<?php

	$host = "localhost";
	$username = "root";
	$password = "";
	$dbname = "pdo";
	
	try
	{
		$con = new PDO ("mysql:host=$host;dbname=$dbname",$username,$password);
		$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	
	catch (PDOException $e)
	{
		echo "Error".$e->getMessage();
	}
	
	$del_id = $_GET['del_id'];
	$delete = $con->prepare("DELETE from users where id='$del_id'");
	if($delete->execute())
	{
		echo "<script> window.open('select.php?del=Delete Succesfully','_self') </script>";
	}
	
?>

<form method="post">
	<input type="text" name="email" id="email" />
	<input type="password" name="pass" id="pass" />
	<input type="text" name="subject" id="subject" />
	<input type="submit" name="submit" id="submit" />
</form>