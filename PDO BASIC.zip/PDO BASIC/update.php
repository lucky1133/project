<?php

	$host = "localhost";
	$username = "root";
	$password = "";
	$dbname = "pdo";
	
	try
	{
		$con = new PDO ("mysql:host=$host;dbname=$dbname",$username,$password);
		$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	
	catch (PDOException $e)
	{
		echo "Error".$e->getMessage();
	}
	
	$edit_id = $_GET['edit_id'];
	$select = $con->prepare("SELECT * from users where id='$edit_id'");
	$select->setFetchMode(PDO::FETCH_ASSOC);
	$select->execute();
	while($data = $select->fetch())
	{
		$email = $data['email'];
		$pass = $data['pass'];
		$subject = $data['subject'];
	}
	
	if(isset($_POST['submit']))
	{
		$edit_id = $_GET['edit_id'];
		$email = $_POST['email'];
		$password = $_POST['pass'];
		$subject = $_POST['subject'];
		
		$insert = $con->prepare("UPDATE users SET email=:email,pass=:pass,subject=:subject where id='$edit_id' ");
		$insert->bindParam(":email",$email);
		$insert->bindParam(":pass",$password);
		$insert->bindParam(":subject",$subject);
		if($insert->execute())
		{
			echo "<script> window.open('select.php?edit=Edit Has Been Succesfully','_self'); </script>";
		}
		
	}
	
		
?>

<form method="post">
	<input type="text" name="email" value="<?php echo $email; ?>" id="email" />
	<input type="text" name="pass" value="<?php echo $pass; ?>" id="pass" />
	<input type="text" name="subject" value="<?php echo $subject; ?>" id="subject" />
	<input type="submit" name="submit" id="submit" />
</form>


