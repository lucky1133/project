
<table border="1" cellpadding="10px" style="margin:0 auto;">
	<caption> Insert Delete Edit </caption>
	<tr>
		<td> Sr.No </td>
		<td> Email </td>
		<td> Password </td>
		<td> Subject </td>
		<td> Edit </td>
		<td> Delete </td>
	</tr>
<?php

	$host = "localhost";
	$username = "root";
	$password = "";
	$dbname = "pdo";
	
	try
	{
		$con = new PDO ("mysql:host=$host;dbname=$dbname",$username,$password);
		$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	
	catch (PDOException $e)
	{
		echo "Error".$e->getMessage();
	}
	
	$select = $con->prepare("SELECT * from users");
	$select->setFetchMode(PDO::FETCH_ASSOC);
	$select->execute();
	$c= "";
	while($data = $select->fetch())
	{
		$c++;
		$id = $data['id'];
		$email = $data['email'];
		$pass = $data['pass'];
		$subject = $data['subject'];
	?>
	
<tr>
	<td> <?php echo $c; ?> </td>
	<td> <?php echo $email; ?> </td>
	<td> <?php echo $pass; ?> </td>
	<td> <?php echo $subject; ?> </td>
	<td> <a href="update.php?edit_id=<?php echo $id; ?>"> Edit </a> </td>
	<td> <a href="delete.php?del_id=<?php echo $id; ?>"> Delete </a> </td>
	
	
</tr>

	
<?php } ?>

<tr>
	<td colspan="6" align="center"> <?php echo @$_GET['del']; ?> <?php echo @$_GET['edit']; ?> </td>
</tr>

</table>
