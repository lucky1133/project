<?php
	$host = "localhost";
	$username = "root";
	$password = "";
	$dbname = "ajax";
	
	$con = mysqli_connect($host,$username,$password);
	mysqli_select_db($con,$dbname) or die ("not connebted".mysql_error($con));
	
?>