<?php 
	//print_r($_POST);
	
	include("connection.php");
if($_GET['action']=="insert")
{
	$email = $_POST['email'];
	$pass = $_POST['pass'];
	
	$query = ("INSERT into user (email,pass) VALUES ('$email','$pass')").mysqli_error($con);
	
	mysqli_query($con,$query);
	

}
if($_GET['action']=="del")
{
	$del = $_GET['id'];
	$sql = "DELETE from user where id='$del'";
	mysqli_query($con,$sql)or die(mysqli_error($con)); 
}

if($_GET['action']=="show")
{
?>

<table border="1">
	<tr>
		<th> Sr.No </th>
		<th> Email </th>
		<th> Password </th>
		<th> Edit </th>
		<th> Delete </th>
	</tr>
	
<?php 

	$select = "SELECT * from user order by id desc";
	$sql = mysqli_query($con,$select);
	$c= "";
	$i=1;
	while($row=mysqli_fetch_assoc($sql))
	{
		$c++;
		$id =  $row['id'];
		$email =  $row['email'];
		$pass = $row['pass'];
	?>
	<tr>
		<td> <?php echo $c; ?> </td>
		<td> <?php echo $email; ?> </td>
		<td> <?php echo $pass; ?> </td>
		<td> <a href="javascript:void(0)" onclick="updatess('<?php echo $id; ?>','<?php echo $i; ?>')"> Edit </a> </td>
		<td> <a href="javascript:void(0)" onclick="deletes('<?php echo $id; ?>')"> Delete </a> </td>
	</tr>
	<?php $i++;
	} ?>

</table>
<?php }

if($_GET['action']=="update")
{
	$email = $_POST['email'];
	$pass = $_POST['pass'];
	
	$query = "update user  set email='$email',pass='$pass' where id='".$_GET['id']."' ";
	
	mysqli_query($con,$query)or die(mysqli_error($con));
}
?>
