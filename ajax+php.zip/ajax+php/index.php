<?php 
	include("connection.php");
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  
    <title>Practive</title>

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
	
	<style>
		 #div1 {
			width: 50px;
			height: 70px;
			float: left;
			margin: 5px;
			background: rgb(255,140,0);
			cursor: pointer;
		  }
		  
		.newcolor 
		{
			background: blue;
			color:#fff;
		}
	</style>
  </head>
  <body>
	
	<div class="container">
		<div class="row">
			<div class="col-md-12">
					<input type="email" id="email" name="email" value="" placeholder="Enter Email" />
					<input type="text" id="pass" name="pass" value="" placeholder="Enter Password" />
					<button type="button" id="submit"> ADD </button>
					<input type="text" id="semail" name="serach"/>
					<input type="text" id="spwd" name="serach"/>
					<button type="button" id="search" onclick="search();"> Search </button>
					<button type="button" id="editsss"> Edit </button>
			</div>
			
			<br><br>
			
			<style>
				table tr td
				{
					padding:10px;
				}
			</style>
			
			<div id="data">
			

			<table border="1">
				<tr>
					<th> Sr.No </th>
					<th> Email </th>
					<th> Password </th>
					<th> Edit </th>
					<th> Delete </th>
				</tr>
			<?php 

				$select = "SELECT * from user order by id desc";
				$sql = mysqli_query($con,$select);
				$c= "";
				$i=1;
				while($row=mysqli_fetch_assoc($sql))
				{
					$c++;
					$id =  $row['id'];
					$email =  $row['email'];
					$pass = $row['pass'];
				?>
				<tr>
					<td> <?php echo $c; ?> </td>
					<td> <?php echo $email; ?> </td>
					<td> <?php echo $pass; ?> </td>
					<td> <a href="javascript:void(0)" onclick="updatess('<?php echo $id; ?>','<?php echo $i; ?>')"> Edit </a> </td>
					<td> <a href="javascript:void(0)" onclick="deletes('<?php echo $id; ?>')"> Delete </a> </td>
				</tr>
				<?php $i++;
				} ?>

			</table>


			</div>
	
			
		</div>
	</div>
	
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
	<script>
		function show()
		{
			$.ajax({
				  method: "get",
				  url: "p.php?action=show",
				  success : function(html){
					$("#data").html(html);
				}
			});
		}
		function search()
		{
		
				var semail = $("#semail").val();
				var spwd = $("#spwd").val();
				
				$.ajax({
				  method: "POST",
				  url: "p.php?action=search",
				  data: {semail:semail,spwd:spwd},
				  success : function(html){
					$("#data").html(html);
				}
			});
		
		}
		
		$(document).ready(function(){
			$("#submit").click(function(){
				var email = $("#email").val();
				var pass = $("#pass").val();
				$.ajax({
				  method: "POST",
				  url: "p.php?action=insert",
				  data: {email:email,pass:pass},
				  success : function(html){
					show();
				}
			});
		  });
		});
		  
		function deletes(id)
		{
			$.ajax({
				  method: "POST",
				  url: "p.php?action=del&id="+id,
					success : function(html){
				  show();
				}
			});
		}
		
		function updatess(id,row)
		{
			//alert("update");
			var current_row_email=$("table tr:eq("+row+") td:eq(1)").html();
			var current_row_password=$("table tr:eq("+row+") td:eq(2)").html();
			
			localStorage.setItem("email",current_row_email);
			localStorage.setItem("pwd",current_row_password);
			localStorage.setItem("id",id);
			
			var lemail=localStorage.getItem("email");
			var pwd=localStorage.getItem("pwd");
			var id=localStorage.getItem("id");
			
			var email = $("#email").val(lemail);
			var pass = $("#pass").val(pwd.trim());
			
			$("#submit").hide();
			$("#spwd").hide();
			$("#semail").hide();
			$("#search").hide();
			$("#editsss").show();
		}
		
		
		$(document).ready(function(){
			$("#editsss").hide();
				$("#editsss").click(function(){
					
				var email = $("#email").val();
				var pass = $("#pass").val();
				var id=localStorage.getItem("id");
					
				$.ajax({
					method: "POST",
					url: "p.php?action=update&id="+id,
					data: {email:email,pass:pass},
					success : function(html){
						 
					show();
					$("#submit").show();
					var email = $("#email").val("");
					var pass = $("#pass").val("");
					 
					localStorage.removeItem("email");
					localStorage.removeItem("pwd");
					localStorage.removeItem("id");
					 
					$("#editsss").hide();
					$("#search").hide();
					$("#spwd").hide();
					$("#semail").hide();
					}
				});
			});
		});
	
	</script>
	
  </body>
</html>