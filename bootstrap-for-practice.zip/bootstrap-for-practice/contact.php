<?php include("inc/connection.php"); ?>
<?php include("inc/header.php"); ?>

	<div class="jumbotron">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="details animated fadeInLeft">
						<h1> Lucky <span> Blog </span> </h1>
						<p> This is the Huge Website. </p>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<section> 
		<div class="container">
			<div class="row">
				<div class="col-md-8"> 
					<div class="map">
						<img src="images/map.jpg" class="img-responsive" />
					</div>
					
					<div class="form">
						<form method="post" action="">
							<div class="form-group">
								<label> Full Name* </label>
								<input type="text" class="form-control" id="name" name="name" placeholder="Please Enter Your Name" />
							</div>
							
							<div class="form-group">
								<label> Email* </label>
								<input type="email" class="form-control" id="email" name="email" placeholder="Please Enter Your Email" />
							</div>
							
							<div class="form-group">
								<label> Website* </label>
								<input type="text" class="form-control" id="website" name="website" placeholder="Please Enter Your Website" />
							</div>
							
							<div class="form-group">
								<label> Message* </label>
								<textarea id="message" cols="30" rows="10" class="form-control" placeholder="Message Should Be Here"> </textarea>
							</div>
							
							<input type="submit" name="submit" class="btn btn-info" id="submit" value="Submit" />
						</form>
					</div>
				</div>
			
				<div class="col-md-4">
					<div class="widget">
						 <div class="input-group">
						  <input type="text" class="form-control" placeholder="Search for...">
						  
						  <span class="input-group-btn">
							<button class="btn btn-default" type="button">Search</button>
						  </span>
						</div><!-- /input-group -->
					</div>
					
					<div class="widget">
					   <div class="popular-post">
					     <div class="pop">
						  <h3 class="m-head"> Popular Post </h3>
						  <hr>
						  <div class="row">
							 <div class="col-xs-4">
								<a href="#"> <img src="images/jumbo.jpg" class="img-responsive"> </a>
							 </div>
							 <div class="col-xs-8 mar-heading">
								<h3> <a href="#"> This is heading </a> </h3>
								<p> <i class="fa fa-clock-o"></i> 10 January, 2017 </p>
							 </div>
						  </div>
						 </div>
						 
						 <div class="pop">
						 
						  <div class="row">
							<div class="col-xs-4">
								<a href="#"> <img src="images/jumbo.jpg" class="img-responsive"> </a>
							 </div>
							 <div class="col-xs-8 mar-heading">
								<h3> <a href="#"> This is heading </a> </h3>
								<p> <i class="fa fa-clock-o"></i> 10 January, 2017 </p>
							 </div>
						  </div>
						 </div>
						 
						 <div class="pop">
						 
						  <div class="row">
							<div class="col-xs-4">
								<a href="#"> <img src="images/jumbo.jpg" class="img-responsive"> </a>
							 </div>
							 <div class="col-xs-8 mar-heading">
								<h3> <a href="#"> This is heading </a> </h3>
								<p> <i class="fa fa-clock-o"></i> 10 January, 2017 </p>
							 </div>
						  </div>
						 </div>
					   </div>
					 </div> <!--  Popular Post -->
					 
					 <div class="widget">
					   <div class="popular-post">
					     <div class="pop">
						  <h3 class="m-head"> Recent Post </h3>
						  <hr>
						  <div class="row">
							<div class="col-xs-4">
								<a href="#"> <img src="images/jumbo.jpg" class="img-responsive"> </a>
							 </div>
							 <div class="col-xs-8 mar-heading">
								<h3> <a href="#"> This is heading </a> </h3>
								<p> <i class="fa fa-clock-o"></i> 10 January, 2017 </p>
							 </div>
						  </div>
						 </div>
						 
						 <div class="pop">
						 
						  <div class="row">
							<div class="col-xs-4">
								<a href="#"> <img src="images/jumbo.jpg" class="img-responsive"> </a>
							 </div>
							 <div class="col-xs-8 mar-heading">
								<h3> <a href="#"> This is heading </a> </h3>
								<p> <i class="fa fa-clock-o"></i> 10 January, 2017 </p>
							 </div>
						  </div>
						 </div>
						 
						 <div class="pop">
						 
						  <div class="row">
							<div class="col-xs-4">
								<a href="#"> <img src="images/jumbo.jpg" class="img-responsive"> </a>
							 </div>
							 <div class="col-xs-8 mar-heading">
								<h3> <a href="#"> This is heading </a> </h3>
								<p> <i class="fa fa-clock-o"></i> 10 January, 2017 </p>
							 </div>
						  </div>
						 </div>
					   </div>
					 </div> <!-- Recent Post -->
					 
					 <div class="widget">
						<div class="popular-post">
					     <div class="pop">
						  <h3 class="m-head"> Popular Category </h3>
						  <hr>
						  <div class="row">
							 <div class="col-xs-6">
								<ul>
									<li> <a href="#"> Category </a> </li>
									<li> <a href="#"> Category </a> </li>
									<li> <a href="#"> Category </a> </li>
									<li> <a href="#"> Category </a> </li>
									<li> <a href="#"> Category </a> </li>
									<li> <a href="#"> Category </a> </li>
								</ul>
							 </div>
							 <div class="col-xs-6">
								<ul>
									<li> <a href="#"> Category </a> </li>
									<li> <a href="#"> Category </a> </li>
									<li> <a href="#"> Category </a> </li>
									<li> <a href="#"> Category </a> </li>
									<li> <a href="#"> Category </a> </li>
									<li> <a href="#"> Category </a> </li>
								</ul>
							 </div>
						  </div>
						 </div>
					   </div>
					 </div>
					 
					 
					 <div class="widget wid-bot">
						<div class="popular-post">
					     <div class="pop">
						  <h3 class="m-head"> Social Icon </h3>
						  <hr>
						  <div class="row">
							 	<div class="col-md-12">
								<ul class="social-network social-circle">
									<li><a href="#" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>
									<li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
									
								</ul>				
							</div>
						  </div>
						 </div>
					   </div>
					 </div>
					 
				</div>
			</div>
		</div>
	</section>
	
<?php include("inc/footer.php"); ?>