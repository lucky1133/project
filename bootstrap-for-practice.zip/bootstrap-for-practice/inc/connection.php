<?php
	
	$host = "localhost";
	$username = "root";
	$password = "";
	$db_name = "cms";
	
	$con = mysqli_connect($host,$username,$password);
	$run = mysqli_select_db($con,$db_name);
	
	if(!$run)
	{
		die ("Connection Error".mysqli_connect_error());
	}
?>