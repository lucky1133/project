<?php include("inc/connection.php"); ?>
<?php include("inc/header.php"); ?>
	
	<div class="jumbotron">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="details animated fadeInLeft">
						<h1> Custom <span> Post </span> </h1>
						<p> Here you can put your own tag line. </p>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<section> 
		<div class="container">
			<div class="row">
				<div class="col-md-8"> 
					<div class="post">
						<div class="row">
							<div class="col-md-2 col-xs-3 post-date"> 
								<div class="date"> 16 </div>
								<div class="month"> January </div>
								<div class="year"> 2017 </div>
							</div>
							<div class="col-md-7 col-xs-7 post-title"> 
								<a href="#"> <h2> This is heading for post one ... </h2> </a>
								<p> Written By : <span> Lucky </span> </p>
							</div>
							<div class="col-md-3 col-xs-12  profile-image"> 
								<img src="images/jumbo.jpg" class="img-responsive img-circle">
							</div>
						
						<div class="col-md-12 ">
						  <img src="images/jumbo.jpg" alt="" class="img-responsive">
						  <div class="content">
								
								<p class="desc"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>
								
								<a href="#" class="btn btn-info"> Read More </a>
								
								<div class="button">
									<a href="#"> <i class="fa fa-folder" aria-hidden="true"></i> Category </a> 
									<span> | </span>
									<a href="#"> <i class="fa fa-comment" aria-hidden="true"></i> Comment </a>
								</div>
								
							
							</div>
							
							
						</div>
					  </div>
					</div>
					<div class="post-img">
					    <h2> Related Post </h2>
						<div class="row">
							<div class="col-md-4">
							
								<img src="images/jumbo.jpg" class="img-responsive" />
								<a href=""><h3>This is the first Heading post.This is the first Heading post </h3> </a>
							</div>
							
							<div class="col-md-4">
								
								<img src="images/jumbo.jpg" class="img-responsive" />
								<a href=""><h3>This is the first Heading post. This is the first Heading post </h3> </a>
							</div>
							
							<div class="col-md-4">
								
								<img src="images/jumbo.jpg" class="img-responsive" />
								<a href=""><h3>This is the first Heading post. This is the first Heading post </h3> </a>
							</div> 
						 </div>
					</div>
					
					<div class="user-info">
						<div class="row">
							<div class="col-md-4">
								<img src="images/jumbo.jpg" class="img-responsive" />
							</div>
							<div class="col-md-8">
								<h3> <a href="#"> Lucky </a> </h3>
								<p class="text-justify"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived.</p>
						
							</div>
						</div>
					</div>
					
					<div class="post-img comment">
					    <h2> Comment </h2>
						<div class="row">
						  <div class="comment-mar">
							<div class="col-md-2">
								<img src="images/user.jpg" width="80px" class="img-responsive" />
							</div>
							
							<div class="col-md-10">
								<p class="text-justify"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. . </p>
							</div>
					      </div>
						  
						   <div class="comment-mar">
							<div class="col-md-2">
								<img src="images/user.jpg" width="80px" class="img-responsive" />
							</div>
							
							<div class="col-md-10">
								<p class="text-justify"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. . </p>
							</div>
					      </div>
						 </div>
					</div>
					
					<div class="comment-box">
						<div class="row">
							<div class="col-md-12">
								<div class="form">
						<form method="post" action="">
							<div class="form-group">
								<label> Full Name* </label>
								<input type="text" class="form-control" id="name" name="name" placeholder="Please Enter Your Name" />
							</div>
							
							<div class="form-group">
								<label> Email* </label>
								<input type="email" class="form-control" id="email" name="email" placeholder="Please Enter Your Email" />
							</div>
							
							<div class="form-group">
								<label> Website* </label>
								<input type="text" class="form-control" id="website" name="website" placeholder="Please Enter Your Website" />
							</div>
							
							<div class="form-group">
								<label> Message* </label>
								<textarea id="message" cols="30" rows="10" class="form-control" placeholder="Message Should Be Here"> </textarea>
							</div>
							
							<input type="submit" name="submit" class="btn btn-info" id="submit" value="Submit Comment" />
						</form>
					</div>
							</div>
						</div>
					</div>
					
					
					
				</div> <!-- Post -->
				
				<div class="col-md-4">
					<div class="widget">
						 <div class="input-group">
						  <input type="text" class="form-control" placeholder="Search for...">
						  
						  <span class="input-group-btn">
							<button class="btn btn-default" type="button">Search</button>
						  </span>
						</div><!-- /input-group -->
					</div>
					
					<div class="widget">
					   <div class="popular-post">
					     <div class="pop">
						  <h3 class="m-head"> Popular Post </h3>
						  <hr>
						  <div class="row">
							 <div class="col-xs-4">
								<a href="#"> <img src="images/jumbo.jpg" class="img-responsive"> </a>
							 </div>
							 <div class="col-xs-8 mar-heading">
								<h3> <a href="#"> This is heading </a> </h3>
								<p> <i class="fa fa-clock-o"></i> 10 January, 2017 </p>
							 </div>
						  </div>
						 </div>
						 
						 <div class="pop">
						 
						  <div class="row">
							<div class="col-xs-4">
								<a href="#"> <img src="images/jumbo.jpg" class="img-responsive"> </a>
							 </div>
							 <div class="col-xs-8 mar-heading">
								<h3> <a href="#"> This is heading </a> </h3>
								<p> <i class="fa fa-clock-o"></i> 10 January, 2017 </p>
							 </div>
						  </div>
						 </div>
						 
						 <div class="pop">
						 
						  <div class="row">
							<div class="col-xs-4">
								<a href="#"> <img src="images/jumbo.jpg" class="img-responsive"> </a>
							 </div>
							 <div class="col-xs-8 mar-heading">
								<h3> <a href="#"> This is heading </a> </h3>
								<p> <i class="fa fa-clock-o"></i> 10 January, 2017 </p>
							 </div>
						  </div>
						 </div>
					   </div>
					 </div> <!--  Popular Post -->
					 
					 <div class="widget">
					   <div class="popular-post">
					     <div class="pop">
						  <h3 class="m-head"> Recent Post </h3>
						  <hr>
						  <div class="row">
							<div class="col-xs-4">
								<a href="#"> <img src="images/jumbo.jpg" class="img-responsive"> </a>
							 </div>
							 <div class="col-xs-8 mar-heading">
								<h3> <a href="#"> This is heading </a> </h3>
								<p> <i class="fa fa-clock-o"></i> 10 January, 2017 </p>
							 </div>
						  </div>
						 </div>
						 
						 <div class="pop">
						 
						  <div class="row">
							<div class="col-xs-4">
								<a href="#"> <img src="images/jumbo.jpg" class="img-responsive"> </a>
							 </div>
							 <div class="col-xs-8 mar-heading">
								<h3> <a href="#"> This is heading </a> </h3>
								<p> <i class="fa fa-clock-o"></i> 10 January, 2017 </p>
							 </div>
						  </div>
						 </div>
						 
						 <div class="pop">
						 
						  <div class="row">
							<div class="col-xs-4">
								<a href="#"> <img src="images/jumbo.jpg" class="img-responsive"> </a>
							 </div>
							 <div class="col-xs-8 mar-heading">
								<h3> <a href="#"> This is heading </a> </h3>
								<p> <i class="fa fa-clock-o"></i> 10 January, 2017 </p>
							 </div>
						  </div>
						 </div>
					   </div>
					 </div> <!-- Recent Post -->
					 
					 <div class="widget">
						<div class="popular-post">
					     <div class="pop">
						  <h3 class="m-head"> Popular Category </h3>
						  <hr>
						  <div class="row">
							 <div class="col-xs-6">
								<ul>
									<li> <a href="#"> Category </a> </li>
									<li> <a href="#"> Category </a> </li>
									<li> <a href="#"> Category </a> </li>
									<li> <a href="#"> Category </a> </li>
									<li> <a href="#"> Category </a> </li>
									<li> <a href="#"> Category </a> </li>
								</ul>
							 </div>
							 <div class="col-xs-6">
								<ul>
									<li> <a href="#"> Category </a> </li>
									<li> <a href="#"> Category </a> </li>
									<li> <a href="#"> Category </a> </li>
									<li> <a href="#"> Category </a> </li>
									<li> <a href="#"> Category </a> </li>
									<li> <a href="#"> Category </a> </li>
								</ul>
							 </div>
						  </div>
						 </div>
					   </div>
					 </div>
					 
					 
					 <div class="widget wid-bot">
						<div class="popular-post">
					     <div class="pop">
						  <h3 class="m-head"> Social Icon </h3>
						  <hr>
						  <div class="row">
							 	<div class="col-md-12">
								<ul class="social-network social-circle">
									<li><a href="#" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>
									<li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
									
								</ul>				
							</div>
						  </div>
						 </div>
					   </div>
					 </div>
					 
				</div>
			</div>
		</div>
	</section>
	
<?php include("inc/footer.php"); ?>