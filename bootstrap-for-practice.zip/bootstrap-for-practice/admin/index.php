
	<p> <br> </p>
	<section> 
		<div class="container">
			<div class="row">
				<div class="col-md-3"> 
					<div class="list-group">
					  <a href="#" class="list-group-item active"> <i class="fa fa-tachometer"> </i> Dasboard </a>
					  <a href="index.php" class="list-group-item"><span class="badge">14</span> <i class="fa fa-file-text"> </i> All Post</a>
					  <a href="#" class="list-group-item"><span class="badge">20</span> <i class="fa fa-comment"> </i> Comments</a>
					  <a href="category.php" class="list-group-item"><span class="badge">14</span> <i class="fa fa-folder-open"> </i> Category</a>
					  <a href="#" class="list-group-item"><span class="badge">5</span> <i class="fa fa-user"> </i> User</a>
					</div>
				</div>	
				<div class="col-md-9 dash"> 
					<h1> <i class="fa fa-tachometer"> </i> Dasboard </h1> 
					<ol class="breadcrumb">
						<li class="active">  <i class="fa fa-tachometer"> </i> Dasboard  </li>
					</ol>
					
					<div class="row">
						<div class="col-md-6 col-lg-3">
							<div class="panel panel-primary">
								<div class="panel-heading">
									<div class="row">
										<div class="col-xs-3">
											<i class="fa fa-comments fa-5x"> </i>
										</div>
										
										<div class="col-xs-9">
											<div class="text-right huge"> 11 </div>
											<div class="text-right font-s"> New Comments </div>
										</div>
									
									</div>
									</div>	
									<a href="#">
									<div class="panel-footer">
										<span class="pull-left"> View All Comments </span>
										<span class="pull-right"> <i class="fa fa-arrow-circle-right"> </i> </span>
										<div class="clearfix"> </div>
									</div>
									</a>
							</div>
						</div>	
						
						
						<div class="col-md-6 col-lg-3">
							<div class="panel panel-danger">
								<div class="panel-heading">
									<div class="row">
										<div class="col-xs-3">
											<i class="fa fa-file-text fa-5x"> </i>
										</div>
										
										<div class="col-xs-9">
											<div class="text-right huge"> 28 </div>
											<div class="text-right font-s"> All Post </div>
										</div>
									
									</div>
									</div>	
									<a href="#">
									<div class="panel-footer">
										<span class="pull-left"> View All Post </span>
										<span class="pull-right"> <i class="fa fa-arrow-circle-right"> </i> </span>
										<div class="clearfix"> </div>
									</div>
									</a>
							</div>
						</div>	
						
						<div class="col-md-6 col-lg-3">
							<div class="panel panel-warning">
								<div class="panel-heading">
									<div class="row">
										<div class="col-xs-3">
											<i class="fa fa-users fa-5x"> </i>
										</div>
										
										<div class="col-xs-9">
											<div class="text-right huge"> 25 </div>
											<div class="text-right font-s"> All Users </div>
										</div>
									
									</div>
									</div>	
									<a href="#">
									<div class="panel-footer">
										<span class="pull-left"> View All Comments </span>
										<span class="pull-right"> <i class="fa fa-arrow-circle-right"> </i> </span>
										<div class="clearfix"> </div>
									</div>
									</a>
							</div>
						</div>	
						
						<div class="col-md-6 col-lg-3">
							<div class="panel panel-success">
								<div class="panel-heading">
									<div class="row">
										<div class="col-xs-3">
											<i class="fa fa-folder-open fa-5x"> </i>
										</div>
										
										<div class="col-xs-9">
											<div class="text-right huge"> 9 </div>
											<div class="text-right font-s"> All Categories </div>
										</div>
									
									</div>
									</div>	
									<a href="#">
									<div class="panel-footer">
										<span class="pull-left"> View All Categories </span>
										<span class="pull-right"> <i class="fa fa-arrow-circle-right"> </i> </span>
										<div class="clearfix"> </div>
									</div>
									</a>
							</div>
						</div>	
						
						
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<!-- <footer>
		<div class="container">
			 Copyright &copy; 2017 All Right Reserved 
		</div>
	</footer> -->
		

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>