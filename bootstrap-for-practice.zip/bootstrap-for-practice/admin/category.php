<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Practice</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link rel="icon" type="image/png" href="favicon-16x16.png">
  </head>
  <body>
  
  <nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="index.php"><img src="images/logo.png" width="90px" class="img-responsive" alt="" /></a>
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
     
     <!--  <form class="navbar-form navbar-left">
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Search">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
      </form> -->
	  
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"> <i class="fa fa-plus-square"></i> Add Post </a></li>
		<li><a href="#"> <i class="fa fa-user-plus"></i> Add User </a></li>
		<li><a href="#"> <i class="fa fa-user"></i> Profile </a></li>
		<li><a href="#"> <i class="fa fa-power-off"> </i> Logout </a></li>
      </ul>
		</div><!-- /.navbar-collapse -->
	  </div><!-- /.container-fluid -->
	</nav>

	<p> <br> </p>
	<section> 
		<div class="container">
			<div class="row">
				<div class="col-md-3"> 
					<div class="list-group">
					  <a href="#" class="list-group-item active"> <i class="fa fa-tachometer"> </i> Dasboard </a>
					  <a href="index.php" class="list-group-item"><span class="badge">14</span> <i class="fa fa-file-text"> </i> All Post</a>
					  <a href="#" class="list-group-item"><span class="badge">20</span> <i class="fa fa-comment"> </i> Comments</a>
					  <a href="category.php" class="list-group-item"><span class="badge">14</span> <i class="fa fa-folder-open"> </i> Category</a>
					  <a href="#" class="list-group-item"><span class="badge">5</span> <i class="fa fa-user"> </i> User</a>
					</div>
				</div>	
				<div class="col-md-9 dash"> 
					<h1> <i class="fa fa-tachometer"> </i> Categories <small> Different Categories </small> </h1> 
					<ol class="breadcrumb">
						<li class="active">  <i class="fa fa-tachometer"> </i> Dasboard  </li>
						<li >  <i class="fa fa-folder-open"> </i> Categories  </li>
					</ol>
					
					<div class="row">
						<div class="col-md-6">
							<form action="">
								<div class="form-group">
									<label for="category"> Category Name : </label>	
									<input type="text" placeholder="Category Name" class="form-control" />
								</div>
								<input type="submit" name="submit" id="submit" Value="Add Category" class="btn btn-info" />
							</form>
						</div>
						
						<div class="col-md-6">
							<table class="table table-responsive">
								<thead>
									<tr>
										<th> Sr. No </th>
										<th> Category Name </th>
										<th> Posts </th>
										<th> Edit </th>
										<th> Delete </th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td> 1 </td>
										<td> Video Tutorials </td>
										<td> 12 </td>
										<td> <a href=""> <i class="fa fa-pencil"> </i> </a> </td>
										<td> <a href=""> <i class="fa fa-times"> </i> </a> </td>
									</tr>
									
									<tr>
										<td> 2 </td>
										<td> Video Tutorials </td>
										<td> 12 </td>
										<td> <a href=""> <i class="fa fa-pencil"> </i> </a> </td>
										<td> <a href=""> <i class="fa fa-times"> </i> </a> </td>
									</tr>
									
									<tr>
										<td> 3 </td>
										<td> Video Tutorials </td>
										<td> 12 </td>
										<td> <a href=""> <i class="fa fa-pencil"> </i> </a> </td>
										<td> <a href=""> <i class="fa fa-times"> </i> </a> </td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<!-- <footer>
		<div class="container">
			 Copyright &copy; 2017 All Right Reserved 
		</div>
	</footer> -->
		

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>