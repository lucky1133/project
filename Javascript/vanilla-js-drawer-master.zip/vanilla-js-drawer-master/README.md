# 🚀 A dependency-free Vanilla JS drawer
No dependencies, no automation build tools. Copy/paste and ready to use.

CSS and JS are inlined inside the HTML file. Autoprefixer settings (online): last 1 version

### Requirements
A browser. No Node.js, Yarn, NPM, Webpack, Gulp, etc...

### Quick start: Installation
Copy/paste and use.

## Copyright and license

Copyright 2020 Tomasz Bujnowicz under the [MIT license](http://opensource.org/licenses/MIT).
