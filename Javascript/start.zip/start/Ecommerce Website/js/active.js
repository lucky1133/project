 $('#counter-block').ready(function () {
     $('.client').owlCarousel({
         loop: true,
         margin: 10,
         nav: true,
         items: 8,
         autoplayTimeout: 6000,
         autoplay: true,
         navText: [
        "<i class=\"fa fa-angle-left\" aria-hidden=\"true\"></i>",
        "<i class=\"fa fa-angle-right\" aria-hidden=\"true\"></i>"],
		 responsive: {
             1400: {
                 items: 8,
                 nav: true,
                 loop: true
             },
             991: {
                 items: 8,
                 nav: true,
                 loop: true
             },
             768: {
                 items: 6,
                 nav: true,
                 loop: true
             },
             500: {
                 items: 5,
                 nav: true,
                 loop: true
             },
             0: {
                 items: 3,
                 nav: true,
                 loop: true
             }
         },
     });
    $('.hero_slider').owlCarousel({
         loop: true,
         margin: 10,
         nav: false,
         items: 1,
         autoplayTimeout: 6000,
         autoplay: true,
         navText: [
        "<i class=\"fa fa-angle-left\" aria-hidden=\"true\"></i>",
        "<i class=\"fa fa-angle-right\" aria-hidden=\"true\"></i>"],
     });
	 $('.product_list').owlCarousel({
         loop: false,
         margin: 10,
         nav: false,
         items: 5,
         autoplayTimeout: 6000,
         autoplay: false,
         navText: [
        "<i class=\"fa fa-angle-left\" aria-hidden=\"true\"></i>",
        "<i class=\"fa fa-angle-right\" aria-hidden=\"true\"></i>"],
		  responsive: {
             1400: {
                 items: 5,
                 nav: true,
                 loop: true
             },
             991: {
                 items: 5,
                 nav: true,
                 loop: true
             },
             768: {
                 items: 3,
                 nav: true,
                 loop: true
             },
             500: {
                 items: 2,
                 nav: true,
                 loop: true
             },
             0: {
                 items: 2,
                 nav: true,
                 loop: true
             }
         },
     });
 });
