import React from "react";
import DropDownHeader from "./DropDownHeader";
import "./Header.css";

const Header = () => {
  const [navbarOpen] = React.useState(false);

  const toogleSidebar = () => {
    var ele = document.body;
    ele.classList.toggle("sideMenu");
    ele.classList.toggle("change");
  };

  return (
    <>
      <nav className="relative flex flex-wrap items-center justify-between px-3 navbar-expand-lg bgColor">
        <div className="px-0 md:px-4 flex w-full items-center justify-between">
          <div className="w-full relative flex justify-between lg:w-auto lg:static lg:block lg:justify-start">
            <div className="text-sm flex items-center  mr-4 py-2 whitespace-no-wrap uppercase text-white">
              <button
                id="minimizeSidebar"
                onClick={() => toogleSidebar()}
                className="bg-gray-100 py-3 px-3 rounded-full flex focus:outline-none"
              >
                <i
                  className="material-icons more_vert text-gray-600"
                  style={{ fontSize: "18px" }}
                >
                  more_vert
                </i>
                <i
                  className="material-icons view_list text-gray-600"
                  style={{ fontSize: "18px", display: "none" }}
                >
                  view_list
                </i>
                <span className="hidden">
                  <i className="material-icons visible-on-sidebar-mini">
                    view_list
                  </i>
                </span>
              </button>
              <span className="ml-4 font-medium text-lg">Wall</span>
            </div>
            <button
              className="text-white cursor-pointer text-xl leading-none px-3 py-1 border border-solid border-transparent rounded bg-transparent block lg:hidden outline-none focus:outline-none"
              type="button"
              onClick={() => toogleSidebar()}
            >
              <div className="bar1"></div>
              <div className="bar2"></div>
              <div className="bar3"></div>
            </button>
          </div>
          <div
            className={
              "lg:flex flex-grow items-center" +
              (navbarOpen ? " flex" : " hidden")
            }
            id="example-navbar-danger"
          >
            <DropDownHeader />
          </div>
        </div>
      </nav>
    </>
  );
};

export default Header;
