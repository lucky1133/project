import React from "react";
import "./Feedback.css";
import CommonHeader from "../commonheader/CommonHeader";
import Swal from "sweetalert2";

class Feedback extends React.Component {
  componentDidMount() {
    document.title = "Feedback";
  }

  onSubmit() {
    Swal.fire({
      text: "Feedback Submitted successfully!",
      confirmButtonText: "Ok",
    });
  }
  render() {
    return (
      <div className="rounded shadow-lg border mt-8">
        <div className="xl:px-6 lg:px-6 md:px-3 px-1 py-2 pb-5">
          <div className="flex justify-between items-center mb-5 relative">
            <CommonHeader icon="people" name="Feedback" />
          </div>

          <section className="text-gray-700">
            <div className="container mx-auto labelmin">
              <div className="flex flex-wrap -m-4">
                <div className="p-4 md:w-1/2 xl:w-1/2 lg:w-1/2 w-full mx-2 md:mx-0">
                  <div className="flex items-start mb-5">
                    <label
                      htmlFor="name"
                      className="font-medium text-sm
                    "
                    >
                      Name
                    </label>

                    <div className="flex-grow w-full">
                      <input
                        className="bg-gray-100 w-full rounded border border-gray-300 focus:outline-none text-sm px-4 py-2 mb-4 sm:mb-0"
                        placeholder="Miguel Cantu"
                        type="text"
                      />
                      <small className="text-red-500 text-sm">
                        Name is Required
                      </small>
                    </div>
                  </div>
                </div>

                <div className="p-4 md:w-1/2 xl:w-1/2 lg:w-1/2 w-full mx-2 md:mx-0">
                  <div className="flex items-start mb-5">
                    <label
                      htmlFor="name"
                      className="font-medium text-sm
                    "
                    >
                      Email
                    </label>

                    <div className="flex-grow w-full">
                      <input
                        className="flex-grow w-full bg-gray-100 rounded border border-gray-300 focus:outline-none text-sm px-4 py-2 mb-4 sm:mb-0"
                        placeholder="student@selready.com"
                        type="text"
                      />
                      <small className="text-red-500 text-sm">
                        Email is Required
                      </small>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex flex-wrap -m-4">
                <div className="p-4 md:w-1/2 xl:w-1/2 lg:w-1/2 w-full mx-2 md:mx-0">
                  <div className="flex items-start">
                    <label
                      htmlFor="name"
                      className="font-medium text-sm
                    "
                    >
                      Feedback
                    </label>

                    <div className="flex-grow w-full">
                      <textarea
                        placeholder=""
                        className="resize h-40 placeholder-opacity-100 rounded border border-gray-300 p-2 px-3 text-sm w-full focus:outline-none"
                      ></textarea>
                      <small className="text-red-500 text-sm">
                        Feedback is Required
                      </small>
                    </div>
                  </div>
                </div>
                <div className="p-4 md:w-1/2 xl:w-1/2 lg:w-1/2 w-full mx-2 md:mx-0">
                  <div className="flex items-start">
                    <label
                      htmlFor="name"
                      className="font-medium text-sm
                    "
                    >
                      Upload Image
                    </label>
                    <div className="w-full">
                      {/* After Upload Images */}
                      <div className="flex items-center w-full mb-3">
                        <input
                          className="form-input block w-full focus:shadow-none"
                          placeholder="download.jpg"
                        ></input>
                        <div className="text-white w-40">
                          <button className="bgRed hover:opacity-75 text-xs p-1 rounded-sm mx-2 leading-none">
                            <i
                              className="material-icons remove_custom"
                              style={{ fontSize: "16px" }}
                            >
                              close
                            </i>
                          </button>
                          <button className="bgRed  hover:opacity-75 text-xs p-1 rounded-sm leading-none">
                            <i
                              className="material-icons remove_custom"
                              style={{ fontSize: "16px" }}
                            >
                              add
                            </i>
                          </button>
                        </div>
                      </div>
                      {/* End */}
                      <div className="upload-btn-wrapper">
                        <button className="transition cursor-pointer duration-300 ease-in-out bgRed hover:opacity-50 text-white font-normal py-2 px-4 rounded">
                          Add File
                        </button>
                        <input
                          type="file"
                          name="myfile"
                          className="cursor-pointer"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <button
                  className="transition duration-300 ease-in-out bgRed  mt-10 hover:opacity-75 text-white font-normal py-2 px-4 mr-2 rounded"
                  onClick={() => this.onSubmit()}
                >
                  Submit
                </button>
              </div>
            </div>
          </section>
        </div>
      </div>
    );
  }
}

export default Feedback;
