import React from "react";
import "./AddCheckitOut.css";
import $ from "jquery";
import CommonHeader from "../../commonheader/CommonHeader";

class AddCheckitOut extends React.Component {
  componentDidMount() {
    document.title = "Add Checkitout";
  }

  render() {
    $(document).ready(function () {
      $('.radioBox input[type="radio"]').click(function () {
        var inputValue = $(this).attr("value");
        var targetBox = $("." + inputValue);
        $(".radioBox .box").not(targetBox).hide();
        $(targetBox).show();
      });
    });
    return (
      <div className="rounded shadow-lg border mt-8">
        <div className="px-6 py-2 pb-5">
          <div className="flex justify-between items-center mb-5 relative">
            <CommonHeader icon="school" name="Check It Out" />
          </div>
          {/* Form */}
          <div className="w-full xl:w-3/6">
            <label
              className="block text-gray-700 text-md font-medium mb-2"
              htmlFor="username"
            >
              Title [English]
            </label>
            <input
              className="appearance-none text-sm border rounded border-gray-400 w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none"
              type="text"
              placeholder="Enter title in English"
            ></input>
            <small className="text-red-500 text-sm">
              The title field in english is required
            </small>
          </div>
          {/* End Form */}

          {/* Form */}
          <div className="w-full xl:w-3/6 mt-4">
            <label
              className="block text-gray-700 text-md font-medium mb-2"
              htmlFor="username"
            >
              Description [English]
            </label>
            <textarea
              placeholder="Enter description in English"
              className="resize h-16 placeholder-opacity-100 border rounded border-gray-400 p-2 px-3 text-sm w-full focus:outline-none"
            ></textarea>
            <small className="text-red-500 text-sm">
              The description field in english is required
            </small>
          </div>
          {/* End Form */}

          {/* Form */}
          <div className="w-full xl:w-3/6 mt-4">
            <label
              className="block text-gray-700 text-md font-medium mb-2"
              htmlFor="username"
            >
              Author
            </label>
            <select className="block appearance-none w-full bg-gray-400 border border-gray-400 hover:border-gray-500 px-4 py-3 pr-8 rounded-0 text-sm leading-tight focus:outline-none">
              <option>Miguel Cantu</option>
              <option>Option 2</option>
              <option>Option 3</option>
            </select>
          </div>
          {/* End Form */}

          {/* Form */}
          <div className="w-full xl:w-4/6 mt-4">
            <label
              className="block text-gray-700 text-md font-medium mb-2"
              htmlFor="username"
            >
              Upload Image or Video
            </label>
            <div className="radioBox mt-5">
              <div className="flex justify-between text-sm font-medium text-gray-700">
                <label className="inline-flex items-center">
                  <input
                    type="radio"
                    className="form-radio border border-gray-500 focus:shadow-none focus:border-red-600 text-red-600"
                    name="colorRadio"
                    value="red"
                  />
                  <span className="ml-2">Upload Image</span>
                </label>

                <label className="inline-flex items-center">
                  <input
                    type="radio"
                    className="form-radio border border-gray-500 focus:shadow-none focus:border-red-600 text-red-600"
                    name="colorRadio"
                    value="green"
                  />
                  <span className="ml-2">Upload Video</span>
                </label>

                <label className="inline-flex items-center">
                  <input
                    type="radio"
                    className="form-radio border border-gray-500 focus:shadow-none focus:border-red-600 text-red-600"
                    name="colorRadio"
                    value="blue"
                  />
                  <span className="ml-2">URL</span>
                </label>
              </div>
              <div className="box red">
                <div className="overflow-hidden relative w-40 mt-4 ">
                  <div className="upload-btn-wrapper">
                    <button className="transition cursor-pointer duration-300 ease-in-out bgRed mt-4 hover:opacity-50 text-white font-normal py-2 px-4 rounded">
                      SELECT IMAGE
                    </button>
                    <input
                      type="file"
                      name="myfile"
                      className="cursor-pointer"
                    />
                  </div>
                </div>
              </div>
              <div className="box green">
                <div className="mt-6 bg-grey-lighter">
                  <label className="w-9/12 flex flex-col items-center px-4 py-12 bg-white text-blue rounded-lg shadow-lg tracking-wide uppercase border border-blue cursor-pointer hover:bg-blue hover:text-black">
                    <svg
                      width="50px"
                      fill="#ccc"
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 20 20"
                    >
                      <path d="M16.88 9.1A4 4 0 0 1 16 17H5a5 5 0 0 1-1-9.9V7a3 3 0 0 1 4.52-2.59A4.98 4.98 0 0 1 17 8c0 .38-.04.74-.12 1.1zM11 11h3l-4-4-4 4h3v3h2v-3z" />
                    </svg>
                    <span className="mt-2 text-xs leading-normal">
                      Drag and drop a file here or click
                    </span>
                    <input type="file" className="hidden" />
                  </label>
                </div>
              </div>
              <div className="box blue">
                {/* Form */}
                <div className="w-full xl:w-4/6 mt-4">
                  <input
                    className="appearance-none text-sm border rounded border-gray-400 w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none"
                    type="text"
                    placeholder="Enter your Link"
                  ></input>
                </div>
                {/* End Form */}
              </div>
            </div>
          </div>
          {/* End Form */}
          <div className="text-right">
            <button className="transition duration-300 ease-in-out bgRed  mt-2 hover:opacity-75 text-white font-normal py-2 px-4 mr-2 rounded">
              Add
            </button>
          </div>
        </div>
      </div>
    );
  }
}

export default AddCheckitOut;
