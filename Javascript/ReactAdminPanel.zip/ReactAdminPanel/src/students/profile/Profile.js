import React from "react";
import "./Profile.css";
import { Tab, Tabs, TabList, TabPanel } from "react-tabs";
import "react-tabs/style/react-tabs.css";
import MyInfo from "./myinfo/MyInfo";
import About from "./aboutme/About";
import MyVault from "./myvault/MyVault";

class Profile extends React.Component {
  constructor() {
    super();
    this.state = {
      show: false,
      title: true,
    };
  }
  profileInfo() {
    this.setState({
      show: !this.state.show,
      title: !this.state.title,
    });
  }

  componentDidMount() {
    document.title = "Profile";
  }
  render() {
    return (
      <div className="rounded shadow-lg border mt-8">
        <div className="xl:px-6 lg:px-6 md:px-3 px-1 py-2 pb-5">
          <section className="text-gray-700">
            <div className="container mx-auto profilCard">
              <div className="flex flex-wrap -m-4">
                <div className="p-4 md:w-full xl:w-1/4 lg:w-full lg:mb-3 w-full">
                  <div className="flex justify-between items-center mb-5 relative">
                    <div className="absolute px-2 py-2 shadow-lg card-icon text-white rounded bgColor text-center">
                      <span className="font-medium text-sm xl:text-lg">
                        My Profile
                      </span>
                    </div>
                  </div>
                  <div className="mt-24 text-center">
                    <div className="rounded shadow-lg border mt-8 relative profilepos">
                      <div className="upload-btn-wrapper uploadWra shadow-md border border-gray-300 ">
                        <div className="cursor-pointer editicon hidden duration-300 ease-in-out hover:opacity-50 text-white font-normal rounded-full">
                          <i className="fa fa-pencil fa-lg"></i>
                        </div>
                        <input
                          type="file"
                          name="myfile"
                          className="cursor-pointer"
                        />
                        <img
                          src="https://3.bp.blogspot.com/-Chu20FDi9Ek/WoOD-ehQ29I/AAAAAAAAK7U/mc4CAiTYOY8VzOFzBKdR52aLRiyjqu0MwCLcBGAs/s1600/DSC04596%2B%25282%2529.JPG"
                          alt=""
                          className="h-full w-full object-cover"
                        />
                      </div>
                      <div className="mt-6 mb-8 px-5">
                        <h2 className="text-xl text-black font-medium mb-3">
                          Miguel Cantu
                        </h2>
                        <p
                          className="text-sm font-medium"
                          onClick={() => this.profileInfo()}
                        >
                          {this.state.title
                            ? "Click for More Info"
                            : "Click for less info"}
                        </p>
                        {this.state.show ? (
                          <>
                            <div className="flex items-start border-b pb-1 mt-3">
                              <i className="material-icons mail mr-3">
                                contact_mail
                              </i>
                              <p className="card-description text-sm text-gray-500">
                                student@selready.com
                              </p>
                            </div>
                            <div className="flex items-start border-b pb-1 mt-3">
                              <i className="material-icons mail mr-3">
                                comment
                              </i>
                              <p className="card-description text-sm text-gray-500">
                                Test 1234
                              </p>
                            </div>
                          </>
                        ) : null}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="p-4 md:w-full xl:w-3/4 lg:w-full w-full">
                  <div className="flex justify-between items-center mb-5 relative">
                    <div className="absolute px-3 w-full py-2 shadow-lg card-icon text-white rounded bgColor text-center">
                      <span className="font-medium text-sm xl:text-lg">
                        Manage Profile
                      </span>
                    </div>
                  </div>
                  <div className="mt-24">
                    <div className="rounded shadow-lg border mt-8 relative p-2 md:p-4 profiletab">
                      <Tabs>
                        <TabList>
                          <Tab>My Info</Tab>
                          <Tab>About Me</Tab>
                          <Tab>My Vault</Tab>
                        </TabList>

                        <TabPanel>
                          <MyInfo />
                        </TabPanel>
                        <TabPanel>
                          <About />
                        </TabPanel>
                        <TabPanel>
                          <MyVault />
                        </TabPanel>
                      </Tabs>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    );
  }
}

export default Profile;
