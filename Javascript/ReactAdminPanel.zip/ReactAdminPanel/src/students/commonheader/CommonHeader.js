import React from "react";

class CommonHeader extends React.Component {
  render() {
    return (
      <>
        <div className="absolute p-4 card-icon text-white flex items-center justify-center rounded-md shadow-lg bgRed text-center">
          <i className="material-icons text-xl">{this.props.icon}</i>
        </div>
        <span className="font-normal text-xl pl-16">{this.props.name}</span>
      </>
    );
  }
}

export default CommonHeader;
