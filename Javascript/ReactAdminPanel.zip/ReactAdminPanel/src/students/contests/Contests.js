import React, { Component, Fragment } from "react";
import ReactDatatable from "@ashvin27/react-datatable";
import records from "../../db/studentdata.json";
import { withSwalInstance } from "sweetalert2-react";
import swal from "sweetalert2";
import { orderBy } from "lodash";
import "./Contests.css";
import CommonHeader from "../commonheader/CommonHeader";

class Contests extends Component {
  constructor(props) {
    super(props);
    this.columns = [
      {
        key: "name",
        text: "Name",
        sortable: true,
      },
      {
        key: "sdate",
        text: "Start Date",
        sortable: true,
      },
      {
        key: "edate",
        text: "End Date",
        sortable: true,
      },
      {
        key: "status",
        text: "Status",
        sortable: true,
      },
      {
        text: "Actions",
        cell: () => {
          return (
            <Fragment>
              <button
                className="matIcon"
                onClick={() => this.setState({ showModal: true })}
                style={{ marginRight: "5px" }}
              >
                <i className="material-icons btnIinfo text-white rounded-md p-1">
                  edit
                </i>
              </button>
              <button
                className="matIcon"
                style={{ marginRight: "5px" }}
                onClick={() => this.setState({ show1: true })}
              >
                <i className="material-icons bgRed text-white rounded-md p-1">
                  close
                </i>
              </button>
            </Fragment>
          );
        },
      },
    ];

    this.config = {
      page_size: 10,
      length_menu: [10, 20, 50],
      show_filter: true,
      show_pagination: true,
      pagination: "advance",
      button: {
        excel: false,
        print: false,
      },
    };

    this.state = {
      records: records.contests,
      showModal: false,
    };
  }
  onSort = (column, records, sortOrder) => {
    return orderBy(records, [column], [sortOrder]);
  };

  componentDidMount() {
    document.title = "Contest";
  }

  render() {
    const SweetAlert = withSwalInstance(swal);
    return (
      <div className="rounded shadow-lg border mt-8">
        <div className="xl:px-6 lg:px-6 md:px-3 px-1 py-2 pb-5">
          <div className="flex justify-between items-center mb-5 relative">
            <CommonHeader icon="emoji_events" name="Contests" />
          </div>
          <ReactDatatable
            config={this.config}
            records={this.state.records}
            columns={this.columns}
            onSort={this.onSort}
          />
          <SweetAlert
            show={this.state.show}
            text="You are not authorized to change the status of post"
            onConfirm={() => this.setState({ show: false })}
          />

          <SweetAlert
            show={this.state.show1}
            showCancel
            type="warning"
            confirmBtnText="Yes, delete it!"
            confirmBtnBsStyle="danger"
            title="Are you sure?"
            showCancelButton="true"
            confirmButtonColor="#051429"
            cancelButtonText="Cancel"
            cancelButtonColor="#ca2222"
            onConfirm={() => this.setState({ show1: false })}
          />

          {this.state.showModal ? (
            <>
              <div className="justify-center modalNew items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none">
                <div className="relative lg:w-2/5 md:w-3/5 w-4/5 my-6 mx-auto max-w-1xl">
                  {/*content*/}
                  <div className="border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none">
                    {/*header*/}
                    <div className="flex items-center bgColor justify-between p-5 border-b border-solid border-gray-300 rounded-t">
                      <h3 className="md:text-2xl text-1xl uppercase text-white font-semibold">
                        Edit contest
                      </h3>
                      <button
                        className="p-1 ml-auto bg-transparent border-0 text-black opacity-5 float-right text-3xl leading-none font-semibold outline-none focus:outline-none"
                        onClick={() => this.setState({ showModal: false })}
                      >
                        <span className="bg-transparent text-white opacity-5 h-6 w-6 text-2xl block outline-none focus:outline-none">
                          ×
                        </span>
                      </button>
                    </div>
                    {/*body*/}
                    <div className="relative p-6 flex-auto">
                      <label className="block mb-3">
                        <span className="text-gray-700 font-medium">Name</span>
                        <input
                          className="form-input mt-1 block w-full"
                          placeholder="Xyz"
                        />
                      </label>
                      <label className="block mb-3">
                        <span className="text-gray-700 font-medium">
                          Start Date
                        </span>
                        <input
                          className="form-input mt-1 block w-full"
                          placeholder="19-8-2020"
                        />
                      </label>
                      <label className="block mb-3">
                        <span className="text-gray-700 font-medium">
                          End Date
                        </span>
                        <input
                          className="form-input mt-1 block w-full"
                          placeholder="19-8-2020"
                        />
                      </label>
                      <label className="block">
                        <span className="text-gray-700 font-medium">
                          Status
                        </span>
                        <input
                          className="form-input mt-1 block w-full"
                          placeholder="Online"
                        />
                      </label>
                    </div>
                    {/*footer*/}
                    <div className="flex items-center justify-end p-3 border-t border-solid border-gray-300 rounded-b">
                      <button
                        className="bg-green-500 text-white active:bg-green-600 font-bold uppercase text-sm px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1"
                        type="button"
                        style={{ transition: "all .15s ease" }}
                        onClick={() => this.setState({ showModal: false })}
                      >
                        Save
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div className="opacity-25 fixed inset-0 z-40 bg-black"></div>
            </>
          ) : null}
        </div>
      </div>
    );
  }
}

export default Contests;
