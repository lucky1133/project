import React, { Component } from "react";
import "./Courses.css";

class Courses extends Component {
  render() {
    return (
      <div>
        <main className="content">
          <div className="container-fluid">
            <div className="w-full w-1/1">
              <div className="card ">
                <div className="card-header card-header-icon card-header-primary">
                  <div className="card-icon">
                    <i className="material-icons">import_contacts</i>
                  </div>
                  <h4 className="card-title mt-12 md:mt-3 mb-4 md:mb-0">
                    Lessons
                  </h4>
                </div>
                <div className="card-body">
                  <div
                    id="user-datatables_wrapper"
                    className="dataTables_wrapper"
                  ></div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }
}

export default Courses;
