import React from "react";
import "./Profile.css";
import { Tab, Tabs, TabList, TabPanel } from "react-tabs";
import "react-tabs/style/react-tabs.css";
import MyInfo from "./myinfo/MyInfo";
import MyVault from "./myvault/MyVault";

class Profile extends React.Component {
  constructor() {
    super();
    this.state = {
      show: false,
      title: true,
    };
  }
  profileInfo() {
    this.setState({
      show: !this.state.show,
      title: !this.state.title,
    });
  }
  render() {
    return (
      <div>
        <main className="content">
          <div className="container-fluid">
            <div className="w-full w-1/1">
              <div className="rounded shadow-lg border mt-8">
                <div className="xl:px-6 lg:px-6 md:px-3 px-1 py-2 pb-5">
                  <section className="text-gray-700">
                    <div className="profilCard">
                      <div className="flex flex-wrap -m-4">
                        <div className="p-4 xl:w-1/4 w-full">
                          <div className="flex justify-center items-center mb-5 relative">
                            <div className="w-10/12 absolute py-2 shadow-lg card-icon text-white rounded bgColor text-center">
                              <span className="font-medium text-lg">
                                My Profile
                              </span>
                            </div>
                          </div>
                          <div className="mt-24 text-center">
                            <div className="rounded shadow-lg border mt-8 relative profilepos">
                              <div className="picture card-avatar teacher -m-16">
                                <div className="edit edit-event-img teacher-edit-img">
                                  <button id="wizardPicturePreview">
                                    <i className="fa fa-pencil fa-lg"></i>
                                  </button>
                                </div>
                                <input
                                  type="file"
                                  id="file"
                                  className="teacher-input-file"
                                />
                                <img
                                  src="https://3.bp.blogspot.com/-Chu20FDi9Ek/WoOD-ehQ29I/AAAAAAAAK7U/mc4CAiTYOY8VzOFzBKdR52aLRiyjqu0MwCLcBGAs/s1600/DSC04596%2B%25282%2529.JPG"
                                  alt="UserImage"
                                  className="picture-src teacher-img"
                                  id=""
                                />
                              </div>
                              <div className="mt-20 mb-8 px-5">
                                <h2 className="text-xl text-black font-medium mb-3">
                                  Teacher Teacher
                                </h2>
                                <p
                                  className="text-sm font-medium cursor-pointer inline-block"
                                  onClick={() => this.profileInfo()}
                                >
                                  {this.state.title
                                    ? "Click for More Info"
                                    : "Click for less info"}
                                </p>
                                {this.state.show ? (
                                  <>
                                    <div className="flex items-start border-b pb-1 mt-3">
                                      <i className="material-icons mail mr-3">
                                        contact_mail
                                      </i>
                                      <p className="card-description text-sm text-gray-500">
                                        student@selready.com
                                      </p>
                                    </div>
                                    <div className="flex items-start border-b pb-1 mt-3">
                                      <i className="material-icons mail mr-3">
                                        comment
                                      </i>
                                      <p className="card-description text-sm text-gray-500">
                                        Test 1234
                                      </p>
                                    </div>
                                  </>
                                ) : null}
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="p-4 xl:w-3/4 w-full">
                          <div className="flex justify-center items-center mb-5 xl:mt-0 mt-10 relative">
                            <div className="w-11/12  absolute px-3 py-2 shadow-lg card-icon text-white rounded bgColor text-center">
                              <span className="font-medium text-lg">
                                Manage Profile
                              </span>
                            </div>
                          </div>
                          <div className="mt-24">
                            <div className="rounded shadow-lg border mt-8 relative p-2 md:p-4 profiletab">
                              <Tabs>
                                <TabList>
                                  <Tab>About Me</Tab>
                                  <Tab>My Vault</Tab>
                                </TabList>

                                <TabPanel>
                                  <MyInfo />
                                </TabPanel>
                                <TabPanel>
                                  <MyVault />
                                </TabPanel>
                              </Tabs>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }
}

export default Profile;
