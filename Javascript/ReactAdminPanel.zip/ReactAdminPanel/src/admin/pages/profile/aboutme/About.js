import React from "react";
import {
  Accordion,
  AccordionItem,
  AccordionItemHeading,
  AccordionItemButton,
  AccordionItemPanel,
} from "react-accessible-accordion";
import "react-accessible-accordion/dist/fancy-example.css";
import "./About.css";

class About extends React.Component {
  render() {
    return (
      <section className="text-gray-700">
        <div className="container mx-auto">
          <div className="flex flex-wrap -m-4 mt-3">
            <div className="py-2 mb-5 mt-8 w-full mx-5 accordDian">
              <Accordion allowZeroExpanded>
                <AccordionItem>
                  <AccordionItemHeading>
                    <AccordionItemButton>My Dogs Name</AccordionItemButton>
                  </AccordionItemHeading>
                  <AccordionItemPanel>
                    <h3 className="font-medium pb-2 border-b border-gray-500 mb-3">
                      This Is Where You Choose What Your Dogs Names Are Called
                    </h3>
                    <div className="border-t border-gray-300 pt-3 pb-3">
                      <h3 className="font-bold text-sm">
                        Question : What is your dog(s) name(s)?
                      </h3>
                      <div className="p-2 mt-4">
                        <label className="inline-flex items-center">
                          <input
                            type="checkbox"
                            className="form-checkbox text-red-600 focus:shadow-none border border-black"
                          />
                          <span className="ml-2">Shadow</span>
                        </label>
                        <label className="inline-flex items-center mx-8">
                          <input
                            type="checkbox"
                            className="form-checkbox text-red-600 focus:shadow-none border border-black"
                          />
                          <span className="ml-2">Panda</span>
                        </label>
                        <label className="inline-flex items-center">
                          <input
                            type="checkbox"
                            className="form-checkbox text-red-600 focus:shadow-none border border-black"
                          />
                          <span className="ml-2">Panther</span>
                        </label>
                      </div>
                    </div>
                  </AccordionItemPanel>
                </AccordionItem>
                <AccordionItem>
                  <AccordionItemHeading>
                    <AccordionItemButton>Test</AccordionItemButton>
                  </AccordionItemHeading>
                  <AccordionItemPanel>
                    <h3 className="font-medium pb-2 border-b border-gray-500 mb-3">
                      Abc
                    </h3>
                    <div className="border-t border-gray-300 pt-3 pb-3">
                      <h3 className="font-bold text-sm">
                        Question : What is your dog(s) name(s)?
                      </h3>
                      <div className="p-2 mt-4">
                        <label className="inline-flex items-center">
                          <input
                            type="radio"
                            name="radio"
                            value="1"
                            className="form-radio text-red-600 focus:shadow-none border border-black"
                          />
                          <span className="ml-2">Abc</span>
                        </label>
                        <label className="inline-flex items-center mx-8">
                          <input
                            type="radio"
                            name="radio"
                            value="2"
                            className="form-radio text-red-600 focus:shadow-none border border-black"
                          />
                          <span className="ml-2">Bca</span>
                        </label>
                      </div>
                    </div>
                  </AccordionItemPanel>
                </AccordionItem>
              </Accordion>
            </div>
          </div>
        </div>
      </section>
    );
  }
}

export default About;
