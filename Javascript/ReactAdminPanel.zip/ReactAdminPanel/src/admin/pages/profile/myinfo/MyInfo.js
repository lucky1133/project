import React from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import ReactFlagsSelect from "react-flags-select";
import "react-flags-select/css/react-flags-select.css";
import "./MyInfo.css";

class MyInfo extends React.Component {
  state = {
    startDate: new Date(),
  };

  handleChange = (date) => {
    this.setState({
      startDate: date,
    });
  };

  render() {
    return (
      <section className="text-gray-700">
        <div className="container mx-auto">
          <h2 className="text-xl mb-5 mt-8 font-medium border-b pb-2">
            Personal Info
          </h2>
          <div className="flex flex-wrap -m-4 mt-3">
            <div className="px-4 xl:px-4 lg:px-4 md:px-4 md:w-full xl:w-1/2 lg:w-1/2 w-full mx-2 md:mx-0">
              <div className="flex flex-wrap md:flex-no-wrap items-start mb-0 md:mb-5">
                <label
                  htmlFor="name"
                  className="w-48 font-medium text-sm bmd-label
 "
                >
                  Prefered Title
                </label>
                <select
                  className="title-select flex-grow w-full mt-2 xl:mt-0 md:mt-0 lg:mt-0 bg-gray-100 rounded border border-gray-300 focus:outline-none text-sm px-4 py-2 mb-4 sm:mb-0"
                  name="title"
                >
                  <option>Choose a prefered title</option>
                  <option value="dr.">Dr.</option>
                  <option value="mr.">Mr.</option>
                  <option value="mrs.">Mrs.</option>
                  <option value="ms.">Ms</option>
                  <option value="coach">Coach</option>
                  <option value="rev.">Rev.</option>
                  <option value="pastor">Pastor</option>
                </select>
              </div>
            </div>
            <div className="px-4 xl:px-4 lg:px-4 md:px-4 md:w-full xl:w-1/2 lg:w-1/2 w-full mx-2 md:mx-0">
              <div className="flex flex-wrap md:flex-no-wrap items-start mb-5 md:mb-5">
                <label
                  htmlFor="name"
                  className="w-full md:w-20 mr-10 font-medium text-sm bmd-label
 "
                >
                  Language Preference
                </label>
                <label className="switch_display_contact">
                  <input className="switch-input" type="checkbox" />
                  <span
                    className="switch-label postStatus updateClass1"
                    data-on="EN"
                    data-off="US"
                    data-id="1"
                    data-act-status="1"
                  ></span>
                  <input type="hidden" id="switchinput1" />
                  <span className="switch-handle"></span>
                </label>
              </div>
            </div>

            <div className="px-4 xl:px-4 lg:px-4 md:px-4 md:w-full xl:w-1/2 lg:w-1/2 w-full mx-2 md:mx-0">
              <div className="flex flex-wrap md:flex-no-wrap items-start mb-0 md:mb-5">
                <label
                  htmlFor="name"
                  className="w-48 font-medium text-sm bmd-label"
                >
                  First Name
                </label>
                <input
                  className="flex-grow w-full mt-2 xl:mt-0 md:mt-0 lg:mt-0 bg-gray-100 rounded border border-gray-300 focus:outline-none text-sm px-4 py-2 mb-4 sm:mb-0"
                  placeholder="Miguel"
                  type="text"
                />
              </div>
            </div>
            <div className="px-4 xl:px-4 lg:px-4 md:px-4 md:w-full xl:w-1/2 lg:w-1/2 w-full mx-2 md:mx-0">
              <div className="flex flex-wrap md:flex-no-wrap items-start mb-0 md:mb-5">
                <label
                  htmlFor="name"
                  className="w-48 font-medium text-sm bmd-label
 "
                >
                  Last Name
                </label>
                <input
                  className="flex-grow w-full mt-2 xl:mt-0 md:mt-0 lg:mt-0 bg-gray-100 rounded border border-gray-300 focus:outline-none text-sm px-4 py-2 mb-4 sm:mb-0"
                  placeholder="Cantu"
                  type="text"
                />
              </div>
            </div>
            <div className="px-4 md:mt-0 mt-3 xl:px-4 lg:px-4 md:px-4 md:w-full xl:w-1/2 lg:w-1/2 w-full mx-2 md:mx-0">
              <div className="flex flex-wrap md:flex-no-wrap items-start mb-0 md:mb-5">
                <label
                  htmlFor="name"
                  className="w-40 mr-4 font-medium text-sm bmd-label
 "
                >
                  Date of Birth
                </label>
                <DatePicker
                  selected={this.state.startDate}
                  onChange={this.handleChange}
                  className="flex-grow w-full bg-gray-100 rounded border border-gray-300 focus:outline-none text-sm px-4 py-2 mb-4 sm:mb-0 mt-2 xl:mt-0 md:mt-0 lg:mt-0"
                />
              </div>
            </div>
            <div className="px-4 pt-1 md:w-1/2 xl:w-1/6 lg:w-1/2 w-full mx-2 md:mx-0">
              <div className="flex items-start">
                <label className="switch_display_contact mb-4">
                  <input className="switch-input" type="checkbox" />
                  <span
                    className="switch-label postStatus updateClass1"
                    data-on="Show"
                    data-off="Hide"
                    data-id="2"
                    data-act-status="2"
                  ></span>
                  <input type="hidden" id="switchinput1" />
                  <span className="switch-handle"></span>
                </label>
              </div>
            </div>
            <div className="px-4 md:mt-0 mt-3 xl:px-4 lg:px-4 md:px-4 md:w-full xl:w-1/2 lg:w-1/2 w-full mx-2 md:mx-0">
              <div className="flex flex-wrap md:flex-no-wrap items-start mb-0 md:mb-5">
                <label
                  htmlFor="name"
                  className="w-40 mr-4 font-medium text-sm bmd-label
 "
                >
                  About me
                </label>
                <textarea
                  placeholder="Test1234"
                  className="resize h-32 placeholder-opacity-100 border rounded border-gray-300 p-2 px-3 text-sm w-full focus:outline-none"
                ></textarea>
              </div>
            </div>
          </div>

          <h2 className="text-xl mb-5 mt-8 font-medium border-b pb-2">
            School Info
          </h2>
          <div className="text-gray-700 body-font">
            <div className="container">
              <div className="flex flex-wrap -m-4">
                <div className="py-0 px-4 xl:p-4 mt-3 md:mt-0 md:p-4 md:w-full xl:w-1/2 lg:w-1/2 w-full md:mx-0">
                  <div className="flex flex-wrap md:flex-no-wrap items-start mb-0 md:mb-5">
                    <label
                      htmlFor="name"
                      className="w-48 font-medium text-sm bmd-label
"
                    >
                      School
                    </label>

                    <div className="relative flex-grow w-full">
                      <input
                        className="  mt-2 xl:mt-0 w-full md:mt-0 lg:mt-0 bg-gray-100 rounded border border-gray-300 focus:outline-none text-sm px-4 py-2 mb-4 sm:mb-0 cursor-not-allowed
                                          "
                        placeholder="School Name"
                        type="text"
                        disabled
                      />
                      <span className="absolute right-0 pt-4 mr-3 md:pt-2 md:mr-2 text-xs">
                        <i className="material-icons mtfont text-gray-500">
                          lock
                        </i>
                      </span>
                    </div>
                  </div>
                </div>
                <div className="py-0 px-4 xl:p-4 md:p-4 md:w-full xl:w-1/2 lg:w-1/2 w-full md:mx-0">
                  <div className="flex flex-wrap md:flex-no-wrap items-start mb-0 md:mb-5 relative">
                    <label
                      htmlFor="name"
                      className="w-48 font-medium text-sm bmd-label
"
                    >
                      Grade
                    </label>

                    <div className="relative flex-grow w-full">
                      <input
                        className="flex-grow mt-2 xl:mt-0 md:mt-0 lg:mt-0 w-full bg-gray-100 rounded border border-gray-300 focus:outline-none text-sm px-4 py-2 mb-4 sm:mb-0 cursor-not-allowed
                                          "
                        placeholder="Grade"
                        type="text"
                        disabled
                      />
                      <span className="absolute right-0 pt-4 mr-3 md:pt-2 md:mr-2">
                        <i className="material-icons mtfont text-gray-500">
                          lock
                        </i>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <h2 className="text-xl mb-5 mt-8 font-medium border-b pb-2">
            Contact Info
          </h2>
          <div className="text-gray-700 body-font">
            <div className="container">
              <div className="flex flex-wrap -m-4">
                <div className="p-4 w-full md:w-full">
                  <div className="flex flex-wrap md:flex-no-wrap items-start mb-0 md:mb-5">
                    <label
                      htmlFor="name"
                      className="w-48 font-medium text-sm bmd-label
"
                    >
                      Email
                    </label>

                    <div className="relative flex-grow w-full">
                      <input
                        className="flex-grow mt-2 xl:mt-0 md:mt-0 lg:mt-0 w-full bg-gray-100 rounded border border-gray-300 focus:outline-none text-sm px-4 py-2 mb-4 sm:mb-0 cursor-not-allowed
                                          "
                        placeholder="student@selready.com"
                        type="text"
                        disabled
                      />
                      <span className="absolute right-0 pt-4 mr-3 md:pt-2 md:mr-2">
                        <i className="material-icons mtfont text-gray-500">
                          lock
                        </i>
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap -m-4">
                <div className="p-4 w-full md:w-full">
                  <div className="flex flex-wrap md:flex-no-wrap items-start mb-0 md:mb-5">
                    <label
                      htmlFor="name"
                      className="w-48 font-medium text-sm mb-2 xl:mb-0 md:mb-0 lg:mb-0 bmd-label
"
                    >
                      Contact No.
                    </label>
                    <div className="w-full contact-input">
                      <div className="flag_select">
                        {" "}
                        <ReactFlagsSelect defaultCountry="US" />
                      </div>
                      <input
                        className="bg-white border border-gray-400 rounded w-full py-2 px-4 text-gray-700 focus:outline-none focus:bg-white focus:border-gray-800"
                        type="text"
                        placeholder="201-555-0123"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="float-right">
            <button className="transition duration-300 ease-in-out bgRed  mt-10 hover:opacity-75 text-white font-normal py-2 px-4 mr-2 rounded flex uppercase">
              <i className="material-icons">arrow_right_alt</i> &nbsp;Update
            </button>
          </div>
          <div className="clear-both"> </div>
        </div>
      </section>
    );
  }
}

export default MyInfo;
