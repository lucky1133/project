import React, { Component, Fragment } from "react";
import "./Checkitout.css";
import { Link } from "react-router-dom";
import records from "../../../db/teacherdata.json";
import ReactDatatable from "@ashvin27/react-datatable";
import SweetAlert from "sweetalert2-react";

class Checkitout extends Component {
  constructor(props) {
    super(props);
    this.columns = [
      {
        key: "date",
        text: "Date",
        sortable: true,
      },
      {
        key: "title",
        text: "Title",
        sortable: true,
      },
      {
        key: "publish",
        text: "Publish",
        cell: (record, checkitout) => {
          return (
            <Fragment>
              <div className="can-toggle">
                <input id="b" type="checkbox" />
                <label htmlFor="b">
                  <div
                    className="can-toggle__switch"
                    data-checked="No"
                    data-unchecked="Yes"
                  ></div>
                </label>
              </div>
            </Fragment>
          );
        },
      },
      {
        key: "action",
        text: "Action",
        cell: (record, checkitout) => {
          return (
            <Fragment>
              <button className="info-lnk text-white info-lnk mt-4 rounded success-lnk  mr-1">
                <i className="material-icons">visibility</i>
              </button>
              <button className="info-lnk text-white info-lnk mt-4 rounded">
                <i className="material-icons edit_icon">edit</i>
              </button>
              <button
                className="danger-lnk text-white mt-4 rounded ml-1"
                onClick={() => this.setState({ showw: true })}
              >
                <i className="material-icons">close</i>
              </button>
            </Fragment>
          );
        },
      },
    ];
    this.config = {
      page_size: 4,
      length_menu: [10, 20, 50],
      show_filter: true,
      show_pagination: true,
      pagination: "advance",
    };
    this.state = {
      records: records.checkitout,
      show: false,
    };

    this.showModal = this.showModal.bind(this);
    this.hideModal = this.hideModal.bind(this);
  }
  showModal(e) {
    this.setState({ show: true });
  }
  hideModal() {
    this.setState({ show: false });
  }
  render() {
    return (
      <div>
        <main className="content">
          <div className="container-fluid">
            <div className="w-full w-1/1">
              <div className="card ">
                <div className="card-header card-header-icon card-header-primary">
                  <div className="card-icon">
                    <i className="material-icons">list</i>
                  </div>
                  <h4 className="card-title mt-12 md:mt-3 mb-4 md:mb-0">
                    Check It Out
                  </h4>
                  <Link
                    id="addbtn"
                    className="add_user_btn btn-rose inline-block modal-open"
                    to="/add/checkitout"
                  >
                    Create
                  </Link>
                </div>
                <div className="card-body">
                  <div
                    id="user-datatables_wrapper"
                    className="dataTables_wrapper"
                  >
                    <ReactDatatable
                      config={this.config}
                      records={this.state.records}
                      columns={this.columns}
                    />
                    <SweetAlert
                      show={this.state.showw}
                      title="Are you sure ?"
                      text="If you continue,it will be permanently deleted"
                      showCancelButton="true"
                      confirmButtonText="Yes, delete it!"
                      cancelButtonText="Cancel!"
                      onConfirm={() => this.setState({ showw: false })}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }
}

export default Checkitout;
