import React from "react";
import { Route } from "react-router-dom";
import Wall from "./common/Wall";
import Profile from "./pages/profile/Profile";
import Checkitout from "./pages/checkitout/Checkitout";
import AddCheckitout from "./pages/add-checkitout/Add-Checkitout";
import Contests from "./pages/contests/Contests";
import AddContest from "./pages/add-contest/Add-Contest";
import Calendar from "./pages/calendar/Calendar";
import Courses from "./pages/courses/Courses";
import Gallery from "./pages/gallery/Gallery";
import Feedback from "./pages/feedback/Feedback";
import Chat from "./pages/chat/Chat";
import "../admin/common/common-style.css";

const Admin = () => {
  return (
    <>
      <Route path="/" exact component={Wall} />
      <Route path="/profile" component={Profile} />
      <Route path="/calendar" component={Calendar} />
      <Route path="/checkitout" component={Checkitout} />
      <Route path="/add/checkitout" component={AddCheckitout} />
      <Route path="/contests" component={Contests} />
      <Route path="/add/contests" component={AddContest} />
      <Route path="/courses" component={Courses} />
      <Route path="/chat" component={Chat} />
      <Route path="/gallery" component={Gallery} />
      <Route path="/feedback" component={Feedback} />
      <Route path="/all/groups" component={Chat} />
    </>
  );
};

export default Admin;
