import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-addjob',
  templateUrl: './addjob.component.html',
  styleUrls: ['./addjob.component.scss']
})
export class AddjobComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
