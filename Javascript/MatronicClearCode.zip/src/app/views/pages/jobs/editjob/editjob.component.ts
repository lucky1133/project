import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-editjob',
  templateUrl: './editjob.component.html',
  styleUrls: ['./editjob.component.scss']
})
export class EditjobComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
