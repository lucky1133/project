import { Component, OnInit  , ViewChild } from '@angular/core';
import {MatPaginator , MatSort , MatTableDataSource} from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'kt-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss']
})
export class ReportsComponent implements OnInit {

 displayedColumns = [ 'select' , 'imageurl' , 'name', 'name2', 'email' , 'phone' , 'status'  ,'action'];
  dataSource = new MatTableDataSource<Element>(ELEMENT_DATA);
    selection = new SelectionModel<Element>(true, []);
	/** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
    this.selection.clear() :
    this.dataSource.data.forEach(row => this.selection.select(row));
  }
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
    @ViewChild(MatSort, {static: true}) sort: MatSort;
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
	    this.dataSource.sort = this.sort;
  }
   applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }
  constructor(private modalService: NgbModal) { }

  ngOnInit() {
  }
open(content) {
        this.modalService.open(content).result.then((result) => {       
        });
    }
}

export interface Element {
  name: string;
  name2: string;
  //result: string;
  email: string;
  phone: string;
  imageurl: string;
  status: string;
}
const ELEMENT_DATA: Element[] = [
  { imageurl:'assets/media/users/salon1.jpg', name: 'Lakme Salon ',  name2: 'John Smith' , email: 'lakme@info.com' , status: 'Fake Documents', phone: '+1234 567 890'},
  { imageurl:'assets/media/users/salon2.jpg', name: 'Matrix Salon', name2: 'David Smith' , email: 'matrix@info.com' , status: 'Fake Information', phone: '+1234 567 890'},
  { imageurl:'assets/media/users/salon3.jpg', name: 'Natural Salon', name2: 'Steve Smith' , email: 'natural@info.com' ,  status: 'Cheating', phone: '+1234 567 890'},
  { imageurl:'assets/media/users/salon1.jpg', name: 'Steve Salon', name2: 'Johnson Smith' , email: 'steve@info.com' ,  status: 'Bad Behavior', phone: '+1234 567 890'},
  { imageurl:'assets/media/users/salon2.jpg', name: 'Beauty Salon', name2: 'Andrew Smith' , email: 'beauty@info.com' , status: 'Fraud', phone: '+1234 567 890'},
  { imageurl:'assets/media/users/salon3.jpg', name: 'Natural Salon', name2: 'John Smith' , email: 'natural@info.com' ,  status: 'Cheating ', phone: '+1234 567 890'}
];