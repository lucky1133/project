import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-editrestro',
  templateUrl: './editrestro.component.html',
  styleUrls: ['./editrestro.component.scss']
})
export class EditrestroComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
