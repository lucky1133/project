// Angular
import { Component, OnInit } from '@angular/core';
// Lodash
import { shuffle } from 'lodash';
// Services
// Widgets model
import { LayoutConfigService, SparklineChartOptions } from '../../../core/_base/layout';
import {MatPaginator , MatSort , MatTableDataSource} from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
@Component({
	selector: 'kt-dashboard',
	templateUrl: './dashboard.component.html',
	styleUrls: ['dashboard.component.scss'],
})
export class DashboardComponent implements OnInit {
	displayedColumns = ['id','food_item','username','address','points','status','action'];
	dataSource = ELEMENT_DATA1;

	chartOptions1: SparklineChartOptions;
	chartOptions2: SparklineChartOptions;
	chartOptions3: SparklineChartOptions;
	chartOptions4: SparklineChartOptions;
	// widget4_1: Widget4Data;
	// widget4_2: Widget4Data;
	// widget4_3: Widget4Data;
	// widget4_4: Widget4Data;

	constructor(private layoutConfigService: LayoutConfigService , private modalService: NgbModal) {
	}
open(content) {
        this.modalService.open(content).result.then((result) => {
        });
    }
	ngOnInit(): void {
		this.chartOptions1 = {
			data: [10, 14, 18, 11, 9, 12, 14, 17, 18, 14],
			color: this.layoutConfigService.getConfig('colors.state.brand'),
			border: 3
		};
		this.chartOptions2 = {
			data: [11, 12, 18, 13, 11, 12, 15, 13, 19, 15],
			color: this.layoutConfigService.getConfig('colors.state.danger'),
			border: 3
		};
		this.chartOptions3 = {
			data: [12, 12, 18, 11, 15, 12, 13, 16, 11, 18],
			color: this.layoutConfigService.getConfig('colors.state.success'),
			border: 3
		};
		this.chartOptions4 = {
			data: [11, 9, 13, 18, 13, 15, 14, 13, 18, 15],
			color: this.layoutConfigService.getConfig('colors.state.primary'),
			border: 3
		};


	}
}

export interface Element {
	id: string;
	food_item: string;
	points: string;
	username: string;
	address: string;
	status: string;
}
const ELEMENT_DATA1: Element[] = [
  {id: "1" , food_item:'Great Cheese Chilli', points : '25', username : 'Adelmo', address: '4344 E. Juanita Avenue Gilbert', status :'cancelled'},
  {id: "2" , food_item:'Big Hamburger', points : '50', username : 'John Doe', address: '4344 E. Juanita Avenue Gilbert', status :'completed'},
  {id: "3" , food_item:'Great Cheese Chilli', points : '25', username : 'Adelmo', address: '4344 E. Juanita Avenue Gilbert', status :'pending'},
  {id: "4" , food_item:'Big Hamburger', points : '50', username : 'John Doe', address: '4344 E. Juanita Avenue Gilbert', status :'cancelled'},
  {id: "5" , food_item:'Great Cheese Chilli', points : '25', username : 'Adelmo', address: '4344 E. Juanita Avenue Gilbert', status :'completed'},
  {id: "6" , food_item:'Big Hamburger', points : '50', username : 'John Doe', address: '4344 E. Juanita Avenue Gilbert', status :'pending'},
];
