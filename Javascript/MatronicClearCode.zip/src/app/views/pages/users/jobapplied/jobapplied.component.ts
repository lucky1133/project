import { Component, OnInit , ViewChild } from '@angular/core';
import {MatPaginator , MatSort , MatTableDataSource} from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'kt-jobapplied',
  templateUrl: './jobapplied.component.html',
  styleUrls: ['./jobapplied.component.scss']
})
export class JobappliedComponent implements OnInit {

 displayedColumns = [ 'select' , 'imageurl' , 'name', 'cname' , 'location' , 'salary'  ,'experience'];
  dataSource = new MatTableDataSource<Element>(ELEMENT_DATA);
    selection = new SelectionModel<Element>(true, []);
	/** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
    this.selection.clear() :
    this.dataSource.data.forEach(row => this.selection.select(row));
  }
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
    @ViewChild(MatSort, {static: true}) sort: MatSort;
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
	    this.dataSource.sort = this.sort;
  }
   applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }
  constructor(private modalService: NgbModal) { }

  ngOnInit() {
  }
open(content) {
        this.modalService.open(content).result.then((result) => {       
        });
    }

}

export interface Element {
  name: string;
  //result: string;
  cname: string;
  location: string;
  imageurl: string;
  salary: string;
  experience: string;
}
const ELEMENT_DATA: Element[] = [
  { imageurl:'assets/media/users/job1.jpg', name: 'Dentist Assistant Trainee ',  cname: 'Smily Dental Clinic' , location: '123 Town Street, CA', salary: '$1000 - $2000'  , experience:'1 Year'},
  { imageurl:'assets/media/users/job2.jpg', name: 'Dentist', cname: 'Fortis Dental Clinic' , location: '678 New Town Street', salary: '$2000 - $3000' , experience:'1 Year'},
  { imageurl:'assets/media/users/job3.jpg', name: 'Dentist  Hygienist', cname: 'Dental Clinic' ,  location: '345 New Town Street', salary: '$3000 - $4000'  , experience:'2 Years'},
  { imageurl:'assets/media/users/job4.jpg', name: 'Experienced Dentist', cname: 'Fortis Dental Clinic' ,  location: '467 Town Street ,Alaska', salary: '$1500 - $2500'  , experience:'1 Year'},
  { imageurl:'assets/media/users/job1.jpg', name: 'Senior Dentist', cname: 'Smily Dental Clinic' , location: '123 Town Street, CA', salary: '$3000 - $4500'  , experience:'3 Years'},
  { imageurl:'assets/media/users/job2.jpg', name: 'Dentist', cname: 'Fortis Dental Clinic' ,  location: '345 Town Street, CA', salary: '$1700 - $2800'  , experience:'5 Years'}
];