import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-user-logs',
  templateUrl: './user-logs.component.html',
  styleUrls: ['./user-logs.component.scss']
})
export class UserLogsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
