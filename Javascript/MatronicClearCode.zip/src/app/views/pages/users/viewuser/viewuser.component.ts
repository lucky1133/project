import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-viewuser',
  templateUrl: './viewuser.component.html',
  styleUrls: ['./viewuser.component.scss']
})
export class ViewuserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
