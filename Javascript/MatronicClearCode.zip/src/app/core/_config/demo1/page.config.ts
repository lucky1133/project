export class PageConfig {
	public defaults: any = {
		    dashboard: {
		     page: {title: 'Dashboard', desc: ''},
			},
			users: {
		     page: {title: 'User', desc: ''},
			'adduser': {page: {title: 'Add User', desc: ''}},
			'edituser': {page: {title: 'Edit User', desc: ''}},

			},
			reports: {
		     page: {title: 'Reports', desc: ''},
			},
			pages: {
				page: {title: 'Pages', desc: ''}

				},

					notifications: {
					page: {title: 'Notifications', desc: ''}
				},
					profile: {
					page: {title: 'Profile', desc: ''}
				},

				builder: {
					page: {title: 'Layout Builder', desc: ''}
				},
			};

	public get configs(): any {
		return this.defaults;
	}
}
