export class MenuConfig {
	public defaults: any = {
		header: {
			self: {},
			items: []
		},
		aside: {
			self: {},
			items: [
				{
					title: 'Dashboard',
					root: true,
					icon: 'flaticon2-architecture-and-city',
					page: 'dashboard',
					translate: 'MENU.DASHBOARD',
					bullet: 'dot',
				},
				{
					title: 'Report',
					bullet: 'dot',
					page: 'reports',
					icon: 'flaticon2-document',
				},
				{
					title: 'Notifications',
					bullet: 'dot',
					page: 'notifications',
					icon: 'flaticon2-bell',
				},
				{
					title: 'Profile Settings',
					bullet: 'dot',
					page: 'profile',
					icon: 'flaticon2-user-1',
				},
			]
		},
	};

	public get configs(): any {
		return this.defaults;
	}
}
