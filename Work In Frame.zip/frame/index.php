<?php
$codeBeforeHead='
	<style type="text/css">
		h2
		{
			cursor:crosshair; 
			background-color:black; 
			color:white;
		}
		
		.step.step-active
		{
			display:none !important;
		}
		
		.header
		{
			display:none;
		}
		
		#myNavbar ul li a
		{
			background-color:transparent;
		}
		
		.navbar-inverse
		{
			border-bottom:1px solid #000;
		}
		
		.footer{
			display:none;
		}
		
		.text-sec
		{
			display:none;
		}
		
		.sidebar-wrpper
		{
			display:none;
		}
		
		#google_ads_frame2
		{
			display:none !important;
		}
	</style>
	<base href="https://searchenginereports.net/plagiarism-checker">
	';
	$content=file_get_contents("https://searchenginereports.net/plagiarism-checker");
	$content = str_replace('</head>', $codeBeforeHead.'</head>', $content);
	echo $content;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Geek</title>
    <meta name="description" content="">
    <meta name="keywords" content="">

    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
	
	<style>
		body
		{
			padding-top:90px;
		}
	</style>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	

</head>

<body>
    <div id="myDiv">
        <nav class="navbar navbar-inverse navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">LOGO</a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">

                    <ul class="nav navbar-nav navbar-right" id="navigation-menu">
                        <li><a href="index.html">Home</a></li>
                        <li><a href="#abt">About Us</a></li>
                        <li><a href="#ser">Services</a></li>
                        <li><a href="#con">Contact Us</a></li>
                      
                    </ul>
                </div>
            </div>
        </nav>
    </div>

	<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">
					<h1> Footer </h1>
				</div>
			</div>
		</div<
	</footer>
</body>

</html>