
<?php 
include('connection.php');
if(!empty($_POST))
	{
		extract($_POST);
		$query = "SELECT * FROM `users` WHERE `email`='".mysqli_real_escape_string($con,$email)."' AND `password`='".mysqli_real_escape_string($con,$pass)."' LIMIT 1";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		if(count($row))
		{
			$_SESSION['user']=$row;
			header("Location: index.php");
		}
		
		else
		{
			$msg =  "User Name Invalid";
			
		}
	}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/util.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">

    <title>Employee</title>
  </head>
  <body style="background-image: url('images/bg-01.jpg');"> 
  

    <div class="limiter">
		<div class="container-login100" >
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">
				<form class="login100-form validate-form" action="login.php" method="post">
					<span class="login100-form-title p-b-49">
						Login
					</span>

					<div class="wrap-input100 validate-input m-b-23" data-validate = "Email is reauired">
						<span class="label-input100">Email</span>
						<input class="input100" type="text" name="email" placeholder="Type your email" required >
						<span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-23" data-validate="Password is required">
						<span class="label-input100">Password</span>
						<input class="input100" type="password" name="pass" placeholder="Type your password" required >
						<span class="focus-input100" data-symbol="&#xf190;"></span>
					</div>
					
				
					<?php if(isset($msg))
					{?>
						<div class='p-t-8 p-b-31'> 
							<div class="alert alert-danger">
						  		<strong>Error!</strong> <?php echo $msg; ?>
							</div> 
						</div>
					<?php
					}
					?>

					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn">
								Login
							</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>

    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>	
  </body>
</html>