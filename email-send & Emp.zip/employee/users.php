<?php
	
	include("connection.php");
	 if(isset($_SESSION['user']))
   {
      $user = $_SESSION['user'];
	  if($user['role'] != 'admin'){
		  header('Location: index.php');
	  }
   }

   else
   {
      header("Location: login.php");
   }
	$query = "SELECT * from `users` WHERE role !='admin'";
	$result = mysqli_query($con,$query);
	
	
?>
<!doctype html>
<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      
      <link rel="stylesheet" type="text/css" href="css/material-design-iconic-font.min.css">
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/util.css">
      <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
      <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">
      <link rel="stylesheet" href="https://cdn.datatables.net/fixedheader/3.1.5/css/fixedHeader.bootstrap.min.css">
      <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
      <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
	
      <title>Employee</title>
   </head>
   <body>

      <?php include("navigation.php"); ?>

      <div class="container-login100" style="background-image: url('images/bg-01.jpg');">
         <section class="datatable">
            <div class="container">
               <div class="row">
                  <div class="col-md-12 table-responsive">
                     <div class="card">
                        <div class="card-body">
                           <div class="m-b-10">
							 
                              <h1 class="card-title m-b-0 text-center" style="font-size:30px;margin-top:0px;">User List</h1>
							  <div class="text-right"><a href="useradd.php" class="btn btn-success "> <i class="fa fa-user-plus" aria-hidden="true"></i></a></div>
							  <hr>
						   </div>
                           <div class="table-responsive">
							
                              <table id="example" class="table table-striped table-bordered nowrap" style="width:100%">
                                 <thead>
								 
                                    <tr>
                                       <th>#</th>
                                       <th>Name</th>
                                       <th>Email</th>
                                       <th>Role</th>
                                       <th>Created</th>
                                       <th>Status</th>
                                       <th>Action</th>
                                    </tr>
                                 </thead>
                                 <tbody>
								 <?php 
									$number = 0;
									while($row = mysqli_fetch_assoc($result))
									{
										
										$number++;
									
								 
								 ?>
                                    <tr>
                                       <td><?php echo $number;?></td>
                                       <td><?php echo $row['name']?></td>
                                       <td><?php echo $row['email']?></td>
                                       <td><?php echo $row['role']?></td>
                                       <td><?php echo $row['created_at']?></td>	
                                       <td><?php echo $row['status']?></td>
                                       <td><a href="useredit.php?uid=<?php echo $row['uid'];?>" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></a> <a href="userdelete.php?delid=<?php echo $row['uid'];?>" class="btn btn-danger btn-xs" onclick="return confirm('Are You Sure!')"><i class="fa fa-trash"></i></a></td>
                                     
                                    </tr>
								<?php
								
									}
								?>
                                    
                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
      </div>
      <!-- jQuery first, then Popper.js, then Bootstrap JS -->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	  <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
      <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
      <script src="https://cdn.datatables.net/fixedheader/3.1.5/js/dataTables.fixedHeader.min.js"></script>
	  <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
	  <script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>
	  <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
	  
	  <script>
		$(document).ready(function() {
			var table = $('#example').DataTable( {
				fixedHeader: true
			});
		});
     </script>
   </body>
</html>