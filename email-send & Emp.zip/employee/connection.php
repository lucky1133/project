<?php 
	session_start();
	$con = mysqli_connect('localhost','fareandflights','$ftpr3m0t3','employee_crm');
	if($con)
	{
		//echo "Connected Successfull" or die ("Error".mysqli_error());
	}else { echo "Galat h";
	}
	
?>