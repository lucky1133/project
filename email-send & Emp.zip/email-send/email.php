<?php
if(!empty($_POST)){
    extract($_POST);
    // multiple recipients
    $to  = 'info@airflightsreservation.com'; // note the comma
    
    
    // subject
    $subject = 'Recieve a Newsletter request!';
    
    // message
    $message = '
      <p>Receive a Newsletter Request from :</p>
    '.$email;
    
    // To send HTML mail, the Content-type header must be set
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
    
    // Additional headers
    $headers .= 'To: AirFlightReservation <info@airflightsreservation.com>' . "\r\n";
    $headers .= 'From: <'.$email.'>' . "\r\n";
    
    
    // Mail it
    mail($to, $subject, $message, $headers);
}
header('Location: thankyou.html');

?>

